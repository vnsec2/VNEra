/*
 * Adapted from BitChord (https://github.com/kushagrasinghx/BitChord), GPL-3.0-or-later,
 * sharedUi/src/jvmSharedMain/kotlin/com/music/bitchord/ui/screens/HomeScreen.kt at edc1e6f.
 * Modified for Myspoti, 2026-10.
 */
package com.music.spotui.ui.immersive.screens

import com.music.spotui.ui.immersive.shell.immersiveHazeSource
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import com.music.spotui.ui.components.arrivingRow
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.rounded.NotificationsNone
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import app.myspoti.engine.R
import com.music.spotui.data.api.Features
import com.music.spotui.data.api.ProfileCache
import com.music.spotui.data.api.Response
import com.music.spotui.data.entity.HomeItem
import com.music.spotui.data.entity.HomeSection
import com.music.spotui.data.entity.homeShortcuts
import com.music.spotui.data.entity.withoutDj
import com.music.spotui.data.entity.withoutPodcastShows
import com.music.spotui.di.Graph
import com.music.spotui.di.SongPlayer
import com.music.spotui.ui.components.onHomeItemClick
import com.music.spotui.ui.components.prefetchHomeItem
import com.music.spotui.ui.components.prefetchHomeShortcuts
import com.music.spotui.ui.components.pressHint
import com.music.spotui.ui.immersive.Immersive
import com.music.spotui.ui.immersive.components.ImmersiveCover
import com.music.spotui.ui.immersive.components.ImmersiveLargeAlbumCard
import com.music.spotui.ui.immersive.components.ImmersiveMessageState
import com.music.spotui.ui.immersive.components.ImmersiveShelf
import com.music.spotui.ui.immersive.components.ImmersiveShelfCard
import com.music.spotui.ui.immersive.components.ImmersiveShelfRow
import com.music.spotui.ui.immersive.components.SectionHeader
import com.music.spotui.ui.immersive.components.immersiveClickable
import com.music.spotui.ui.immersive.components.immersiveFeedSkeleton
import com.music.spotui.ui.immersive.components.immersiveHeroCardWidth
import com.music.spotui.ui.immersive.shell.ImmersiveFloatingHeader
import com.music.spotui.ui.immersive.shell.ImmersiveHeaderContentHeight
import com.music.spotui.ui.immersive.shell.LocalBarControlSize
import com.music.spotui.ui.immersive.shell.immersiveChromeScroll
import com.music.spotui.ui.immersive.shell.immersiveHeaderContentPadding
import com.music.spotui.ui.immersive.shell.rememberTopBarCollapse
import com.music.spotui.ui.navigation.Routes
import com.music.spotui.ui.navigation.TabReselect
import com.music.spotui.ui.viewmodel.HomeViewModel

/**
 * Home in the Immersive look: the greeting as the page's large title with the profile disc at its
 * end, the facet pills, then the feed — the first carousel as big cards, the rest as shelves. The
 * data, clicks, prefetch and profile actions are those of the Classic Home screen.
 */
@Composable
fun ImmersiveHomeScreen(navController: NavController) {
    val homeViewModel: HomeViewModel = viewModel()
    val home by homeViewModel.home.collectAsState()
    val feed = (home as? Response.Success)?.data
    val facet = homeViewModel.facet.value
    val context = LocalContext.current
    LaunchedEffect(Unit) { ProfileCache.ensure(context) }
    // An old feed is read again when Home shows again (see HomeViewModel.refreshIfStale).
    androidx.lifecycle.compose.LifecycleEventEffect(androidx.lifecycle.Lifecycle.Event.ON_RESUME) { homeViewModel.refreshIfStale() }

    // Re-tapping the Home tab while on Home scrolls back to the top, as in the Classic screen.
    val listState = rememberLazyListState()
    LaunchedEffect(Unit) {
        TabReselect.home.collect {
            if (listState.firstVisibleItemIndex != 0 || listState.firstVisibleItemScrollOffset != 0) {
                listState.animateScrollToItem(0)
            }
        }
    }

    val homeTitle = stringResource(R.string.navigationbar_musicappitems_home_title)
    val title = feed?.greeting?.takeIf { it.isNotBlank() } ?: homeTitle
    var showProfile by remember { mutableStateOf(false) }
    if (showProfile) {
        ImmersiveProfileSheet(
            onOpen = { route -> showProfile = false; navController.navigate(route) },
            onDismiss = { showProfile = false },
        )
    }

    // The context playing right now (empty while paused), derived once for every card: a card
    // only recomposes when its own answer flips, not on every change of the player's state.
    val playingContext = remember {
        derivedStateOf { if (Graph.currentSongState.playingState.value) SongPlayer.nowPlaying.value.contextUri else "" }
    }

    val hideDj = com.music.spotui.data.preferences.HideDjPref.hidden
    val podcastsShown = Features.PODCASTS
    LaunchedEffect(podcastsShown, facet) {
        val parent = com.music.spotui.data.entity.HomeSubChips.parentOf(facet) ?: facet
        if (!podcastsShown && (parent == "podcasts-chip" || parent == "audiobooks-chip")) {
            homeViewModel.selectFacet("")
        }
    }
    val sections = remember(feed, hideDj, podcastsShown) {
        val all = feed?.sections.orEmpty().withoutPodcastShows()
        if (hideDj) all.withoutDj() else all
    }
    // Only the untitled section the web home starts with is a shortcut grid; a titled lead
    // section is a carousel like any other.
    val gridSection = sections.firstOrNull()?.takeIf { it.title.isBlank() }
    val carousels = if (gridSection != null) sections.drop(1) else sections
    // Liked Songs leads the shortcuts when Spotify's grid does not carry it.
    val likedName = stringResource(R.string.collection_liked_songs_title)
    val shortcuts = remember(gridSection, sections, facet, likedName) { homeShortcuts(gridSection?.items, sections.isEmpty(), facet, likedName) }
    // The shortcuts at the top load in the background, ready before a tap.
    LaunchedEffect(shortcuts) { prefetchHomeShortcuts(shortcuts) }

    Box(Modifier.fillMaxSize().background(Immersive.Page)) {
        LazyColumn(
            state = listState,
            // The greeting is the floating header's own title, so the feed starts right under it
            // (it used to be a large title under an empty bar row: the gap at the top of Home).
            contentPadding = PaddingValues(top = immersiveHeaderContentPadding(), bottom = Immersive.BottomChrome),
            modifier = Modifier.fillMaxSize().immersiveHazeSource().immersiveChromeScroll(),
        ) {
            item(key = "home:facets") {
                ImmersiveHomeFacets(
                    facet,
                    labels = mapOf(
                        "" to stringResource(R.string.filter_chip_all_label),
                        "music-chip" to stringResource(R.string.recents_content_filter_music),
                        "podcasts-chip" to stringResource(R.string.ad_category_title_podcasts),
                        "audiobooks-chip" to stringResource(R.string.audiobooks_title),
                    ),
                    podcasts = Features.PODCASTS,
                    select = homeViewModel::selectFacet,
                )
            }
            when {
                feed != null && feed.sections.isNotEmpty() -> {
                    shortcuts?.let { tiles ->
                        item(key = "home:shortcuts") {
                            // The feed fades in over its placeholder (see immersiveFeedSkeleton).
                            Box(arrivingRow()) {
                                ShortcutGrid(navController, tiles, playingContext)
                            }
                        }
                    }
                    carousels.forEachIndexed { index, section ->
                        item(key = "home:section:$index:${section.title}") {
                            // The lead carousel gets the big cards, unless it is a row of artists.
                            val hero = index == 0 && section.items.none { it is HomeItem.Artist }
                            Box(arrivingRow()) {
                                if (hero) HeroSection(navController, section, playingContext) else ShelfSection(navController, section, playingContext)
                            }
                        }
                    }
                    // Sections from extensions (home.sections), after Spotify's own.
                    item(key = "home:extensions") {
                        com.music.spotui.extensions.ExtensionBlocks(app.myspoti.extensions.Hook.HOME, app.myspoti.extensions.Surface.HOME, "{}")
                    }
                }
                home is Response.Loading -> immersiveFeedSkeleton(firstIsHero = true)
                else -> item(key = "home:message") {
                    ImmersiveMessageState(
                        message = stringResource(if (home is Response.Error) R.string.home_error else R.string.home_empty),
                        actionLabel = if (home is Response.Error) stringResource(R.string.home_retry) else null,
                        onAction = if (home is Response.Error) ({ homeViewModel.retry() }) else null,
                    )
                }
            }
        }
        // The greeting, the bell and the profile disc on floating glass; the feed scrolls under it.
        ImmersiveFloatingHeader(title, collapse = rememberTopBarCollapse(listState, 24.dp)) {
            // Friend activity, out of the tab bar: beside the profile, as Spotify has it.
            com.music.spotui.ui.immersive.shell.ImmersiveBarAction(
                androidx.compose.ui.graphics.vector.ImageVector.vectorResource(R.drawable.ic_friends_big),
                contentDescription = stringResource(R.string.friends_title),
                onClick = { navController.navigate(com.music.spotui.ui.navigation.Routes.Friends.route) },
            )
            val size = LocalBarControlSize.current
            WhatsNewBell(size) { navController.navigate(Routes.WhatsNew.route) }
            // The tap area is the header's full height and reaches past the disc toward the
            // title, so the small disc of the minimized bar is still easy to hit.
            Box(
                Modifier
                    .height(ImmersiveHeaderContentHeight)
                    .width(size + 20.dp)
                    .immersiveClickable(onClick = { showProfile = true }),
                contentAlignment = Alignment.CenterEnd,
            ) {
                Box(
                    Modifier.size(size).graphicsLayer { scaleX = size / 44.dp; scaleY = scaleX },
                    contentAlignment = Alignment.Center,
                ) {
                    ProfileDisc(onClick = null)
                }
            }
        }
    }
}

/** The bell left of the profile disc: opens "What's New". Its tap area is the header's full height, as the disc's is. */
@Composable
private fun WhatsNewBell(size: androidx.compose.ui.unit.Dp, onClick: () -> Unit) {
    Box(
        Modifier
            .height(ImmersiveHeaderContentHeight)
            .width(size)
            .immersiveClickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        androidx.compose.material3.Icon(
            androidx.compose.material.icons.Icons.Rounded.NotificationsNone,
            contentDescription = stringResource(R.string.whats_new_title),
            tint = Immersive.Text,
            modifier = Modifier.size(size * 0.55f),
        )
    }
}

/** The uri of the thing this card opens, to tell whether it is what is playing. */
private fun HomeItem.contextUri(): String = when (this) {
    is HomeItem.Album -> if (id.isNotBlank()) "spotify:album:$id" else ""
    is HomeItem.Playlist -> if (id.isNotBlank()) "spotify:playlist:$id" else ""
    is HomeItem.Artist -> if (id.isNotBlank()) "spotify:artist:$id" else ""
    is HomeItem.Show -> if (id.isNotBlank() && !isEpisode) "spotify:show:$id" else ""
}

/** True while this card's album, playlist or artist is the playing context, [playingContext]. */
private fun HomeItem.isPlayingIn(playingContext: String): Boolean {
    val uri = contextUri()
    return uri.isNotEmpty() && playingContext == uri
}

/**
 * Keys for the cards of a shelf: the uri they open, or their kind and name for those with none
 * (an episode). A repeat within one shelf gets a suffix, as a lazy list refuses two equal keys.
 */
private fun homeItemKeys(items: List<HomeItem>): List<String> {
    val seen = HashMap<String, Int>()
    return items.map { item ->
        val base = item.contextUri().ifEmpty { "${item::class.simpleName}:${item.name}:${item.imageUrl}" }
        val count = seen.merge(base, 1, Int::plus) ?: 1
        if (count == 1) base else "$base#$count"
    }
}

@Composable
private fun HomeItem.cardSubtitle(): String = when (this) {
    is HomeItem.Album -> subtitle
    is HomeItem.Playlist -> subtitle
    is HomeItem.Artist -> stringResource(R.string.artist_subtitle)
    is HomeItem.Show -> subtitle
}

/** The lead carousel: big artwork cards with the caption over a scrim, the next one peeking in. */
@Composable
private fun HeroSection(navController: NavController, section: HomeSection, playingContext: State<String>) {
    Column(Modifier.padding(bottom = 26.dp)) {
        SectionHeader(section.title)
        BoxWithConstraints {
            // Measured: the card has a ceiling as well as a fraction, and the skeleton agrees.
            val cardWidth = immersiveHeroCardWidth(maxWidth)
            val keys = remember(section.items) { homeItemKeys(section.items) }
            ImmersiveShelfRow {
                items(section.items.size, key = { keys[it] }) { i ->
                    val item = section.items[i]
                    // One lambda per card, so the press hint's pointer input is not restarted by a recomposition.
                    val hint = remember(item) { { prefetchHomeItem(item) } }
                    ImmersiveLargeAlbumCard(
                        title = item.name,
                        subtitle = item.cardSubtitle(),
                        imageUrl = item.imageUrl,
                        onClick = { onHomeItemClick(navController, item) },
                        modifier = Modifier.width(cardWidth).pressHint(hint),
                        playing = item.isPlayingIn(playingContext.value),
                    )
                }
            }
        }
    }
}

/** A titled row of square cards (round for artists). */
@Composable
private fun ShelfSection(navController: NavController, section: HomeSection, playingContext: State<String>) {
    val keys = remember(section.items) { homeItemKeys(section.items) }
    ImmersiveShelf(title = section.title) {
        items(section.items.size, key = { keys[it] }) { i ->
            val item = section.items[i]
            val hint = remember(item) { { prefetchHomeItem(item) } }
            ImmersiveShelfCard(
                title = item.name,
                subtitle = item.cardSubtitle(),
                imageUrl = item.imageUrl,
                onClick = { onHomeItemClick(navController, item) },
                modifier = Modifier.width(com.music.spotui.ui.immersive.components.ImmersiveShelfCardWidth)
                    .pressHint(hint),
                round = item is HomeItem.Artist,
                playing = item.isPlayingIn(playingContext.value),
                badge = if (item is HomeItem.Show && !item.isEpisode) ({
                    com.music.spotui.ui.components.NewEpisodeDot(item.id, Immersive.Accent, Modifier.align(Alignment.TopEnd).padding(8.dp))
                }) else null,
            )
        }
    }
}

/** The two-column shortcuts the web home starts with: a small cover and a name on a raised tile. */
@Composable
private fun ShortcutGrid(navController: NavController, items: List<HomeItem>, playingContext: State<String>) {
    Column(
        modifier = Modifier.padding(horizontal = Immersive.Gutter).padding(bottom = 22.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        // Large windows: more tiles per row (two on phones).
        val cols = com.music.spotui.ui.components.windowSize().columns(2, 280.dp)
        items.chunked(cols).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                rowItems.forEach { item ->
                    val playing = item.isPlayingIn(playingContext.value)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp)
                            .pressHint { prefetchHomeItem(item) }
                            .immersiveClickable(onClick = { onHomeItemClick(navController, item) })
                            .clip(Immersive.CoverMedium)
                            .background(Immersive.Raised),
                    ) {
                        ImmersiveCover(
                            url = item.imageUrl,
                            modifier = Modifier.size(56.dp),
                            shape = Immersive.CoverMedium,
                            border = false,
                        )
                        Text(
                            text = item.name,
                            style = Immersive.Subhead.copy(
                                color = if (playing) Immersive.Accent else Immersive.Text,
                                fontWeight = FontWeight.SemiBold,
                                lineHeight = 17.sp,
                                // Two balanced lines rather than a lone word under the rest.
                                lineBreak = androidx.compose.ui.text.style.LineBreak.Heading,
                            ),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 10.dp).weight(1f),
                        )
                    }
                }
                repeat(cols - rowItems.size) { Box(Modifier.weight(1f)) }
            }
        }
    }
}
