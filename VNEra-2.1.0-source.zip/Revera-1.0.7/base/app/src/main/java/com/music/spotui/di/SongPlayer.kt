package com.music.spotui.di
import app.myspoti.host.android.AppLog

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import app.myspoti.api.ItemKind
import app.myspoti.api.MyspotiApi
import app.myspoti.api.PlayerState
import app.myspoti.api.Repeat
import app.myspoti.host.android.MyspotiRuntime
import app.myspoti.host.android.NowPlayingInfo
import app.myspoti.host.android.PlaybackService
import com.music.spotui.data.entity.SongsModel
import com.music.spotui.data.local.LocalFileMatch.isDeviceFile
import com.music.spotui.data.local.LocalFileMatch.isUnmatchedLocal
import com.music.spotui.data.offline.OfflineStore
import com.music.spotui.extensions.ExtensionAudio
import com.music.spotui.extensions.Extensions
import com.music.spotui.extensions.spotifyFirstRoute
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap

/**
 * The UI's player facade over two players. [LocalPlayer] (the AutoMix engine) plays the
 * extensions' streams, the phone's files and the downloads, and is the one heard for them. The
 * account's player ([MyspotiApi.player], Spotify's Web Player) is heard only when the user picks
 * it as the audio source ([com.music.spotui.extensions.ACCOUNT_SOURCE]), for what only it has
 * (episodes), or on another device through Spotify Connect; else it runs unheard as the listen
 * sync's mirror, when that is on (AccountSync).
 *
 * Screens call playSong / play / pause / seekTo / getCurrentPosition…; the controls go to the
 * player heard. The account's player keeps its own queue, so next/previous/shuffle/repeat are its
 * own while it plays.
 */
object SongPlayer {
    private const val SPOTIFY_TRACK_PREFIX = "spotify:track:"
    private const val PENDING_MS = 6000L
    /** The longest a song is shown loading while the extensions are asked (they answer sooner). */
    private const val ROUTE_HOLD_MS = 40_000L
    /** The end-of-track timer pauses this close to the end (before the next item starts). */
    private const val END_OF_TRACK_MARGIN_MS = 600L
    /** How often the state is read again while another device plays and the app is on screen. */
    private const val REMOTE_REFRESH_MS = 3_000L
    /**
     * The same with the app in the background or the screen off: the notification's clock runs on
     * by itself and Spotify's own messages bring a change; the song's end is read at once (overdue).
     */
    private const val REMOTE_BACKGROUND_REFRESH_MS = 30_000L
    /** How often the state is read again while this phone plays (the page pushes its changes). */
    private const val LOCAL_REFRESH_MS = 15_000L
    /** Nothing to read (this phone is idle): the refresh loop sleeps this long, or until a state or a Connect device wakes it. */
    private const val IDLE_WAKE_MS = 60_000L
    /** A song this far past its end with no new state from the page: the state is read at once. */
    private const val SONG_END_GRACE_MS = 1_500L
    /** A transport command that has not answered by then is given up (the next one runs). */
    private const val TRANSPORT_TIMEOUT_MS = 15_000L
    /**
     * A transport command still running this long when a newer one comes is stuck (a dead
     * connection, a page that does not answer): it is given up at once rather than holding the
     * newer one for the rest of [TRANSPORT_TIMEOUT_MS]. A skip normally answers well within it.
     */
    private const val TRANSPORT_STUCK_MS = 3_000L
    /**
     * The longest a skip is shown ahead of the page: its burst gap, its turn behind a stuck command
     * and its own timeout. Once it is answered, the page has [SKIP_ANSWERED_MS] (see [skipDone]).
     */
    private const val SKIP_PENDING_MAX_MS = TRANSPORT_TIMEOUT_MS + 5_000L
    /**
     * An answered skip whose song has not come by then: the old song is heard again (the engine
     * brings its sound back 2.5 s after the skip, SpotifyPlayer.FADE_BACK_MAX_MS), so the screen
     * shows it again too. Reported: the next song's cover on screen, the old song playing on.
     */
    private const val SKIP_ANSWERED_MS = 3_000L
    /** How long a play has to show up in the page's state before it is sent again. */
    private const val PLAY_CHECK_MS = 4_000L
    /** A resume of an episode that the page did not take is asked for again after that. */
    private const val EPISODE_RESUME_CHECK_MS = 2_500L
    /** A timed sleep timer lowers the volume over its last seconds. */
    private const val SLEEP_FADE_MS = 15_000L
    /** "Next" taps closer than this are sent as one jump. */
    private const val SKIP_BURST_MS = 350L
    /** Skip commands are at least this far apart; taps in between add up (see [next]). */
    private const val MIN_SKIP_GAP_MS = 2_000L
    /** An ad break shorter than this is never shown (see the adPlaying collector). */
    private const val AD_SHOW_AFTER_MS = 2_000L
    /** After a local file starts, engine states this recent still predate the pause. */
    private const val LOCAL_GRACE_MS = 2500L
    /** An answered command's state reaches the app within this (see [reconcile]). */
    private const val COMMAND_SETTLE_MS = 1_500L
    /** A hold's end is checked this long after it, so the hold is over by then (see [reconcile]). */
    private const val RECONCILE_MARGIN_MS = 100L
    /** The page's state is read again that long at most before the screen is put right. */
    private const val RECONCILE_READ_MS = 3_000L
    /** A seek is sent within this, or given up for this try (see [seekTo]). */
    private const val SEEK_SEND_MS = 5_000L
    /** How long a seek has to show up in the page's state before it is sent again. */
    private const val SEEK_CHECK_MS = 3_000L
    /** The longest a seek holds the clock against the page (both tries and their sends). */
    private const val SEEK_HOLD_MS = 2 * (SEEK_SEND_MS + SEEK_CHECK_MS)
    /** A page position this close to a seek's target (or past it by the time played) is the seek. */
    private const val SEEK_NEAR_MS = 2_000L
    private const val TAG = "MspPlayer"
    private const val LIKED_CONTEXT = "spotify:collection:tracks"
    /** A picked song from this row on is also sent by its place in the list (see [rowIndex]). */
    private const val INDEXED_ROW_FROM = 100
    /** The car's queue shows the current song and at most this many after it (see [publishCarQueue]). */
    private const val CAR_QUEUE_MAX = 50
    /** A burst of queue changes (a skip, a list loading) reaches the car once, this long after its last one. */
    private const val CAR_QUEUE_SETTLE_MS = 300L

    private val api: MyspotiApi get() = MyspotiRuntime.api
    private val scope get() = MyspotiRuntime.scope

    // ── Player state ──
    @Volatile private var playing = false
    private val bufferingState = mutableStateOf(false)
    /** Observable startup state: visual lookups wait for the audio transport. */
    val isBuffering: Boolean get() = bufferingState.value

    /**
     * An ad break is on (T4). The page publishes no track while one plays — the song before it
     * stays in the state, buffering — so the screens show this instead of that stale song.
     */
    private val adState = mutableStateOf(false)
    val adPlaying: Boolean get() = adState.value
    @Volatile private var durationMs = 0L
    @Volatile private var positionMs = 0L
    @Volatile private var positionAt = 0L
    /** The page says it plays, but nothing is heard (see [onSoundStalled]): the clock waits. */
    @Volatile private var soundStalled = false
    @Volatile var currentTrackId: String = ""
        private set
    @Volatile var currentContextUri: String = ""
        private set
    @Volatile private var stateSeen = false

    // A track the user just picked: the player reports the previous one for a moment,
    // which must not overwrite the optimistic now-playing state.
    @Volatile private var pendingTrackId: String? = null
    @Volatile private var pendingItemUri: String? = null
    @Volatile private var pendingUntil = 0L

    // After play / pause the player reports the old state for a moment; keep the requested one.
    @Volatile private var wantPlayingUntil = 0L
    @Volatile private var wantPausedUntil = 0L

    private fun intendPlaying() { wantPlayingUntil = SystemClock.elapsedRealtime() + 4000; wantPausedUntil = 0; reconcileAfter(intentEnded, 4000) }
    private fun intendPaused() { wantPausedUntil = SystemClock.elapsedRealtime() + 1500; wantPlayingUntil = 0; reconcileAfter(intentEnded, 1500) }

    /**
     * Puts the screen back on what the page last said once a hold is over (a play or pause
     * wanted, a song shown before it plays). The page pushes changes only, and a state read again
     * that did not change is no news either: a play the page never took left the clock counting
     * over silence, and a skip that never landed left the next song on screen while the old one
     * played on (reported).
     */
    private fun reconcile() {
        // A command still on its way: its own end puts the screen right (see [transport]).
        fun leftAlone() = !acceptsSessionUpdates() || LocalPlayer.active.value || transportsInFlight.get() > 0
        if (leftAlone()) return
        scope.launch {
            // Read again first: the page's last push can be lost on the way (its events buffer
            // drops the oldest when its main thread stalls), and the screen must not go back to
            // "paused" over a song that plays.
            kotlinx.coroutines.withTimeoutOrNull(RECONCILE_READ_MS) { runCatching { MyspotiRuntime.spotify.player.refresh() } }
            if (leftAlone()) return@launch
            val s = api.player.state.value
            if (s != null) { applyState(s); return@launch }
            // The page never reported anything (it did not load): nothing plays, whatever was tapped.
            if (playing) {
                playing = false
                bufferingState.value = false
                boundState?.updatePlayingState(false)
                pushNotification(null, boundState?.likeState?.value ?: false)
            }
        }
    }
    private val intentEnded = Runnable { reconcile() }
    private val pendingEnded = Runnable { reconcile() }
    private val commandSettled = Runnable { reconcile() }
    private fun reconcileAfter(check: Runnable, ms: Long) {
        main.removeCallbacks(check)
        main.postDelayed(check, ms.coerceAtLeast(0L) + RECONCILE_MARGIN_MS)
    }

    /**
     * Not heard yet: the page buffers, its sound stands still, or a play is wanted that the page
     * has not started. The clock waits and the screens show the song loading.
     */
    private fun waiting(s: PlayerState) = s.isBuffering || soundStalled || (playing && s.isPaused)

    /** Myspoti itself asked the engine to play lately (a pick, a play, a skip): not another device's doing. */
    fun engineIntended(): Boolean =
        SystemClock.elapsedRealtime() < wantPlayingUntil || pendingTrackId != null || resumeWhenReady

    private fun resolvePlaying(paused: Boolean): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (now < wantPlayingUntil) {
            if (!paused) wantPlayingUntil = 0
            return true
        }
        if (now < wantPausedUntil) {
            if (paused) wantPausedUntil = 0
            return false
        }
        return !paused
    }

    // Context (album/playlist/artist/liked) a track was listed in, so playing it keeps
    // Spotify's own queue and autoplay for that context.
    private val contextRegistry = ConcurrentHashMap<String, String>()

    /** Queue items of the local player (downloads, Local Files). */
    const val LOCAL = "local"

    /** Spotify's real queue. */
    data class QueueItem(val song: SongsModel, val uri: String, val uid: String, val provider: String)
    data class EngineQueue(
        val current: SongsModel? = null,
        val queued: List<QueueItem> = emptyList(),
        val nextUp: List<QueueItem> = emptyList(),
    )
    private val _queue = mutableStateOf(EngineQueue())
    private var apiQueue: app.myspoti.api.Queue? = null

    /** What the now-playing screen needs beyond the track itself. */
    data class NowPlaying(
        val contextUri: String = "",
        val contextName: String = "",
        val provider: String = "",
        val uri: String = "",
        val explicit: Boolean = false,
        val albumUri: String = "",
        val prev: SongsModel? = null,
        val next: SongsModel? = null,
    )
    private val _nowPlaying = mutableStateOf(NowPlaying())
    val nowPlaying: State<NowPlaying> get() = _nowPlaying
    val engineQueue: State<EngineQueue> get() = _queue
    /** The rows the car's queue was last given, after the current song: the row with id n is carQueue[n - 1]. */
    private var carQueue: List<QueueItem> = emptyList()

    private val main = Handler(Looper.getMainLooper())
    private var boundState: CurrentSongState? = null

    /** Wires the API's flows into the UI's now-playing state. Call once, on the main thread. */
    fun attachEngine(state: CurrentSongState) {
        boundState = state
        app.myspoti.host.android.PhoneCall.listener = ::phoneCall
        if (app.myspoti.host.android.PhoneCall.busy) refreshCallPolicy()
        com.music.spotui.data.api.LyricsApi.extraSources =
            com.music.spotui.data.preferences.isLyricsExtraSources(Graph.app)
        com.music.spotui.data.api.LyricsApi.extraSourcesOff =
            com.music.spotui.data.preferences.isLyricsExtraSourcesOff(Graph.app)
        com.music.spotui.data.api.LyricsApi.wordSync =
            com.music.spotui.data.preferences.isLyricsWordSync(Graph.app)
        restoreLastTrack(state)
        restoreRepeat(state)
        scope.launch { api.player.state.collect { s -> if (acceptsSessionUpdates()) applyState(s) } }
        AccountSync.attach()
        NativeAudio.attach()
        // Another device plays (the phone as a remote): the state is read again every few seconds
        // so the notification, the mini player and the slider keep up. Reported: the notification
        // stopped refreshing in the background — this loop waited for _activeDevice, which only a
        // pull-back sets, so an app started in the background never ran it.
        // This phone plays: the page pushes every change itself (it is not throttled while it plays, see
        // AwakeWebView), so reading the whole state and queue every 3 s only kept both processes
        // awake, screen off. It is read every LOCAL_REFRESH_MS as a safety net, and at once when
        // the song should have ended without the page saying what came next.
        // With nothing playing and no Connect device, the loop below only found it had nothing to do,
        // every 3 s, waking the main thread: it sleeps then, and a pushed state or a Connect device
        // wakes it (the long timeout is only a net against a missed wake).
        scope.launch { androidx.compose.runtime.snapshotFlow { _activeDevice.value }.collect { refreshWake.trySend(Unit) } }
        scope.launch {
            var lastRead = 0L
            while (true) {
                if (_activeDevice.value == null && !PlaybackService.isRunning && !playing && !isBuffering) {
                    kotlinx.coroutines.withTimeoutOrNull(IDLE_WAKE_MS) { refreshWake.receive() }
                    continue
                }
                kotlinx.coroutines.delay(REMOTE_REFRESH_MS)
                val remote = _activeDevice.value != null
                if (!remote && !PlaybackService.isRunning) continue
                // No page up (a music account other than Spotify loads it only when used): a read
                // here would load it for nothing.
                if (!MyspotiRuntime.spotify.ready.value) continue
                val now = SystemClock.elapsedRealtime()
                val overdue = playing && !isBuffering && durationMs > 0 &&
                    positionMs + (now - positionAt) > durationMs + SONG_END_GRACE_MS
                val every = when {
                    !remote -> LOCAL_REFRESH_MS
                    AppForeground.inForeground -> REMOTE_REFRESH_MS
                    else -> REMOTE_BACKGROUND_REFRESH_MS
                }
                if (!overdue && now - lastRead < every) continue
                lastRead = now
                // The queue only with a new song: it is tens of KB of JSON, and it moves with the song.
                runCatching { MyspotiRuntime.spotify.player.refreshState() }
            }
        }
        scope.launch { api.player.queue.collect { q -> if (acceptsSessionUpdates()) applyQueue(q) } }
        // Android Auto's queue follows the one on screen (Spotify's or the local player's), sent
        // only when it changes: the position reports never reach it.
        scope.launch {
            androidx.compose.runtime.snapshotFlow { _queue.value to _nowPlaying.value.contextName }.collectLatest { (q, name) ->
                kotlinx.coroutines.delay(CAR_QUEUE_SETTLE_MS)
                publishCarQueue(q, name)
            }
        }
        scope.launch { MyspotiRuntime.spotify.player.stalled.collect { on -> onSoundStalled(on) } }
        // Ads on a Connect device the music was sent to are muted there (#153).
        com.music.spotui.connect.RemoteAdMute.start()
        // Smart shuffle plays a mixed order as the list and leaves Spotify's own shuffle off, so
        // turning it off sends no shuffle command at all (the button finds shuffle already off):
        // the list's own order comes back here.
        scope.launch {
            var was = com.music.spotui.ui.screens.SmartShuffle.on.value
            androidx.compose.runtime.snapshotFlow { com.music.spotui.ui.screens.SmartShuffle.on.value }.collect { now ->
                val ended = was.takeIf { now == null }
                was = now
                if (ended != null) endSmartShuffle(ended)
            }
        }
        scope.launch { api.library.changes.collect { refreshCurrentLiked() } }
        scope.launch {
            api.ready.collect { ready ->
                if (!ready) return@collect
                likeCheckFailedAt.clear()
                refreshCurrentLiked()
                val retry = synchronized(pendingLibraryUris) {
                    if (pendingLibraryUris.isEmpty()) emptyList()
                    else pendingLibraryUris.toList().also { pendingLibraryUris.clear() }
                }
                if (retry.isNotEmpty()) {
                    retry.chunked(50).forEach { libraryContains(it) }
                }
            }
        }
        // T4: the player keeps the ad out of [api.player.state] on purpose (the last song stays
        // there, buffering); its own flag is collected here so the UI can say an ad is on. Only an
        // ad that is still on after AD_SHOW_AFTER_MS is shown: a blocked ad is gone within a second
        // (its audio is refused, the page moves on), and showing it only made the screens blink.
        scope.launch {
            // The local player plays (an extension's or a downloaded song): the ad is on the unheard page
            // that mirrors it, not what is heard. Shown, the song on screen became the ad and left the
            // notification until a restart (reported), also when that song began after the ad was shown.
            kotlinx.coroutines.flow.combine(
                MyspotiRuntime.spotify.player.adPlaying,
                androidx.compose.runtime.snapshotFlow { LocalPlayer.active.value },
            ) { ad, local -> ad && !local }.distinctUntilChanged().collectLatest { on ->
                if (on) {
                    kotlinx.coroutines.delay(AD_SHOW_AFTER_MS)
                    // Spotify limiting playback holds every repair, the ad's too: the limit is what
                    // the user is told (its toast), not an ad for as long as it lasts (50 s seen).
                    // The same when it refuses the account its licences (#134): the ad it is stuck on
                    // stays out of the screens, the toast said why nothing plays.
                    while (MyspotiRuntime.host.licenseLimited() || MyspotiRuntime.spotify.player.licencesHeld) kotlinx.coroutines.delay(1_000)
                }
                onAdPlaying(on)
            }
        }
        scope.launch {
            MyspotiRuntime.spotify.player.refused.collect {
                // No Widevine in this WebView: the refusal is the WebView's, not the account's.
                val message = if (MyspotiRuntime.spotify.player.drmMissing.value) app.myspoti.engine.R.string.drm_missing else app.myspoti.engine.R.string.play_refused
                android.widget.Toast.makeText(Graph.app, message, android.widget.Toast.LENGTH_LONG).show()
            }
        }
        scope.launch {
            MyspotiRuntime.spotify.player.refusedAll.collect {
                android.widget.Toast.makeText(Graph.app, app.myspoti.engine.R.string.play_refused_all, android.widget.Toast.LENGTH_LONG).show()
            }
        }
        scope.launch {
            MyspotiRuntime.spotify.player.skipChained.collect {
                android.widget.Toast.makeText(Graph.app, app.myspoti.engine.R.string.songs_skipped_by_spotify, android.widget.Toast.LENGTH_LONG).show()
            }
        }
        scope.launch {
            MyspotiRuntime.spotify.player.licencesRefused.collect {
                // A Widevine older than Spotify still accepts is the phone, not the account: waiting
                // or another account changes nothing, an extension's source does.
                val drm = app.myspoti.host.android.Widevine.version
                val text = if (app.myspoti.host.android.Widevine.tooOld(drm))
                    Graph.app.getString(app.myspoti.engine.R.string.licences_refused_old_widevine, drm?.substringBefore('@'))
                else Graph.app.getString(app.myspoti.engine.R.string.licences_refused_by_spotify)
                android.widget.Toast.makeText(Graph.app, text, android.widget.Toast.LENGTH_LONG).show()
            }
        }
        // Said once the page has asked its WebView: a device that cannot decrypt Spotify's streams
        // plays nothing (no sound, 0:00), and nothing else in the app says why.
        scope.launch {
            MyspotiRuntime.spotify.player.drmMissing.first { it }
            android.widget.Toast.makeText(Graph.app, app.myspoti.engine.R.string.drm_missing, android.widget.Toast.LENGTH_LONG).show()
        }
        scope.launch {
            MyspotiRuntime.host.licenseLimitedUntil.collect { until ->
                if (until > SystemClock.elapsedRealtime()) main.post {
                    playing = false
                    boundState?.updatePlayingState(false)
                    android.widget.Toast.makeText(Graph.app, app.myspoti.engine.R.string.spotify_limited, android.widget.Toast.LENGTH_LONG).show()
                }
            }
        }
        PlaybackService.controls = Controls
    }

    /** System controls (notification, headset, car) land here. */
    private object Controls : app.myspoti.host.android.PlaybackControls {
        // The session says the new state at once, not when the page answers: a Bluetooth headset or
        // stereo reads it (AVRCP play status) to choose between play and pause, and kept sending
        // "pause" to a paused player while the session still said playing (#108).
        override fun play() { SongPlayer.play(by = "media session"); pushNotification(null, boundState?.likeState?.value ?: false) }
        override fun pause() { SongPlayer.pause(by = "media session"); pushNotification(null, boundState?.likeState?.value ?: false) }
        override fun next() = SongPlayer.next(by = "media session")
        override fun previous() = SongPlayer.previous(by = "media session")
        override fun seekTo(ms: Long) = SongPlayer.seekTo(ms)
        override fun setLiked(liked: Boolean) = SongPlayer.setLiked(liked)
        override fun playFromMediaId(mediaId: String) = AutoBrowser.play(mediaId)
        override fun playFromSearch(query: String) { scope.launch { AutoBrowser.playFromSearch(query) } }
        override fun setRemoteVolume(volume: Int) = SongPlayer.setRemoteVolume(volume)
        override fun setShuffle(on: Boolean) = SongPlayer.setShuffle(on)
        override val isEpisode: Boolean get() = SongPlayer.isEpisode
        override fun skipBy(deltaMs: Long) {
            // Past the end of the episode a +15 s is the normal end: on to the next item.
            val duration = getDuration()
            if (deltaMs > 0 && duration > 0 && getCurrentPosition() + deltaMs >= duration) SongPlayer.next(by = "media session")
            else SongPlayer.skipBy(deltaMs)
        }
        // Row 0 is the song playing: a tap on it changes nothing.
        override fun skipToQueueItem(id: Long) { carQueue.getOrNull(id.toInt() - 1)?.let(SongPlayer::skipTo) }
    }

    // ── Last track: shown at launch (mini player) before the Web Player reports ──

    private fun lastTrackPrefs() = Graph.app.getSharedPreferences("myspoti_last_track", Context.MODE_PRIVATE)
    private var savedLast = ""
    // Who played the saved session and when it was saved: Spotify's state at launch is older than a
    // local-player (extension / download) session saved after it, and must not replace it.
    private var savedSource = com.music.spotui.data.preferences.LastSession.SOURCE_SPOTIFY
    private var savedAtMs = 0L
    /** A local-player session was put back paused at launch: play restarts it there, not through Spotify. */
    private var restoredLocal = false
    @Volatile private var resumeWhenReady = false

    private fun restoreLastTrack(state: CurrentSongState) {
        if (state.title.value.isNotBlank() || !acceptsSessionUpdates()) return
        val p = lastTrackPrefs()
        val uri = p.getString("uri", "").orEmpty()
        val title = p.getString("title", "").orEmpty()
        if (uri.isBlank() || title.isBlank()) return
        val id = trackIdOf(uri)
        currentTrackId = id
        savedSource = p.getString("source", null) ?: com.music.spotui.data.preferences.LastSession.SOURCE_SPOTIFY
        savedAtMs = p.getLong("savedAt", 0L)
        restoredLocal = savedSource == com.music.spotui.data.preferences.LastSession.SOURCE_LOCAL
        durationMs = p.getLong("duration", 0L)
        positionMs = p.getLong("position", 0L)
        positionAt = SystemClock.elapsedRealtime()
        playing = false
        // The list it was played in, with its name and queue: a resume through the extensions plays
        // the song in it (alone, the list was lost at every launch).
        val contextUri = p.getString("contextUri", "").orEmpty()
        val contextName = p.getString("contextName", "").orEmpty()
        registerContextName(contextUri, contextName)
        currentContextUri = contextUri
        _nowPlaying.value = NowPlaying(uri = uri, contextUri = contextUri, contextName = contextName)
        state.updateSongState(
            coverUri = p.getString("cover", "").orEmpty(),
            title = title,
            singer = p.getString("singer", "").orEmpty(),
            playingState = false,
            songId = songIdFor(id, uri),
            songIndex = 0,
            album = p.getString("album", "").orEmpty(),
        )
        state.likeState.value = p.getBoolean("liked", false)
        // The media session has the last song, paused, before anything plays: a car or a Bluetooth
        // stereo that binds first (after the app was killed too) shows it and can resume it (#142).
        PlaybackService.update(Graph.app, NowPlayingInfo(
            id = uri, title = title, artist = p.getString("singer", "").orEmpty(), album = p.getString("album", "").orEmpty(),
            coverUrl = p.getString("cover", "").orEmpty().ifBlank { null }, durationMs = durationMs, positionMs = positionMs,
            playing = false, liked = state.likeState.value, shuffle = state.shuffle.value == true,
            episode = uri.startsWith("spotify:episode:"),
        ))
        // Spotify's own queue too: the page's replaces it once it reports.
        val rest = com.music.spotui.data.preferences.LastSession.decodeQueue(p.getString("queue", null))
        if (rest.isNotEmpty()) {
            restoredQueuePending = true
            _queue.value = EngineQueue(
                current = rest.first(),
                nextUp = rest.drop(1).map { QueueItem(it, SPOTIFY_TRACK_PREFIX + it.spotifyTrackId, "", "") },
            )
        }
    }

    /** Saved on track change and on play/pause (not on every state). */
    private fun saveLastTrack(
        song: SongsModel, uri: String, liked: Boolean, contextUri: String, contextName: String,
        source: String = com.music.spotui.data.preferences.LastSession.SOURCE_SPOTIFY, queue: List<SongsModel>? = null,
    ) {
        val key = "$uri|$playing|$liked|$source|$contextUri"
        if (uri.isBlank() || key == savedLast) return
        savedLast = key
        savedSource = source; savedAtMs = System.currentTimeMillis(); restoredLocal = false
        val p = lastTrackPrefs()
        // No queue known yet for this song: the one saved with it stays (a pause, a like), another song's goes.
        val kept = if (queue.isNullOrEmpty() && p.getString("uri", "") == uri) p.getString("queue", "").orEmpty() else null
        p.edit()
            .putString("source", source).putLong("savedAt", savedAtMs)
            .putString("queue", kept ?: queue?.let(com.music.spotui.data.preferences.LastSession::encodeQueue).orEmpty())
            .putString("contextUri", contextUri).putString("contextName", contextName)
            .putString("uri", uri).putString("title", song.title).putString("singer", song.singer)
            .putString("album", song.album).putString("cover", song.coverUri)
            .putLong("duration", durationMs).putLong("position", getCurrentPosition())
            .putBoolean("liked", liked)
            .apply()
    }

    /**
     * The saved session's position kept current while a song plays (every [POSITION_SAVE_MS]): saved on
     * track changes and play/pause only, an app closed mid-song resumed it from its start (reported
     * with an extension's song after a relaunch).
     */
    private val savePosition = object : Runnable {
        override fun run() {
            // Nothing plays: a look now and then for a song that started, not a wake every ten seconds.
            val on = playing || LocalPlayer.isPlaying()
            main.postDelayed(this, if (on) POSITION_SAVE_MS else POSITION_IDLE_MS)
            if (!on) return
            val p = lastTrackPrefs()
            val uri = p.getString("uri", "").orEmpty()
            val now = if (LocalPlayer.active.value) localSpotifyUri(LocalPlayer.current()) else _nowPlaying.value.uri
            if (uri.isBlank() || uri != now) return
            p.edit().putLong("position", getCurrentPosition()).apply()
        }
    }
    init { main.postDelayed(savePosition, POSITION_SAVE_MS) }

    private fun acceptsSessionUpdates() = Graph.app.getSharedPreferences("myspoti_prefs", Context.MODE_PRIVATE)
        .getBoolean("LoggedIn", false)

    /** Call on the main thread before navigating to logout. */
    fun clearSession() {
        main.removeCallbacksAndMessages(null)
        invalidateHandoff()
        // A play, pause or skip still waiting (a slow page, a page still loading) belongs to the
        // session that ends: it is dropped, not sent once the next account's page is ready.
        sessionGen.incrementAndGet()
        routeAsk.incrementAndGet(); routingState.value = null; routingSongs = null
        transportGen.incrementAndGet()
        runningTransport?.cancel()
        pendingTrackId = null
        pendingItemUri = null
        pendingUntil = 0L
        intentUri = ""; intentUntil = 0L
        wantPlayingUntil = 0L; wantPausedUntil = 0L
        // Its own end puts nothing back on screen: the seq it ends with is no longer the last.
        seekSeq++; seekJob?.cancel(); seekUntil = 0L; seekUri = ""
        stateSeen = false
        playing = false; bufferingState.value = false; adState.value = false; durationMs = 0L; positionMs = 0L
        currentTrackId = ""; currentContextUri = ""
        contextRegistry.clear(); contextRows.clear(); contextNames.clear(); library.clear()
        synchronized(wantedSaved) { wantedSaved.clear() }
        _queue.value = EngineQueue(); apiQueue = null; restoredQueuePending = false; _nowPlaying.value = NowPlaying()
        lastTrackPrefs().edit().clear().apply(); savedLast = ""; resumeWhenReady = false
        savedSource = com.music.spotui.data.preferences.LastSession.SOURCE_SPOTIFY; savedAtMs = 0L; restoredLocal = false
        _activeDevice.value = null; if (MyspotiRuntime.isStarted) MyspotiRuntime.spotify.player.remoteControl = false; _sleepEndsAt.value = null; sleepFade?.cancel(); main.removeCallbacks(sleepFadeRunnable); sleepTrackId = null; spotifyFallbackId = null
        // The Connect device picked was the account's that leaves: the next one starts on this phone.
        chosenRemote = null
        boundState?.let { state ->
            state.updateQueue(emptyList())
            state.updateSongState("", "", "", false, 0, 0, "")
            state.likeState.value = false
        }
    }

    private fun trackIdOf(uri: String) = uri.removePrefix(SPOTIFY_TRACK_PREFIX).takeIf { uri.startsWith(SPOTIFY_TRACK_PREFIX) }.orEmpty()

    private fun songIdFor(trackId: String, fallback: String) =
        (if (trackId.isNotBlank()) "track:$trackId" else "uri:$fallback").hashCode() and 0x7fffffff

    internal fun songOf(n: app.myspoti.api.NowPlaying): SongsModel {
        val id = trackIdOf(n.uri)
        val artists = n.artists.joinToString(", ") { it.name }
        return SongsModel(
            id = songIdFor(id, n.uri),
            title = n.name,
            album = n.album?.name.orEmpty(),
            singer = artists,
            coverUri = n.imageUrl.orEmpty(),
            url = if (n.kind == ItemKind.EPISODE) "episode:" + n.uri.substringAfterLast(':') else buildSpotifyPlayQuery(id, n.name, artists),
            spotifyTrackId = id,
            explicit = n.explicit,
            durationMs = n.durationMs.toInt(),
            albumId = n.album?.uri?.substringAfterLast(':').orEmpty(),
        )
    }

    /**
     * The page says it plays but its sound stands still (a slow network), or plays again. The page's
     * own clock goes on over the silence (reported: "the time was counting, the song not playing"):
     * the screen's clock stops where it is and goes on from there once the sound does.
     */
    private fun onSoundStalled(on: Boolean) {
        if (on == soundStalled) return
        // Read before the flag changes: the running clock as it stands, or the held one.
        positionMs = getCurrentPosition()
        positionAt = SystemClock.elapsedRealtime()
        soundStalled = on
        // A song shown before the page plays it is waiting already (see [markPending]).
        if (LocalPlayer.active.value || pendingTrackId != null) return
        val s = api.player.state.value ?: return
        bufferingState.value = waiting(s)
        pushNotification(null, boundState?.likeState?.value ?: false)
        com.music.spotui.video.MusicVideoController.onAudioBuffering(isBuffering, currentTrackId)
    }

    /** An ad break starts or ends: the notification, the widget and the screens follow (T4). */
    private fun onAdPlaying(on: Boolean) {
        if (adState.value == on) return
        adState.value = on
        pushNotification(null, boundState?.likeState?.value ?: false)
    }

    /**
     * What plays comes over the network as it plays (the service's Wi-Fi lock is for that): the
     * account's page, an extension's stream, a radio; not a file of the phone nor a download.
     */
    private fun streamedNow(): Boolean {
        if (!LocalPlayer.active.value) return true
        val scheme = LocalPlayer.current()?.uri?.scheme ?: return false
        return scheme == com.music.spotui.extensions.ExtensionAudio.SCHEME || scheme == "http" || scheme == "https"
    }

    /** Wakes the refresh loop of [attachEngine] when it sleeps: a state was pushed, or a Connect device took over. */
    private val refreshWake = kotlinx.coroutines.channels.Channel<Unit>(kotlinx.coroutines.channels.Channel.CONFLATED)

    /** Notification, lock screen, Bluetooth and Android Auto. */
    private fun pushNotification(song: SongsModel?, liked: Boolean) {
        refreshWake.trySend(Unit)
        val st = boundState
        // T4: during an ad break the page reports no track (the song before it would sit there,
        // buffering), so the notification and the widget say an ad is on instead of that song.
        val ad = adState.value
        val title = if (ad) Graph.app.getString(app.myspoti.engine.R.string.ad_playing) else song?.title ?: st?.title?.value.orEmpty()
        val artist = if (ad) "" else song?.singer ?: st?.singer?.value.orEmpty()
        val cover = if (ad) null else song?.coverUri ?: st?.coverUri?.value
        PlaybackService.update(Graph.app, NowPlayingInfo(
            id = if (ad) "spotify:ad" else _nowPlaying.value.uri,
            title = title,
            artist = artist,
            album = if (ad) "" else song?.album ?: st?.album?.value.orEmpty(),
            coverUrl = cover,
            durationMs = if (ad) 0L else getDuration(),
            positionMs = if (ad) 0L else getCurrentPosition(),
            playing = isPlaying() && !ad,
            buffering = isBuffering && !ad,
            liked = !ad && liked,
            // The car and the lock screen flip what they read here: the local queue's own on an
            // extension's song, or their shuffle button could only ever turn it on (reported).
            shuffle = isShuffleOn(),
            episode = !ad && isEpisode,
            streamed = streamedNow(),
            speed = when {
                ad -> 1f
                LocalPlayer.active.value && !routing -> LocalPlayer.rate()
                isEpisode -> _speed.value.toFloat().coerceIn(0.5f, 3.5f)
                else -> 1f
            },
        ))
        com.music.spotui.widget.NowPlayingWidget.show(Graph.app,
            title = title,
            artist = artist,
            coverUrl = cover,
            playing = isPlaying() && !ad)
    }

    /** The hidden songs ("Not interested") skipped in a row; one met twice means the list holds nothing else. */
    private val hiddenSkipped = mutableSetOf<String>()
    /** The hidden song the user asked for by hand: it plays, it is not skipped. */
    private var playedByHand = ""

    /**
     * A hidden song the player moved on to by itself (the list, the radio, the queue, a skip) is
     * skipped. Songs picked by hand play; a run of skips ends at the first song met twice, or at
     * [HIDDEN_SKIPS_MAX], and that song then plays.
     */
    private fun skipHidden(id: String, uri: String) {
        val byHand = uri == playedByHand
        if (!byHand) playedByHand = ""
        if (byHand || !com.music.spotui.data.preferences.HiddenSongs.isHidden(id)) { hiddenSkipped.clear(); return }
        if (!hiddenSkipped.add(id) || hiddenSkipped.size > HIDDEN_SKIPS_MAX) {
            AppLog.d("hidden: only hidden songs left, $id plays")
            hiddenSkipped.clear(); playedByHand = uri
            return
        }
        AppLog.d("hidden: $id skipped (not interested)")
        main.post { if (_nowPlaying.value.uri == uri && !LocalPlayer.active.value) next(by = "hidden song") }
    }

    private const val HIDDEN_SKIPS_MAX = 30

    /**
     * "Not interested": the song is kept in a list on this phone (nothing goes to Spotify), taken
     * out of the queue, and skipped if it plays now. From then on lists skip it ([skipHidden]).
     */
    fun hideSong(song: SongsModel) {
        val id = song.spotifyTrackId
        if (id.isBlank()) return
        com.music.spotui.data.preferences.HiddenSongs.hide(Graph.app, song)
        Haptics.confirm()
        _queue.value.let { it.queued + it.nextUp }.filter { it.provider != LOCAL && it.uri == SPOTIFY_TRACK_PREFIX + id }.forEach(::removeFromQueue)
        LocalPlayer.upcoming().filter { LocalPlayer.spotifyIdOf(it.second) == id }.map { it.first }.sortedDescending().forEach(LocalPlayer::remove)
        val playingNow = if (LocalPlayer.active.value) LocalPlayer.current()?.let(LocalPlayer::spotifyIdOf) == id else trackIdOf(_nowPlaying.value.uri) == id
        if (playingNow) next(by = "not interested")
    }

    /** The autoplay item already paused on, so it is paused once, not on every state. */
    private var autoplayHandledUri = ""

    private fun applyState(s: PlayerState?) {
        if (s == null) return
        stateSeen = true
        if (LocalPlayer.active.value && engineWhileLocal(s)) return
        // The watch's song, played unheard by the listen sync: the page's states are the sync's (on
        // the native engine, the sync reads the engine's own: the page's are left).
        if (AccountSync.watchActive && AccountSync.holdsSpotify) { if (AccountSync.holdsSpotifyPage) AccountSync.listen.onProviderState(s); return }
        // Spotify's server still shows the song played before the local-player session saved at exit.
        if (com.music.spotui.data.preferences.LastSession.engineStateIsStale(savedSource, savedAtMs, s.timestampMs, s.isPaused)) return
        if (s.item != null && !s.isPaused) restoredQueuePending = false
        if (resumeWhenReady) {
            resumeWhenReady = false
            // The Web Player restored the last session paused: play what was tapped.
            if (s.isPaused) transport { api.player.resume() }
        }
        val item = s.item
        val uri = item?.uri.orEmpty()
        if (uri.isNotEmpty()) lastPageUri = uri
        // The song the extensions are asked for shows meanwhile, not what the engine paused on.
        if (routing && !LocalPlayer.active.value) return
        val id = trackIdOf(uri)
        val wasIntended = engineIntended()
        val pending = pendingTrackId
        if (pending != null) {
            // Rapid A -> B -> C picks can report B while C is pending: keep C until it shows up.
            if (id == pending || pendingItemUri == uri || SystemClock.elapsedRealtime() > pendingUntil) {
                pendingTrackId = null
                pendingItemUri = null
            } else return
        }
        val wasPlaying = playing
        val wasBuffering = isBuffering
        val predicted = getCurrentPosition()
        playing = resolvePlaying(s.isPaused)
        bufferingState.value = waiting(s)
        SpeakerKeepAlive.set(playing && _activeDevice.value == null)
        val lengthBefore = durationMs
        durationMs = item?.durationMs ?: 0L
        // The engine's own position when it is what plays: the account's player lays it over the page's (EngineStates).
        val reported = s.positionAt(System.currentTimeMillis())
        // A seek on its way: the page's old position does not take the clock back (see [seekTo]).
        if (seekHeld(uri) && seekLanded(s)) seekUntil = 0L
        val seeking = seekHeld(uri)
        // Keep the running clock when the player only nudges it (< 1 s).
        if (!seeking && !(wasPlaying && playing && !wasBuffering && !isBuffering && kotlin.math.abs(reported - predicted) < 1000)) {
            positionMs = reported
            positionAt = SystemClock.elapsedRealtime()
        }
        val leftId = trackIdOf(_nowPlaying.value.uri)
        val trackChanged = uri != _nowPlaying.value.uri
        // Repeat once on a Spotify song: the page's repeat-track loops for good. The page seen
        // starting the song again is its one replay: repeat goes off there, and that replay ends
        // into the next song. Another song under repeat-track (a skip, a pick) cancels it.
        if (item != null && s.repeat == Repeat.TRACK && _repeatMode.value == LocalRepeat.ONCE) {
            if (LocalRepeat.pageRestarted(!trackChanged, predicted, lengthBefore, reported)) {
                AppLog.d("repeat once: ${item.name} replayed, back to off")
                setRepeatMode(LocalRepeat.OFF)
            } else if (trackChanged && _nowPlaying.value.uri.isNotBlank() && !seeking) {
                AppLog.d("repeat once: cancelled (${item.name} plays now), back to off")
                setRepeatMode(LocalRepeat.OFF)
            }
        }
        // Autoplay off: stop once, when the player moves on to a track it picked itself.
        // Tracks only: this is the music setting (similar songs). An episode the page rolls on
        // to after the previous one belongs to the show, not to that recommendation autoplay —
        // pausing it there is how a podcast "stopped by itself" (B11).
        if (item != null && item.provider == "autoplay" && uri.startsWith(SPOTIFY_TRACK_PREFIX) &&
            !com.music.spotui.data.preferences.AutoplayPref.on) {
            if (!s.isPaused && uri != autoplayHandledUri) {
                autoplayHandledUri = uri
                pauseSilently()
            }
        } else if (item?.provider != "autoplay") {
            autoplayHandledUri = ""
        }
        if (item != null && trackChanged && playing && !adState.value && uri.startsWith(SPOTIFY_TRACK_PREFIX)) skipHidden(id, uri)
        currentContextUri = s.contextUri.orEmpty()
        if (item != null) { checkEndOfTrackTimer(id); currentTrackId = id }
        if (_abLoop.value.trackUri.isNotBlank() && uri.isNotBlank() && uri != _abLoop.value.trackUri) clearAbLoop()
        _nowPlaying.value = NowPlaying(
            contextUri = s.contextUri.orEmpty(),
            contextName = s.contextName.orEmpty(),
            provider = item?.provider.orEmpty(),
            uri = uri,
            explicit = item?.explicit == true,
            albumUri = item?.album?.uri.orEmpty(),
            prev = s.previous?.let(::songOf),
            next = s.next?.let(::songOf),
        )
        // Started or moved on without Myspoti asking (another device, a transfer back here): the
        // listen sync sends it back through the extensions. After this state's own follow-ups.
        val moved = trackChanged || (!wasPlaying && playing)
        if (moved || AccountSync.listen.waitsBack) {
            val intended = wasIntended || engineIntended()
            main.post { if (!LocalPlayer.active.value && !routing) AccountSync.listen.onProviderPlayback(s, moved, intended) }
        }
        if (MixedPlaylistQueue.active && !LocalPlayer.active.value) {
            main.post {
                MixedPlaylistQueue.onSpotifyState(
                    uri = uri,
                    trackId = id,
                    provider = item?.provider.orEmpty(),
                    isPaused = s.isPaused,
                    wasPlaying = wasPlaying,
                    positionMs = reported,
                    predictedMs = predicted,
                    durationMs = lengthBefore.takeIf { it > 0L } ?: durationMs,
                )
            }
        }
        // A resume Spotify took because another device played (see resumeThroughExtensions): the
        // song now plays on this phone, so the extensions play it, from where it is.
        resumeAfterPull?.let { (pulledId, at) ->
            when {
                SystemClock.elapsedRealtime() - at > RESUME_AFTER_PULL_MS -> resumeAfterPull = null
                !s.isPaused && !s.isBuffering && trackIdOf(uri) == pulledId && _activeDevice.value == null -> {
                    resumeAfterPull = null
                    main.post {
                        if (LocalPlayer.active.value || routing || _activeDevice.value != null) return@post
                        AppLog.d("audio: $pulledId pulled back to this phone: the extensions play it again")
                        resumeThroughExtensions()
                    }
                }
            }
        }
        val state = boundState ?: return
        val holding = SystemClock.elapsedRealtime() < shuffleWantedUntil
        if (holding && s.shuffle == shuffleWanted) shuffleWantedUntil = 0L
        // Myspoti's shuffle plays the list in its own order with Spotify's off: shown on.
        val trusted = !holding || s.shuffle == shuffleWanted
        val dealt = AppShuffle.onPage(s.contextUri.orEmpty(), uri, s.shuffle, trusted)
        if (trusted) state.shuffle.value = s.shuffle || dealt
        val reportedSpeed = s.speed.takeIf { it > 0.0 } ?: 1.0
        val epNow = uri.startsWith("spotify:episode:")
        if (epNow && lastAppliedEpisodeSpeedUri != uri) {
            lastAppliedEpisodeSpeedUri = uri
            val savedEpSpeed = loadSavedPodcastSpeed()
            if (kotlin.math.abs(savedEpSpeed - 1.0) >= 0.02 && kotlin.math.abs(reportedSpeed - savedEpSpeed) >= 0.02) {
                _speed.value = savedEpSpeed
                speedWanted = savedEpSpeed
                speedWantedUntil = SystemClock.elapsedRealtime() + 4_000L
                LocalPlayer.setEpisodeSpeed(savedEpSpeed.toFloat())
                command { api.player.setSpeed(savedEpSpeed) }
            } else {
                _speed.value = reportedSpeed
            }
        } else if (!epNow) {
            lastAppliedEpisodeSpeedUri = ""
            _speed.value = 1.0
        } else {
            val speedHeld = SystemClock.elapsedRealtime() < speedWantedUntil
            if (speedHeld && kotlin.math.abs(reportedSpeed - speedWanted) < 0.02) speedWantedUntil = 0L
            if (!speedHeld) _speed.value = reportedSpeed
        }
        // A song from an extension keeps its own repeat: the muted Spotify copy that counts it
        // reports repeat off and turned the button back off right after a tap (reported: loop
        // button does nothing). A tap on a Spotify song is held until the page shows it.
        val repeatHeld = SystemClock.elapsedRealtime() < repeatWantedUntil
        if (repeatHeld && s.repeat.ordinal == repeatWanted) repeatWantedUntil = 0L
        if (!LocalPlayer.active.value && (!repeatHeld || s.repeat.ordinal == repeatWanted)) {
            // Repeat once is the page's repeat-track too: the page reporting it does not turn once into for good.
            if (!(s.repeat == Repeat.TRACK && _repeatMode.value == LocalRepeat.ONCE)) _repeatMode.value = s.repeat.ordinal
            state.repeat.value = s.repeat != Repeat.OFF
        }
        if (item == null) {
            state.updatePlayingState(playing)
            pushNotification(null, state.likeState.value)
            return
        }
        val liked = likedFor(uri, library[uri] ?: false)
        state.likeState.value = liked
        val song = songOf(item)
        state.updateSongState(
            coverUri = song.coverUri,
            title = song.title,
            singer = song.singer,
            playingState = playing,
            songId = song.id,
            songIndex = state.queue.value.indexOfFirst { it.id == song.id }.coerceAtLeast(0),
            album = song.album,
        )
        pushNotification(song, liked)
        saveLastTrack(song, uri, liked, s.contextUri.orEmpty(), s.contextName.orEmpty(), queue = spotifyQueueOf(id))
        trackListen(uri, song, com.music.spotui.data.local.ListenHistory.Source.SPOTIFY, playing)
        // A song never asked about (the one restored at launch is not a change): its state is asked
        // once, not read as "not liked" until the next song. A failed ask is not repeated by every state.
        if (!trackChanged && library[uri] == null) refreshCurrentLiked(fromState = true)
        if (trackChanged) {
            refreshCurrentLiked()
            refreshDevice()
            // The engine moved on by itself from a song no extension had: the new one is asked there.
            if (playing && !adState.value) main.post {
                if (_nowPlaying.value.uri == uri) backToExtensions(song, leftId, upcomingSongs(song), spotifyFirst = false) { intendPlaying(); playing = true; transport { api.player.resume() } }
            }
        }
        val mv = com.music.spotui.video.MusicVideoController
        mv.onAudioBuffering(isBuffering, song.spotifyTrackId)
        // Clips are shown by the Classic player only: under the Immersive look no clip is looked up.
        val clipsShown = com.music.spotui.data.preferences.LookPref.look == com.music.spotui.data.preferences.Look.CLASSIC
        // Clip lookup only where it can pay off: video wanted, or the player screen
        // is up (toggle then is instant). Looking up every track by default cost
        // searches and full-audio alignment downloads for users who never watch.
        if (clipsShown && !isBuffering && playing && mv.inForeground && (mv.wantVideo || mv.hasPlayerScreen) && song.spotifyTrackId.isNotBlank())
            com.music.spotui.video.MusicVideoController.prepare(song.spotifyTrackId, song.title, song.singer, durationMs)
        val lookups = app.myspoti.power.EnergySettings.state.value.policy.allowBackgroundLookups
        // Lyrics are warmed in the background too (the next song's are there when it starts), but not on a metered network.
        if (!isBuffering && playing && lookups && (mv.inForeground || !com.music.spotui.data.DataSaver.metered)) {
            // The next song's once the playing one's are found: an extension answers one call at a time.
            com.music.spotui.data.api.LyricsApi.prefetch(lyricsTrack(song), then = _nowPlaying.value.next?.let { lyricsTrack(it) })
        }
        if (!isBuffering && playing && mv.inForeground && lookups) {
            // The next song's clip is looked up now, so its button is there when it starts. The
            // controller itself stays off under the data saver; a Spotify limit holds it too, as
            // it holds every other request. Only for someone who has the player open or wants
            // the clip: a lookup downloads ~145 s of audio, too much data and battery to spend on
            // every song for a user who never looks at the player.
            if (clipsShown && (mv.wantVideo || mv.hasPlayerScreen) && !MyspotiRuntime.host.licenseLimited()) _nowPlaying.value.next?.takeIf { it.spotifyTrackId.isNotBlank() && it.durationMs > 0 }?.let {
                // Without the song's length the match could not be checked, so nothing is cached for it.
                mv.prefetch(it.spotifyTrackId, it.title, it.singer, it.durationMs.toLong())
            }
        }
    }

    /** Songs whose saved state is being asked for by [refreshCurrentLiked] (one check in flight per song). */
    private val likeChecking = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    /** When a check of each song got no answer (even after its retry): states do not start another for a while. */
    private val likeCheckFailedAt = java.util.concurrent.ConcurrentHashMap<String, Long>()
    /** The last line [refreshCurrentLiked] logged, so the same answer for the same song is logged once. */
    @Volatile private var lastLikeLog = ""

    /**
     * Asks Spotify whether the song shown is liked (a state it confirmed less than [SAVED_FRESH_MS]
     * ago is not asked for again). [fromState]: called because the page state shows a song with no
     * answer yet, so a song whose check just failed waits [LIKE_RETRY_AFTER_MS] before the next one.
     * An answer that never comes leaves the heart as it is: no "not liked" is written for it.
     */
    private fun refreshCurrentLiked(fromState: Boolean = false) {
        val uri = currentLikeUri().takeIf { it.startsWith(SPOTIFY_TRACK_PREFIX) || it.startsWith("spotify:episode:") } ?: return
        if (fromState && SystemClock.elapsedRealtime() - (likeCheckFailedAt[uri] ?: -LIKE_RETRY_AFTER_MS) < LIKE_RETRY_AFTER_MS) return
        if (!likeChecking.add(uri)) return
        scope.launch {
            try {
                // Through the shared, cached request path: a state Spotify confirmed less than
                // [SAVED_FRESH_MS] ago is not asked for again (its row asked for it already).
                var check = checkLibrary(listOf(uri))
                if (check.failed) {
                    // The page was not ready, or the request was lost: once more, for this song only.
                    kotlinx.coroutines.delay(LIKE_RETRY_MS)
                    if (currentLikeUri() == uri) check = checkLibrary(listOf(uri))
                }
                val answer = when {
                    check.failed -> "failed, from Spotify, song $uri, reason ${savedError.ifBlank { "no answer" }}"
                    uri in check.asked -> "${if (uri in check.saved) "liked" else "not liked"}, from Spotify, song $uri"
                    else -> "${if (uri in check.saved) "liked" else "not liked"}, from memory, song $uri"
                }
                val line = "liked check: answer $answer"
                if (line != lastLikeLog) { lastLikeLog = line; AppLog.d(line) }
                if (check.failed) { likeCheckFailedAt[uri] = SystemClock.elapsedRealtime(); return@launch }
                likeCheckFailedAt.remove(uri)
                if (uri in check.asked) onLibraryItem(uri, uri in check.saved)
            } finally {
                likeChecking.remove(uri)
            }
        }
    }

    /** The app is on screen again, or a player opens: the song shown is asked for if its state is old (see [SAVED_FRESH_MS]). */
    fun refreshLikedIfStale() = refreshCurrentLiked()

    /** Back from the local player: the page is heard again if a mirror (an extension's, or the listen sync) had muted it. */
    fun unmuteMirror() {
        com.music.spotui.extensions.Extensions.mirrorReset("the local player stopped")
        // The listen sync unmutes the page itself, after pausing the song it played there.
        if (!AccountSync.listen.stop("the local player stopped")) unmuteMirrorNow()
    }

    /** The page heard again, unless the listen sync holds it (an extension's mirror ending must not unmute it then). */
    fun unmuteMirrorNow() { if (api.player.localMute && !AccountSync.holdsSpotifyPage) command { api.player.setLocalMute(false) } }

    /** The local player's state for the mirror guard: playing, track uri, duration. */
    fun localSnapshot3(): Triple<Boolean, String?, Long> =
        Triple(LocalPlayer.active.value && playing, _nowPlaying.value.uri.takeIf { LocalPlayer.active.value }, durationMs)
    fun localSnapshot(): Pair<Boolean, String?> = localSnapshot3().let { it.first to it.second }

    internal fun publishMixedQueue() = main.post { MixedPlaylistQueue.toEngineQueue()?.let { _queue.value = it } }

    /** Back from the local player: the Spotify queue again. */
    fun restoreEngineQueue() = main.post {
        if (MixedPlaylistQueue.active) {
            MixedPlaylistQueue.toEngineQueue()?.let { _queue.value = it }
            return@post
        }
        _queue.value = EngineQueue()
        applyQueue(apiQueue)
    }

    /**
     * The queue saved at the last exit is on screen and nothing has played since: an empty queue
     * from Spotify (its session ended while the app was away, after a while) does not wipe it
     * (#240: "when the app is opened after a while the entire queue is reset").
     */
    @Volatile private var restoredQueuePending = false

    private fun applyQueue(q: app.myspoti.api.Queue?) {
        apiQueue = q
        if (MixedPlaylistQueue.active) {
            MixedPlaylistQueue.toEngineQueue()?.let { _queue.value = it }
            return
        }
        if (restoredQueuePending && q != null && q.current == null && q.queued.isEmpty() && q.nextUp.isEmpty()) return
        // While a downloaded or local file plays, the queue shown is the local player's.
        if (q == null || LocalPlayer.active.value) return
        // A move is under way: its steps are not shown, the order dropped stays (see [queueMove]).
        if (queueMovesInFlight.get() > 0) return
        if (SystemClock.elapsedRealtime() < staleUntil && order(q) in staleOrders) return
        fun items(list: List<app.myspoti.api.NowPlaying>) = list
            .filter { it.uri.startsWith("spotify:track:") || it.uri.startsWith("spotify:episode:") }
            .map { QueueItem(songOf(it), it.uri, it.uid.orEmpty(), "") }
        _queue.value = EngineQueue(
            current = q.current?.let(::songOf),
            queued = items(q.queued),
            nextUp = items(q.nextUp),
        )
        saveSpotifyQueue()
    }

    /** The page's queue from the song [id] on, for the saved session (see [saveLastTrack]). */
    private fun spotifyQueueOf(id: String): List<SongsModel> {
        val q = _queue.value
        if (LocalPlayer.active.value || id.isBlank()) return emptyList()
        return com.music.spotui.data.preferences.LastSession.queueFor(id, listOfNotNull(q.current) + (q.queued + q.nextUp).map { it.song })
    }

    /** The queue arrives after the song's state: it is saved with the song once it is there. */
    private fun saveSpotifyQueue() {
        val uri = _nowPlaying.value.uri
        val queue = spotifyQueueOf(trackIdOf(uri)).ifEmpty { return }
        val p = lastTrackPrefs()
        if (savedSource != com.music.spotui.data.preferences.LastSession.SOURCE_SPOTIFY || p.getString("uri", "") != uri) return
        val encoded = com.music.spotui.data.preferences.LastSession.encodeQueue(queue)
        if (p.getString("queue", "") != encoded) p.edit().putString("queue", encoded).apply()
    }

    /**
     * The car's queue: the current song as row 0, then the queued and next songs, capped at
     * [CAR_QUEUE_MAX]. A row's id is its place, which [Controls.skipToQueueItem] maps back through
     * [carQueue] (a uid is empty for some rows, and a local row's is an index that moves).
     */
    private fun publishCarQueue(q: EngineQueue, contextName: String) {
        val rows = (q.queued + q.nextUp).take(CAR_QUEUE_MAX)
        carQueue = rows
        fun entry(id: Long, s: SongsModel) = app.myspoti.host.android.QueueEntry(id, s.title, s.singer, ArtworkProvider.uriFor(s.coverUri)?.toString())
        val entries = listOfNotNull(q.current?.let { entry(0L, it) }) + rows.mapIndexed { i, item -> entry(i + 1L, item.song) }
        PlaybackService.updateQueue(
            title = contextName.ifBlank { Graph.app.getString(app.myspoti.engine.R.string.next_up) },
            items = entries,
            activeId = if (q.current != null) 0L else null,
        )
    }

    // ── Listen history (in-app recap) ──
    private var listenKey = ""
    private var listenSong: SongsModel? = null
    private var listenSource = com.music.spotui.data.local.ListenHistory.Source.SPOTIFY
    private var listenPlayedMs = 0L
    private var listenTickAt = 0L
    private var listenWasPlaying = false

    /** Adds the time played since the last call; a new [key] closes the previous listen. */
    private fun trackListen(key: String, song: SongsModel?, source: com.music.spotui.data.local.ListenHistory.Source, isPlaying: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (listenWasPlaying && listenTickAt > 0) listenPlayedMs += now - listenTickAt
        if (key != listenKey) {
            listenSong?.let { s ->
                com.music.spotui.data.local.ListenHistory.record(com.music.spotui.data.local.ListenHistory.Listen(
                    System.currentTimeMillis(), listenKey, s.title, s.singer, s.album, s.coverUri, listenPlayedMs, listenSource,
                    com.music.spotui.data.local.ListenHistory.artistsOf(s.singer, s.artistIds),
                ))
            }
            listenKey = key; listenSong = song; listenSource = source; listenPlayedMs = 0
        }
        listenTickAt = now
        listenWasPlaying = isPlaying
    }

    // ── Commands ──

    /** Runs an API call off the caller, logging failures instead of crashing the UI. */
    private fun command(onFailure: (Throwable) -> Unit = {}, block: suspend () -> Unit) {
        scope.launch {
            runCatching { block() }.onFailure { Log.w(TAG, "command failed: ${it.message}"); onFailure(it) }
        }
    }

    private val transportLock = kotlinx.coroutines.sync.Mutex()
    private val transportGen = java.util.concurrent.atomic.AtomicInteger()

    /** Moved by [clearSession]: a transport started for an account that signed out is never sent. */
    private val sessionGen = java.util.concurrent.atomic.AtomicInteger()

    /**
     * Play, pause, skip: sent one at a time and only the newest one counts. Taps sent all
     * at once raced in the Web Player (a skip and a play crossing, a player stuck on one
     * song until restarted); one still waiting when a newer one comes is dropped.
     */
    /** [pullBack]: playback taken by another device comes back here first (not for a pause). */
    /**
     * [waitReady]: wait for the page when it is loading. Skips do not once a state was seen:
     * the player keeps them for after the reload (the song the taps point at plays then).
     */
    /**
     * [checkAfter]: when this phone was the one playing, the device check runs after the command
     * instead of before it, so the tap does not wait on a server round trip. A takeover it finds
     * then is pulled back as before; with another device known to be active, the check still
     * comes first, since the pull-back has to happen before the command.
     */
    /**
     * [done]: told once, on the main thread, whether the command was answered (true) or not
     * (failed, timed out, dropped for a newer one or for a page that never loaded).
     */
    private fun transport(
        pullBack: Boolean = true,
        waitReady: Boolean = true,
        checkAfter: Boolean = false,
        done: ((ok: Boolean) -> Unit)? = null,
        block: suspend (isLatest: () -> Boolean) -> Unit,
    ) {
        val gen = transportGen.incrementAndGet()
        val session = sessionGen.get()
        runningTransport?.let { job ->
            val held = SystemClock.elapsedRealtime() - runningSince
            if (job.isActive && held >= TRANSPORT_STUCK_MS) {
                Log.w(TAG, "transport stuck for $held ms: given up for the newer one")
                job.cancel()
            }
        }
        scope.launch {
            val self = coroutineContext[kotlinx.coroutines.Job]
            var told = false
            fun tell(ok: Boolean) {
                if (told) return
                told = true
                done?.invoke(ok)
            }
            var answered = false
            // Counted from inside: a coroutine cancelled before it starts never runs its finally.
            transportsInFlight.incrementAndGet()
            try {
                transportLock.withLock {
                    if (gen != transportGen.get()) return@withLock
                    runningTransport = self
                    runningSince = SystemClock.elapsedRealtime()
                    // A tap while the page loads (cold start, a reload): sent once it is there,
                    // instead of failing at once with "not ready".
                    if (waitReady && !api.ready.value && kotlinx.coroutines.withTimeoutOrNull(READY_WAIT_MS) { api.ready.first { it } } == null) {
                        Log.w(TAG, "transport dropped: the player page is not ready")
                        return@withLock
                    }
                    if (gen != transportGen.get()) return@withLock
                    // A listen sync just ended: the page is heard again before this command reaches it.
                    AccountSync.listen.awaitEnded()
                    val checkLater = pullBack && checkAfter && _activeDevice.value == null
                    if (pullBack && !checkLater && api.ready.value) takeBackPlayback()
                    // Both may wait (a mirror's end, a device check): the session may have ended meanwhile.
                    if (session != sessionGen.get()) return@withLock
                    // A cancellation of the caller is never swallowed (it must unwind); only the
                    // transport's own timeout and a real failure are logged here.
                    try {
                        kotlinx.coroutines.withTimeout(TRANSPORT_TIMEOUT_MS) { block { gen == transportGen.get() } }
                        answered = true
                        tell(true)
                    } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
                        Log.w(TAG, "transport timed out after ${TRANSPORT_TIMEOUT_MS} ms")
                    } catch (e: kotlinx.coroutines.CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Log.w(TAG, "transport failed: ${e.message}")
                    }
                    if (checkLater && gen == transportGen.get() && api.ready.value) takeBackPlayback()
                }
            } finally {
                // A newer transport may hold the lock already: only this one's own mark is cleared.
                if (runningTransport === self) runningTransport = null
                tell(false)
                transportsInFlight.decrementAndGet()
                // An answered play or pause: the page gets a moment to say so before the screen
                // is put back on what it says (a slow network answers late, its state later).
                // One that failed is put right then too, whatever was wanted.
                if (answered) {
                    val until = SystemClock.elapsedRealtime() + COMMAND_SETTLE_MS
                    if (wantPlayingUntil != 0L) wantPlayingUntil = maxOf(wantPlayingUntil, until)
                    if (wantPausedUntil != 0L) wantPausedUntil = maxOf(wantPausedUntil, until)
                }
                reconcileAfter(commandSettled, COMMAND_SETTLE_MS)
            }
        }
    }

    /** Transports started and not over yet: [reconcile] leaves the screen to them meanwhile. */
    private val transportsInFlight = java.util.concurrent.atomic.AtomicInteger()

    /** The transport holding [transportLock], and since when (see [TRANSPORT_STUCK_MS]). */
    @Volatile private var runningTransport: kotlinx.coroutines.Job? = null
    @Volatile private var runningSince = 0L

    /**
     * Plays [itemUri], then checks that the page really moved to it; a play the page lost
     * (busy, reloading) is sent once more instead of leaving the old song playing.
     */
    private suspend fun playChecked(itemUri: String, isLatest: () -> Boolean, play: suspend () -> Unit) {
        if (NativeAudio.on && _activeDevice.value == null) {
            play()
            return
        }
        val before = api.player.state.value?.item?.uri
        play()
        repeat(2) { attempt ->
            val moved = kotlinx.coroutines.withTimeoutOrNull(PLAY_CHECK_MS) {
                api.player.state.first { s ->
                    val u = s?.item?.uri
                    u == itemUri || (u != null && u != before && !s.isPaused) || !isLatest()
                }
            }
            if (moved != null || !isLatest()) return
            if (attempt == 0) { Log.w(TAG, "play of $itemUri not taken: sent again"); play() }
        }
    }

    /** Remember the Spotify context the given play keys belong to. */
    fun registerContext(urls: List<String>, contextUri: String) {
        urls.forEach { contextRegistry[it] = contextUri }
        contextRows[contextUri] = urls
    }

    /**
     * Each list's play keys in its own order, as last registered: where a picked song sits in it
     * (see [rowIndex]). The app's rows map one to one onto the list's items, in Spotify's order.
     */
    private val contextRows = ConcurrentHashMap<String, List<String>>()

    /**
     * The place of [song] in the list [ctx], sent with its uri as the official player sends a row's
     * index with its uri. Reported (900+ songs, Liked Songs): a song picked far down a big list
     * started another song. The uri alone is looked up in the list's first pages only (lists of a
     * hundred songs played the song picked); the index says where it is. Only past that first
     * stretch, so the plays that worked go out exactly as before. A given [order] is played as one
     * page of those songs (see player-bridge.js), where the uri is always found: no index then.
     */
    private fun rowIndex(song: String, ctx: String, order: List<String>?): Int? {
        if (order != null) return null
        val at = contextRows[ctx]?.indexOf(song) ?: return null
        return at.takeIf { it >= INDEXED_ROW_FROM }
    }

    // Names of the lists playback started from, as the app's own pages name them. Spotify's
    // state carries a context label, but it comes back blank for some lists, and the player
    // then showed the album name instead of the playlist's (B26). A context the page does not
    // name is shown with the name the app played it from.
    private val contextNames = ConcurrentHashMap<String, String>()

    /** [name] of the list at [contextUri], for the player header and the queue sheet. */
    fun registerContextName(contextUri: String, name: String) {
        if (contextUri.isNotBlank() && name.isNotBlank()) contextNames[contextUri] = name
    }

    /** The app's name for [contextUri], "" when the app never played from it (B26). */
    fun knownContextName(contextUri: String): String = contextNames[contextUri].orEmpty()

    /** Liked Songs plays as its own context: Spotify maps it to the account's liked list. */
    fun registerLikedSongs(urls: List<String>) = registerContext(urls, LIKED_CONTEXT)

    /** [holdMs]: how long states of another song are ignored, at most, while this one comes. */
    private fun markPending(
        trackId: String,
        itemUri: String? = trackId.takeIf { it.isNotBlank() }?.let { SPOTIFY_TRACK_PREFIX + it },
        holdMs: Long = PENDING_MS,
    ) {
        pendingSkip = 0
        pendingItemUri = itemUri
        bufferingState.value = true
        itemUri?.let { boundState?.likeState?.value = library[it] ?: false }
        intendPlaying()
        pendingTrackId = trackId
        pendingUntil = SystemClock.elapsedRealtime() + holdMs
        reconcileAfter(pendingEnded, holdMs)
        playing = true
        positionMs = 0
        positionAt = SystemClock.elapsedRealtime()
    }

    /**
     * Play [song] (a play key "spotify:track:<id>|<text>" or "episode:<id>"). [contextUri] is
     * the list it was picked from; when null, the last list that registered this track is used.
     * [order]: the context's track uris in the order to play them (a sorted playlist).
     * [songs]: what the caller knows of the song (and of its list, in play order), for the
     * audio-source extensions: asked first when one is on ([askExtensions]), they play it in the
     * local player with the rest as the queue; a miss plays on Spotify as before (with Spotify as
     * the music account only, see [accountPlays]). Without
     * [songs], the song is looked up on Spotify (a link, Recents, an extension's block).
     * [alone]: no list at all, not even the one that registered the track (a search hit), so
     * Spotify goes on with its own autoplay of related songs instead of, say, Liked Songs.
     */
    fun playSong(
        song: String, context: Context? = null, contextUri: String? = null, order: List<String>? = null, positionMs: Long? = null,
        songs: List<SongsModel>? = null, askExtensions: Boolean = true, alone: Boolean = false,
        spotifyFirst: Boolean = false,
    ) {
        userActed()
        MixedPlaylistQueue.clear()
        // Data saver on mobile data: Spotify can't stream, only downloads and Local Files play.
        if (com.music.spotui.data.DataSaver.active) {
            main.post {
                android.widget.Toast.makeText(Graph.app, app.myspoti.engine.R.string.data_saver_blocked, android.widget.Toast.LENGTH_SHORT).show()
            }
            return
        }
        // A song of another provider (the catalog's): played as its Spotify recording once found, alone.
        if (song.startsWith(com.music.spotui.data.catalog.CatalogRuntime.PLAY_PREFIX)) { playCatalogSong(song, context, askExtensions); return }
        val routedId = if (song.startsWith("episode:")) null else spotifyTrackIdForPlayback(song)
        if (_activeDevice.value == null && askExtensions && com.music.spotui.extensions.AudioRoute.asks(routedId, com.music.spotui.extensions.Extensions.hasAudioSource())) {
            val ctx = if (alone) "" else (contextUri ?: contextRegistry[song]).orEmpty()
            val shuffle = isShuffleOn()
            playThroughExtensions(
                routedId!!,
                songs?.firstOrNull { it.spotifyTrackId == routedId },
                knownContextName(ctx),
                { playSong(song, context, contextUri, order, positionMs, askExtensions = false, alone = alone) },
                songs = songs,
                contextUri = ctx, spotifyFirst = spotifyFirst,
            ) { isLatest, shown ->
                com.music.spotui.extensions.ExtensionAudio.route(routedId, songs, knownContextName(ctx), shuffle, ctx, isLatest, shown, positionMs ?: 0L)
            }
            return
        }
        if (routedId != null && refusedWithoutAccountPlayer(songs?.firstOrNull { it.spotifyTrackId == routedId }?.title, routedId)) return
        if (askExtensions && routedId != null) com.music.spotui.extensions.Extensions.audioSkipped()?.let {
            AppLog.d("audio: $it, Spotify plays $routedId")
        }
        routeAsk.incrementAndGet(); routingState.value = null
        LocalPlayer.stop()
        cancelBurst()
        val episodeId = song.removePrefix("episode:").takeIf { song.startsWith("episode:") }
        val trackId = episodeId ?: spotifyTrackIdForPlayback(song) ?: return
        val itemUri = if (episodeId != null) "spotify:episode:$episodeId" else SPOTIFY_TRACK_PREFIX + trackId
        val ctx = if (alone) null else contextUri ?: contextRegistry[song]
        // What a smart shuffle ending brings back: the order of the last play that was not one.
        if (ctx != null) {
            val sent = order?.takeIf { ctx == contextUri }
            playedOrder = ctx to sent
            if (com.music.spotui.ui.screens.SmartShuffle.on.value != ctx) { plainOrder = ctx to AppShuffle.unshuffled(ctx, sent); smartPlayed = null }
            else if (sent != null) smartPlayed = ctx
        }
        playedByHand = itemUri
        markPending(if (episodeId != null) "" else trackId, itemUri)
        transport(pullBack = _activeDevice.value == null) { isLatest ->
            playChecked(itemUri, isLatest) {
                Log.d(TAG, "playing $itemUri in ${ctx ?: "no context"}: ${queueTag()}")
                if (ctx != null) {
                    val sent = order?.takeIf { ctx == contextUri }
                    api.player.play(ctx, trackUri = itemUri, index = rowIndex(song, ctx, sent), positionMs = positionMs, order = sent)
                }
                else api.player.play(itemUri, positionMs = positionMs)
            }
        }
    }

    // ── A song sent to the audio-source extensions ──
    /** Bumped by every play; a resolution that finishes after a newer one was asked plays nothing. */
    private val routeAsk = java.util.concurrent.atomic.AtomicInteger()
    private val handoffGeneration = java.util.concurrent.atomic.AtomicInteger()
    private var handoffResolution: Deferred<ExtensionAudio.Handoff?>? = null

    private fun invalidateHandoff() {
        handoffGeneration.incrementAndGet()
        // Cancel provider work, not an in-flight pause. The latter must unwind inside the
        // transport lock before a newer command is sent.
        handoffResolution?.cancel()
        handoffResolution = null
    }
    private val routingState = mutableStateOf<String?>(null)
    private var routingUntil = 0L
    private var routingContext = ""
    private var routingContextUri = ""
    private var routingSongs: List<SongsModel>? = null
    val routing: Boolean get() = routingState.value != null && SystemClock.elapsedRealtime() < routingUntil

    /**
     * Spotify's Web Player is the account's player only with Spotify as the music account
     * ([com.music.spotui.data.preferences.AccountProviderPref]). With YouTube Music, or none, a song
     * plays from the extensions or not at all: it never falls back to Spotify, a session that is not
     * the chosen account (YouTube Music's own page is only the listen sync's unheard mirror, there
     * is no audible YouTube Music player in the app). Episodes stay Spotify's own content.
     */
    val accountPlays: Boolean
        get() = com.music.spotui.data.preferences.AccountProviderPref.id == app.myspoti.api.account.AccountProviders.SPOTIFY

    /**
     * The song [trackId] ([title] when known) would now go to Spotify for want of an extension: with
     * a music account other than Spotify ([accountPlays]) it is not played, the loading ends and the
     * user is told no source had it. True when refused (the caller stops there).
     */
    private fun refusedWithoutAccountPlayer(title: String?, trackId: String): Boolean {
        if (accountPlays) return false
        AppLog.d("audio: no extension plays ${title ?: trackId}; the music account " +
            "(${com.music.spotui.data.preferences.AccountProviderPref.id}) has no player in the app: not sent to Spotify")
        routeAsk.incrementAndGet(); routingState.value = null
        playing = false; bufferingState.value = false
        main.post { android.widget.Toast.makeText(Graph.app, app.myspoti.engine.R.string.why_source_none_chosen, android.widget.Toast.LENGTH_SHORT).show() }
        pushNotification(null, boundState?.likeState?.value ?: false)
        return true
    }

    /**
     * Plays the song [trackId] through the audio-source extensions ([play]: ExtensionAudio, told
     * whether its answer is still the latest ask and how to show the song once it knows it).
     * What played pauses and the song shows at once, loading, under its own Spotify uri: its
     * lyrics, Canvas, artists and colours load while the extensions answer. The latest pick wins:
     * an older answer plays nothing. [contextName]: the list it is played from, shown meanwhile.
     * [fallback] (on the main thread): they had nothing, Spotify plays (only with Spotify as the
     * music account: else the song is not played, see [accountPlays]).
     */
    fun playThroughExtensions(
        trackId: String, song: SongsModel?, contextName: String, fallback: () -> Unit,
        songs: List<SongsModel>? = null, contextUri: String = "",
        spotifyFirst: Boolean = false,
        spotifySkip: Boolean = false,
        play: suspend (isLatest: () -> Boolean, shown: (SongsModel) -> Unit) -> Boolean,
    ) {
        invalidateHandoff()
        if (spotifyFirst && startSpotifyFirst(trackId, song, songs, contextName, contextUri, spotifySkip, fallback)) return
        val ask = routeAsk.incrementAndGet()
        val isLatest = { routeAsk.get() == ask }
        spotifyFallbackId = null; fallbackRest = null
        cancelBurst()
        if (LocalPlayer.active.value) LocalPlayer.pause()
        else if (playing) { intendPaused(); transport(pullBack = false) { api.player.pause() } }
        playing = false; bufferingState.value = true
        positionMs = 0; positionAt = SystemClock.elapsedRealtime()
        routingState.value = trackId; routingUntil = SystemClock.elapsedRealtime() + ROUTE_HOLD_MS
        routingContext = contextName
        routingContextUri = contextUri
        routingSongs = songs
        song?.let(::showRouted)
        scope.launch {
            val played = try { play(isLatest) { s -> main.post { if (isLatest()) showRouted(s) } } }
            catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) {
                AppLog.d("audio: asking the extensions for $trackId failed: $e")
                false
            }
            if (!played) main.post {
                if (isLatest() && refusedWithoutAccountPlayer(song?.title, trackId)) return@post
                if (isLatest()) {
                    AppLog.d("audio: no extension had ${song?.title ?: trackId}, Spotify plays")
                    spotifyPlayed.add(trackId)
                    routingState.value = null; routingSongs = null; spotifyFallbackId = trackId; fallback()
                }
            }
        }
    }

    private fun spotifyPlaysHere(): Boolean = accountPlays && _activeDevice.value == null &&
        !MyspotiRuntime.spotify.player.playsElsewhere.value && !MyspotiRuntime.spotify.player.localMute && !AccountSync.holdsSpotify &&
        api.jam.session.value == null && !adState.value && !MyspotiRuntime.spotify.player.adPlaying.value &&
        !com.music.spotui.data.DataSaver.active && !com.music.spotui.cast.CastPlayback.active

    /** Keep ready preferred sources (and downloads) direct; only a cold answer races Spotify startup. */
    private fun startSpotifyFirst(
        trackId: String, song: SongsModel?, songs: List<SongsModel>?, context: String, contextUri: String,
        spotifySkip: Boolean, start: () -> Unit,
    ): Boolean {
        if (trackId.isBlank() || !MyspotiRuntime.isStarted || !spotifyPlaysHere() || !Extensions.hasAudioSource() || !OfflineStore.isOnline(Graph.app) ||
            MyspotiRuntime.host.licenseLimited() || MyspotiRuntime.spotify.player.licencesHeld ||
            OfflineStore.isDownloaded(trackId) || ExtensionAudio.hasFreshAnswer(trackId)) return false
        val uri = SPOTIFY_TRACK_PREFIX + trackId
        val session = sessionGen.get()
        val sourceOrder = Extensions.sourceLine(app.myspoti.extensions.Action.AUDIO_SOURCE)
        if (sourceOrder.firstOrNull() == com.music.spotui.extensions.ACCOUNT_SOURCE) return false
        val shuffle = isShuffleOn()
        val before = api.player.state.value
        // A fresh state update alone cannot acknowledge a new pick of an already playing item.
        if (before?.item?.uri == uri && !before.isPaused) return false
        val issuedAt = SystemClock.elapsedRealtime()
        val scheduledRequest = handoffGeneration.get()
        var request = scheduledRequest
        var issuedTransport = transportGen.get()
        var dispatched = false
        var matched: PlayerState? = null
        scope.launch {
            if (scheduledRequest != handoffGeneration.get() || session != sessionGen.get()) return@launch
            fun ownsRequest() = dispatched && request == handoffGeneration.get() && issuedTransport == transportGen.get() &&
                session == sessionGen.get() && !LocalPlayer.active.value && !routing && spotifyPlaysHere()
            fun current() = ownsRequest() && Extensions.hasAudioSource() &&
                sourceOrder == Extensions.sourceLine(app.myspoti.extensions.Action.AUDIO_SOURCE)

            fun sameItem(a: PlayerState?, b: PlayerState?): Boolean = a != null && b != null &&
                a.item?.uri == uri && b.item?.uri == uri && a.item?.uid == b.item?.uid && a.contextUri == b.contextUri

            try {
                spotifyFirstRoute(
                    startSpotify = {
                        val previous = transportGen.get()
                        val previousTap = tapSeq
                        start()
                        request = handoffGeneration.get()
                        issuedTransport = transportGen.get()
                        dispatched = previous != issuedTransport ||
                            (spotifySkip && NativeAudio.on && tapSeq != previousTap)
                        if (dispatched) {
                            if (fallbackRest?.first != trackId) fallbackRest = null
                            spotifyFallbackId = trackId
                        }
                    },
                    resolve = {
                        if (!current()) null else kotlinx.coroutines.coroutineScope {
                            val resolution = async {
                                kotlinx.coroutines.withTimeoutOrNull(HANDOFF_RESOLVE_WAIT_MS) {
                                    ExtensionAudio.prepareHandoff(trackId, songs, song)
                                }
                            }
                            handoffResolution = resolution
                            try { resolution.await() } finally {
                                if (handoffResolution === resolution) handoffResolution = null
                            }
                        }
                    },
                    awaitPlaying = {
                        matched = kotlinx.coroutines.withTimeoutOrNull(HANDOFF_START_WAIT_MS) {
                            api.player.state.first { s ->
                                !current() || (s != null && s !== before && s.item?.uri == uri && !s.isPaused && !s.isBuffering)
                            }
                        }
                        matched != null
                    },
                    handoff = { answer ->
                        transportLock.withLock {
                            val spotify = MyspotiRuntime.spotify.player
                            val state = api.player.state.value
                            if (!current() || state == null || !sameItem(matched, state) || state.isPaused || state.isBuffering ||
                                NativeAudio.skipInFlight || pendingSkips != 0 ||
                                !Extensions.canUseAudioAnswer(answer.stream.providerId)) return@withLock null
                            val length = state.item?.durationMs ?: return@withLock null
                            val streamLength = answer.stream.durationMs
                            if (length <= 0L || state.positionAt(System.currentTimeMillis()) >= length - HANDOFF_END_GUARD_MS ||
                                (streamLength != null && kotlin.math.abs(streamLength - length) > HANDOFF_END_GUARD_MS)) return@withLock null
                            val position = kotlinx.coroutines.withTimeoutOrNull(HANDOFF_PAUSE_WAIT_MS) {
                                try { api.player.pause() }
                                catch (e: kotlinx.coroutines.CancellationException) { throw e }
                                catch (e: Exception) { return@withTimeoutOrNull null }
                                val paused = api.player.state.first { s ->
                                    !current() || !sameItem(state, s) || s?.isPaused == true
                                }
                                if (current() && sameItem(state, paused) && paused?.isPaused == true &&
                                    confirmedSpotifySilence(spotify) && current() && Extensions.canUseAudioAnswer(answer.stream.providerId)) {
                                    api.player.state.value?.takeIf { sameItem(paused, it) && it.isPaused }?.positionMs
                                } else null
                            }
                            if (position == null && ownsRequest() && sameItem(state, api.player.state.value)) {
                                // The command may have landed without a timely confirmation. Put
                                // Spotify back in charge only if this request still owns transport.
                                transport(pullBack = false) { latest ->
                                    if (latest() && request == handoffGeneration.get() && session == sessionGen.get() &&
                                        spotifyPlaysHere() && sameItem(state, api.player.state.value)) api.player.resume()
                                }
                            }
                            position
                        }
                    },
                    isCurrent = ::current,
                    startLocal = { answer, position ->
                        val confirmed = api.player.state.value
                        if (!sameItem(matched, confirmed) || confirmed?.isPaused != true) return@spotifyFirstRoute
                        ExtensionAudio.use(trackId, answer.stream)
                        spotifyPlayed.remove(trackId)
                        spotifyFallbackId = null; fallbackRest = null
                        intendPaused(); playing = false // Already paused by the handoff.
                        LocalPlayer.play(answer.tracks, answer.index, shuffle, context, contextUri, position, continues = true)
                        AppLog.d("audio: Spotify-first handoff after ${SystemClock.elapsedRealtime() - issuedAt} ms")
                    },
                )
            } catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) { Log.w(TAG, "Spotify-first handoff failed: ${e.javaClass.simpleName}") }
        }
        return true
    }

    private const val HANDOFF_START_WAIT_MS = 8_000L
    private const val HANDOFF_RESOLVE_WAIT_MS = 25_000L
    private const val HANDOFF_PAUSE_WAIT_MS = 3_000L
    private const val HANDOFF_END_GUARD_MS = 5_000L

    private suspend fun confirmedSpotifySilence(spotify: app.myspoti.spotify.SpotifyPlayer): Boolean = try {
        spotify.outputPausedForHandoff()
    } catch (e: kotlinx.coroutines.CancellationException) { throw e }
    catch (_: Exception) { false }

    private fun stepWhileRoutingOrCold(forward: Boolean, restartAllowed: Boolean = true): Boolean {
        val wasRouting = routing
        val coldLocal = !LocalPlayer.active.value && !wasRouting && _activeDevice.value == null &&
            (restoredLocal || (!playing && !stateSeen && com.music.spotui.extensions.Extensions.hasAudioSource()))
        if (!wasRouting && !coldLocal) return false
        val curId = (if (wasRouting) routingState.value else null) ?: trackIdOf(_nowPlaying.value.uri)
        val list = routingSongs?.takeIf { wasRouting && it.isNotEmpty() }
            ?: _queue.value.let { q -> listOfNotNull(q.current) + (q.queued + q.nextUp).map { it.song } }.takeIf { it.isNotEmpty() }
        val idx = list?.indexOfFirst { it.spotifyTrackId == curId && curId.isNotBlank() } ?: -1
        val target = when {
            forward && idx >= 0 -> list?.getOrNull(idx + 1)
            forward -> _nowPlaying.value.next ?: _queue.value.let { it.queued + it.nextUp }.firstOrNull()?.song
            !forward && restartAllowed && !wasRouting && getCurrentPosition() > 3_000L -> {
                seekTo(0L)
                return true
            }
            !forward && idx > 0 -> list?.getOrNull(idx - 1)
            !forward -> _nowPlaying.value.prev
            else -> null
        }
        if (target != null && target.spotifyTrackId.isNotBlank()) {
            restoredLocal = false
            val ctx = (if (wasRouting) routingContextUri else _nowPlaying.value.contextUri).ifBlank { null }
            val nextSongs = when {
                list != null && idx >= 0 && forward -> list.drop(idx + 1)
                list != null && idx > 0 && !forward -> list.drop(idx - 1)
                else -> upcomingSongs(target)
            }
            val key = target.url.takeIf { it.startsWith("spotify:") || it.startsWith("episode:") }
                ?: (SPOTIFY_TRACK_PREFIX + target.spotifyTrackId)
            playSong(key, contextUri = ctx, songs = nextSongs)
            return true
        }
        if (wasRouting && forward && curId.isNotBlank()) {
            val request = routeAsk.incrementAndGet()
            val user = handoffGeneration.get()
            routingState.value = null
            routingSongs = null
            scope.launch {
                val rec = kotlinx.coroutines.withTimeoutOrNull(8_000L) {
                    runCatching { Graph.api.getRecommendations(listOf(curId)) }.getOrNull()
                }?.firstOrNull { it.spotifyTrackId.isNotBlank() && it.spotifyTrackId != curId }
                if (rec != null) {
                    val key = rec.url.takeIf { it.startsWith("spotify:") } ?: (SPOTIFY_TRACK_PREFIX + rec.spotifyTrackId)
                    main.post { if (routeAsk.get() == request && handoffGeneration.get() == user) playSong(key, songs = listOf(rec), alone = true) }
                } else {
                    main.post { if (routeAsk.get() == request && handoffGeneration.get() == user) bufferingState.value = false }
                }
            }
            return true
        }
        if (wasRouting && !forward) {
            if (LocalPlayer.active.value && LocalPlayer.current() != null) {
                routeAsk.incrementAndGet()
                routingState.value = null
                routingSongs = null
                LocalPlayer.resume()
                return true
            }
        }
        return false
    }

    internal fun playColdResumeFromNative() {
        main.post {
            val np = _nowPlaying.value
            if (np.uri.isBlank()) return@post
            val q = _queue.value
            val songs = (listOfNotNull(q.current) + (q.queued + q.nextUp).map { it.song }).takeIf { it.isNotEmpty() }
            val key = if (np.uri.startsWith("spotify:episode:")) "episode:" + np.uri.removePrefix("spotify:episode:") else np.uri
            playSong(key, contextUri = np.contextUri.ifBlank { null }, positionMs = getCurrentPosition().takeIf { it > 0L }, songs = songs, askExtensions = false)
        }
    }

    internal fun playColdStepFromNative(forward: Boolean) {
        main.post {
            val np = _nowPlaying.value
            val q = _queue.value
            val target = if (forward) {
                np.next ?: (q.queued + q.nextUp).firstOrNull()?.song
            } else {
                if (getCurrentPosition() > 3_000L) {
                    seekTo(0L)
                    return@post
                }
                np.prev ?: q.current
            }
            if (target != null) {
                val key = target.url.takeIf { it.startsWith("spotify:") || it.startsWith("episode:") }
                    ?: (if (target.spotifyTrackId.isNotBlank()) SPOTIFY_TRACK_PREFIX + target.spotifyTrackId else return@post)
                playSong(key, contextUri = np.contextUri.ifBlank { null }, songs = upcomingSongs(target), askExtensions = false)
            } else if (np.uri.isNotBlank()) {
                val key = if (np.uri.startsWith("spotify:episode:")) "episode:" + np.uri.removePrefix("spotify:episode:") else np.uri
                playSong(key, contextUri = np.contextUri.ifBlank { null }, askExtensions = false)
            }
        }
    }

    /**
     * A song of the local queue an extension streams had no audio there, or would not play: Spotify
     * plays it from [positionMs], in the list it came from, and goes on with that list (as a miss
     * at the pick does). False: it cannot (no Spotify id, data saver), the caller skips it.
     */
    fun playUnavailableOnSpotify(t: com.music.spotui.data.local.LocalTrack, positionMs: Long): Boolean =
        playLocalOnSpotify(t, positionMs, "not available from extensions")

    private fun playLocalOnSpotify(t: com.music.spotui.data.local.LocalTrack, positionMs: Long, why: String): Boolean {
        val id = streamedTrackId(t)
        if (id.isBlank() || com.music.spotui.data.DataSaver.active || !accountPlays) return false
        AppLog.d("local: ${t.title} $why, Spotify plays it")
        spotifyPlayed.add(id)
        spotifyFallbackId = id
        // The local queue after it, for the extensions to go on with once Spotify has played it.
        fallbackRest = Triple(id, LocalPlayer.upcoming().map { (_, u) -> localSong(u).copy(spotifyTrackId = LocalPlayer.spotifyIdOf(u)) }, LocalPlayer.contextName)
        playSong(buildSpotifyPlayQuery(id, t.title, t.artist), contextUri = LocalPlayer.contextUri.ifBlank { null },
            positionMs = positionMs.takeIf { it > 0 }, askExtensions = false)
        watchFallback(id, t.title)
        return true
    }

    /**
     * A song of the local queue sent to Spotify for want of the extensions ([playLocalOnSpotify])
     * must be playing there within [FALLBACK_START_MS]; else (Spotify refused it: a Jam, a free
     * account's limits, no network to it) the queue goes on with its next song, as a song neither
     * has is skipped, rather than standing still on a refused play.
     */
    private fun watchFallback(id: String, title: String) {
        fallbackWatch?.cancel()
        val armedAt = android.os.SystemClock.elapsedRealtime()
        val before = trackIdOf(_nowPlaying.value.uri)
        // Looked at twice a second (the scope is the main thread's): the song seen playing once is
        // a success. Only one never seen playing within the time, with nobody else having moved
        // on, is skipped. Looked at once at the end, it took a song played then skipped or paused
        // by the user for a refused one: it skipped again and played on after a pause (dev 3136).
        fallbackWatch = scope.launch {
            while (true) {
                kotlinx.coroutines.delay(FALLBACK_LOOK_MS)
                if (spotifyFallbackId != id || LocalPlayer.active.value) return@launch
                val now = trackIdOf(_nowPlaying.value.uri)
                if (playing && now == id) { fallbackFailures = 0; return@launch }
                // The user skipped, went back, paused or picked something: theirs from now on.
                if (userActedAt > armedAt) return@launch
                // The player moved on to another song by itself (Spotify's own queue): not ours to judge.
                if (now.isNotBlank() && now != id && now != before) return@launch
                if (android.os.SystemClock.elapsedRealtime() - armedAt >= FALLBACK_START_MS) break
            }
            fallbackFailed(id, title)
        }
    }

    /** When the user last skipped, went back, paused, played or picked a song (elapsedRealtime). */
    @Volatile private var userActedAt = 0L
    private fun userActed() {
        userActedAt = android.os.SystemClock.elapsedRealtime()
        if (MyspotiRuntime.isStarted) runCatching { MyspotiRuntime.spotify.player.noteUserAction() }
        invalidateHandoff()
    }

    private var fallbackWatch: kotlinx.coroutines.Job? = null
    /** Songs skipped in a row because neither the extensions nor Spotify played them. */
    private var fallbackFailures = 0

    private fun fallbackFailed(id: String, title: String) {
        val rest = fallbackRest?.takeIf { it.first == id }
        val songs = rest?.second?.filter { it.spotifyTrackId.isNotBlank() && it.spotifyTrackId != id }.orEmpty()
        val next = songs.firstOrNull()
        fallbackFailures++
        if (next == null || fallbackFailures > MAX_FALLBACK_FAILURES) {
            AppLog.d("local: Spotify did not play $title either, ${if (next == null) "no song after it" else "$fallbackFailures songs failed in a row"}: stopped")
            fallbackFailures = 0; spotifyFallbackId = null; fallbackRest = null
            android.widget.Toast.makeText(Graph.app, Graph.app.getString(app.myspoti.engine.R.string.song_unavailable, title), android.widget.Toast.LENGTH_LONG).show()
            return
        }
        AppLog.d("local: Spotify did not play $title within ${FALLBACK_START_MS / 1000} s: the queue goes on with ${next.title}")
        android.widget.Toast.makeText(Graph.app, Graph.app.getString(app.myspoti.engine.R.string.song_unavailable_skipped, title), android.widget.Toast.LENGTH_SHORT).show()
        val name = rest!!.third
        playThroughExtensions(next.spotifyTrackId, next, name, spotifyFirst = false, fallback = {
            // The next one is not on the extensions either: Spotify is tried for it, watched the same way.
            spotifyPlayed.add(next.spotifyTrackId)
            fallbackRest = Triple(next.spotifyTrackId, songs.drop(1), name)
            playSong(buildSpotifyPlayQuery(next.spotifyTrackId, next.title, next.singer), positionMs = null, askExtensions = false)
            watchFallback(next.spotifyTrackId, next.title)
        }) { isLatest, _ ->
            com.music.spotui.extensions.ExtensionAudio.playList(songs, next, name, shuffle = false, isLatest = isLatest)
                .also { if (it) fallbackFailures = 0 }
        }
    }

    /** What picking an audio source in the quality sheet did to the song playing ([switchSource]). */
    enum class SourceSwitch {
        /** The song plays from it, from where it was (or already did). */
        PLAYING,
        /** It does not have the song (or cannot answer now): the song goes on where it played, the order is the one before. */
        MISSING,
        /** The song goes on as it plays (its download, another device, a cast, the song changed): the songs after it come from it. */
        NEXT_SONG,
    }

    /**
     * The audio source [id] (an extension, or [com.music.spotui.extensions.ACCOUNT_SOURCE]) picked
     * in the quality sheet: first of the order for this session (Extensions.setSessionSource, never
     * saved) and the song playing plays from it, from where it is. An extension is asked for the
     * song alone first, nothing stopping meanwhile: without it ([SourceSwitch.MISSING]) the song
     * goes on and the order stays as it was. Spotify picked while an extension streams: Spotify
     * plays the song from there, in its list. Picked while paused, the song stays paused: put on
     * the new source where it was, it starts at the user's next play ([putPausedOnExtension],
     * [spotifyDue]). [done] on the main thread.
     */
    fun switchSource(id: String, done: (SourceSwitch) -> Unit) {
        invalidateHandoff()
        val ext = com.music.spotui.extensions.Extensions
        spotifyDue = null
        val local = LocalPlayer.active.value
        val t = if (local) LocalPlayer.current() else null
        val streamed = t?.let(::streamedTrackId).orEmpty()
        val trackId = if (local) streamed else trackIdOf(_nowPlaying.value.uri)
        val elsewhere = _activeDevice.value != null || routing || com.music.spotui.data.DataSaver.active || com.music.spotui.cast.CastPlayback.active
        if (id == com.music.spotui.extensions.ACCOUNT_SOURCE) {
            ext.setSessionSource(id)
            done(when {
                !local -> SourceSwitch.PLAYING
                t == null || streamed.isBlank() || elsewhere -> SourceSwitch.NEXT_SONG
                // Paused: it stays paused where it is, the user's next play plays it on Spotify from there.
                !LocalPlayer.playWhenReady() -> {
                    spotifyDue = streamed
                    AppLog.d("local: ${t.title} paused, Spotify plays it at the next play")
                    SourceSwitch.PLAYING
                }
                playLocalOnSpotify(t, LocalPlayer.position(), "picked in the player") -> SourceSwitch.PLAYING
                else -> SourceSwitch.NEXT_SONG
            })
            return
        }
        if (local && streamed.isNotBlank() && com.music.spotui.extensions.ExtensionAudio.providerOf(streamed) == id) { ext.setSessionSource(id); done(SourceSwitch.PLAYING); return }
        val song = when {
            trackId.isBlank() || elsewhere -> null
            t != null -> localSong(t)
            else -> _queue.value.current?.takeIf { it.spotifyTrackId == trackId }
        }
        if (song == null) { ext.setSessionSource(id); done(SourceSwitch.NEXT_SONG); return }
        AppLog.d("audio: ${song.title} asked to $id, picked in the player")
        scope.launch {
            val stream = runCatching {
                ext.audioFrom(id, ext.trackInfo(trackId, song.title, song.singer, song.album, song.durationMs.toLong(), song.coverUri))
            }.getOrNull()
            main.post {
                if (stream == null) { done(SourceSwitch.MISSING); return@post }
                ext.setSessionSource(id)
                // Another song meanwhile: it plays as it was asked; the songs after it follow the new order.
                val nowLocal = LocalPlayer.active.value
                val nowId = if (nowLocal) LocalPlayer.current()?.let(::streamedTrackId).orEmpty() else trackIdOf(_nowPlaying.value.uri)
                if (nowId != trackId || routing) { done(SourceSwitch.NEXT_SONG); return@post }
                com.music.spotui.extensions.ExtensionAudio.use(trackId, stream)
                if (nowLocal) { done(if (LocalPlayer.reopen()) SourceSwitch.PLAYING else SourceSwitch.NEXT_SONG); return@post }
                // Spotify played it: the extension plays it from there, the engine's queue after it, as a resume does.
                val np = _nowPlaying.value
                val q = _queue.value
                val songs = (listOfNotNull(q.current) + (q.queued + q.nextUp).map { it.song }).takeIf { l -> l.any { it.spotifyTrackId == trackId } }
                if (!isPlaying()) { putPausedOnExtension(trackId, songs ?: listOf(song), done); return@post }
                playSong(np.uri, contextUri = np.contextUri.ifBlank { null }, positionMs = getCurrentPosition(), songs = songs, spotifyFirst = false)
                done(SourceSwitch.PLAYING)
            }
        }
    }

    /**
     * An extension picked in the player while Spotify had the song [trackId] paused, its answer kept
     * (ExtensionAudio.use): the local player takes it from where Spotify was, with [songs] as its
     * queue (as ExtensionAudio.playList does), paused; nothing plays until the user's play (the page
     * stays paused, the Connect mirror starts only with it). At once, on the main thread: the
     * sources changing next keep the answer of the song the local player is on.
     */
    private fun putPausedOnExtension(trackId: String, songs: List<SongsModel>, done: (SourceSwitch) -> Unit) {
        if (_activeDevice.value != null) { done(SourceSwitch.NEXT_SONG); return }
        val np = _nowPlaying.value
        val picked = songs.first { it.spotifyTrackId == trackId }
        val ctx = np.contextUri.ifBlank { contextRegistry[np.uri].orEmpty() }
        val at = getCurrentPosition()
        AppLog.d("audio: ${picked.title} paused, put on the extension at $at ms, still paused")
        val (list, index) = com.music.spotui.extensions.AudioRoute.queue(songs, picked)
        LocalPlayer.play(list.map(com.music.spotui.extensions.ExtensionAudio::localTrack), index, shuffle = isShuffleOn(), context = knownContextName(ctx),
            contextUri = ctx, startMs = at, continues = true, paused = true)
        done(SourceSwitch.PLAYING)
    }

    /**
     * The song an extension streams that Spotify was picked for while it was paused (see
     * [switchSource]): the user's next play plays it on Spotify from where it is, the local player
     * stays on it paused until then. Null: none.
     */
    private var spotifyDue: String? = null

    /** The user's play on the song [spotifyDue] names: Spotify plays it from where it is. False: the local player resumes as usual. */
    private fun playDueOnSpotify(): Boolean {
        val due = spotifyDue.also { spotifyDue = null } ?: return false
        val t = LocalPlayer.current() ?: return false
        val first = com.music.spotui.extensions.Extensions.sourceLine(app.myspoti.extensions.Action.AUDIO_SOURCE).firstOrNull()
        if (!com.music.spotui.extensions.SessionSource.spotifyDue(due, streamedTrackId(t), first)) return false
        if (_activeDevice.value != null || routing || com.music.spotui.cast.CastPlayback.active) return false
        return playLocalOnSpotify(t, LocalPlayer.position(), "picked in the player while paused")
    }

    /**
     * The local queue the extensions played ended with no song radio to go on with: Spotify goes
     * on after its last song [t] ([trackId]) as after a song played alone (its autoplay), from the
     * song's last second; the song it moves on to is asked to the extensions again (backToExtensions).
     */
    fun continueOnSpotify(t: com.music.spotui.data.local.LocalTrack, trackId: String) {
        if (!com.music.spotui.data.preferences.AutoplayPref.on || trackId.isBlank() || com.music.spotui.data.DataSaver.active) return
        AppLog.d("local: queue ended, Spotify continues")
        spotifyFallbackId = trackId
        val end = (t.durationMs.takeIf { it > 0 } ?: LocalPlayer.duration()) - END_LEAD_MS
        playSong(buildSpotifyPlayQuery(trackId, t.title, t.artist), contextUri = SPOTIFY_TRACK_PREFIX + trackId,
            positionMs = end.takeIf { it > 0 }, askExtensions = false)
    }

    private const val POSITION_SAVE_MS = 10_000L
    /** How often the position save looks for a song playing while none does. */
    private const val POSITION_IDLE_MS = 30_000L

    /** How long a song sent to Spotify for want of the extensions may take to start there. */
    private const val FALLBACK_START_MS = 10_000L
    private const val FALLBACK_LOOK_MS = 500L
    /** How long a resume pulled from another device waits to play here before the extensions are not asked. */
    private const val RESUME_AFTER_PULL_MS = 20_000L
    private const val MAX_FALLBACK_FAILURES = 3

    /** How long before its end the last song is played by Spotify, so its autoplay goes on at once. */
    private const val END_LEAD_MS = 1_000L

    /**
     * The audio-source extensions changed (one installed, turned on, updated or removed, or the
     * order of the sources): [added] gives audio now and did not, [any]: one gives audio. The songs
     * they had nothing for this session are asked again; the answers kept for the songs to come are
     * dropped (asked again in the new order). The local queue asks again for its next song, and the
     * song it stopped on for want of a source; with a new source while Spotify plays, the song after
     * the one playing goes to the extensions (as after a fallback), asked ahead. On the main thread.
     */
    fun audioSourcesChanged(added: List<String>, any: Boolean) {
        spotifyPlayed.clear()
        if (!any) return
        val local = LocalPlayer.active.value
        // The song playing, or the one being asked (a source picked for it in the player), keeps its answer.
        com.music.spotui.extensions.ExtensionAudio.forgetAllBut(if (local) LocalPlayer.current()?.let(LocalPlayer::spotifyIdOf) else routingState.value)
        if (local) { LocalPlayer.sourcesChanged(); return }
        if (added.isEmpty() || _activeDevice.value != null || routing || com.music.spotui.data.DataSaver.active) return
        val id = trackIdOf(_nowPlaying.value.uri).ifBlank { return }
        spotifyFallbackId = id
        val next = _queue.value.let { it.queued + it.nextUp }.map { it.song }.firstOrNull { it.spotifyTrackId.isNotBlank() && it.spotifyTrackId != id }
        AppLog.d("audio: ${added.joinToString()} gives audio now: the song after $id goes to the extensions${next?.let { ", ${it.title} asked ahead" } ?: ""}")
        if (next != null) scope.launch { runCatching { com.music.spotui.extensions.ExtensionAudio.warm(listOf(next)) } }
    }

    /** The songs the extensions had nothing for this session: a resume of one goes straight to Spotify. */
    private val spotifyPlayed = java.util.Collections.synchronizedSet(HashSet<String>())

    /**
     * The song Spotify plays because no extension had it: only that one falls back, the song after
     * it (a next, a previous, the engine moving on) is asked to the extensions again ([backToExtensions]).
     */
    private var spotifyFallbackId: String? = null

    /**
     * The song Spotify plays for want of the extensions while the local player played a queue, the
     * songs that came after it there, and that queue's name: the extensions go on with them
     * ([backToExtensions]) rather than with the engine's list, which has neither the songs the
     * user queued, nor the local order, nor the song radio.
     */
    private var fallbackRest: Triple<String, List<SongsModel>, String>? = null

    /**
     * [target], played after [leftId], asked to the extensions as a pick is, with [songs] (from it
     * on) as the list, when [leftId] is the song Spotify played for want of them. A song they
     * missed lately is not asked: Spotify plays it, and the one after it is asked. [fallback] (on
     * the main thread): they had nothing, the engine goes on. False: the engine goes on as usual.
     * Going [forward] off a song of the local queue, the song after it there is asked, not the engine's.
     */
    private fun backToExtensions(
        asked: SongsModel, leftId: String, songs: List<SongsModel>, forward: Boolean = true,
        spotifyFirst: Boolean = true, fallback: () -> Unit,
    ): Boolean {
        val target = fallbackRest?.takeIf { forward && it.first == leftId }?.second?.firstOrNull() ?: asked
        val id = target.spotifyTrackId
        val remote = _activeDevice.value != null || routing || LocalPlayer.active.value
        if (!com.music.spotui.extensions.AudioRoute.backFromFallback(spotifyFallbackId, leftId, id,
                com.music.spotui.extensions.Extensions.hasAudioSource(), remote)) return false
        if (id in spotifyPlayed || com.music.spotui.extensions.Extensions.missedLately(id)) {
            spotifyFallbackId = id
            // Spotify plays this one too: the local queue goes on after it.
            fallbackRest = fallbackRest?.takeIf { it.first == leftId }?.let { (_, rest, n) ->
                com.music.spotui.extensions.AudioRoute.resumeList(rest, id)?.let { Triple(id, it.drop(1), n) }
            }
            return false
        }
        AppLog.d("audio: back to the extensions for ${target.title}")
        val ctx = _nowPlaying.value.contextUri
        val local = fallbackRest?.takeIf { it.first == leftId }?.let { (_, rest, name) ->
            com.music.spotui.extensions.AudioRoute.resumeList(rest, id)?.let { it to name }
        }
        val name = local?.second ?: knownContextName(ctx)
        val shuffle = isShuffleOn()
        val routeList = local?.first ?: songs
        playThroughExtensions(id, target, name, fallback, songs = routeList, contextUri = ctx,
            spotifyFirst = spotifyFirst && local == null && target.spotifyTrackId == asked.spotifyTrackId, spotifySkip = forward) { isLatest, shown ->
            com.music.spotui.extensions.ExtensionAudio.route(id, routeList, name, shuffle, ctx, isLatest, shown)
        }
        return true
    }

    /** [first] then the engine's songs after it, for the extensions' list. */
    private fun upcomingSongs(first: SongsModel): List<SongsModel> {
        val up = _queue.value.let { it.queued + it.nextUp }.map { it.song }.filter { it.spotifyTrackId.isNotBlank() }
        val from = up.indexOfFirst { it.spotifyTrackId == first.spotifyTrackId }
        return listOf(first) + if (from >= 0) up.drop(from + 1) else up.filter { it.spotifyTrackId != first.spotifyTrackId }
    }

    /**
     * A resume of the engine's paused song with an audio-source extension on (after a launch, the
     * mini player, the notification, headphones) is asked there first, from where it was, with
     * the engine's queue after it; Spotify resumes when they have nothing. False: Spotify resumes.
     */
    /** A resume sent to Spotify because another device played: the song and when, until it plays here. */
    @Volatile private var resumeAfterPull: Pair<String, Long>? = null

    private fun resumeThroughExtensions(restoredLocal: Boolean = false): Boolean {
        val np = _nowPlaying.value
        val id = trackIdOf(np.uri)
        val ext = com.music.spotui.extensions.Extensions
        // The session put back at launch was the extensions' (this phone's local player): it goes
        // back to them, the extensions still starting are waited for ([Extensions.audio]), and a
        // device Spotify still lists as active (the page has not caught up yet) does not send it to Spotify.
        // Reported: a play right after a relaunch resumed on Spotify, and the source had to be picked again.
        val why = when {
            !np.uri.startsWith(SPOTIFY_TRACK_PREFIX) || id.isBlank() -> "not a song"
            routing -> "a song is being asked"
            _activeDevice.value != null && !restoredLocal -> "another device plays"
            id in spotifyPlayed -> "no extension had it this session"
            !ext.hasAudioSource() && !(restoredLocal && ext.audioSourceOn()) -> ext.audioSkipped() ?: "no audio source on"
            else -> null
        }
        if (why != null) {
            if (np.uri.startsWith(SPOTIFY_TRACK_PREFIX)) AppLog.d("audio: resume of $id on Spotify: $why")
            // Resumed here while another device played: Spotify brings it to this phone first, and
            // once it plays here the extensions take it on (reported: back from a Connect device,
            // the song stayed on Spotify; the mirror's own rule skips a move Myspoti asked for).
            if (_activeDevice.value != null && !restoredLocal && ext.hasAudioSource()) resumeAfterPull = id to SystemClock.elapsedRealtime()
            return false
        }
        val q = _queue.value
        val songs = (listOfNotNull(q.current) + (q.queued + q.nextUp).map { it.song }).takeIf { l -> l.any { it.spotifyTrackId == id } }
        AppLog.d("audio: resume of $id asked to the extensions")
        playSong(np.uri, contextUri = np.contextUri.ifBlank { null }, positionMs = getCurrentPosition(), songs = songs)
        return true
    }


    /**
     * A song picked on another device while the Connect mirror played: asked to the extensions as a
     * pick here is, from where the page is, with the page's queue after it; Spotify plays it when they
     * have nothing. An episode is Spotify's own and already plays there: it is only heard again.
     */
    fun followRemotePlay(item: app.myspoti.api.NowPlaying, contextUri: String?, positionMs: Long) {
        if (!item.uri.startsWith(SPOTIFY_TRACK_PREFIX)) {
            AccountSync.listen.stop("${item.uri} picked on another device", pauseRemote = false)
            LocalPlayer.stop()
            return
        }
        val after = apiQueue?.let { it.queued + it.nextUp }.orEmpty().filter { it.uri.startsWith(SPOTIFY_TRACK_PREFIX) && it.uri != item.uri }
        playSong(item.uri, contextUri = contextUri?.ifBlank { null }, positionMs = positionMs.takeIf { it > 0 },
            songs = listOf(songOf(item)) + after.map(::songOf), spotifyFirst = false)
    }

    /**
     * Playback came back to this phone (a transfer from another device, or picked here) after the
     * Connect mirror had handed it away: Spotify plays it here now, heard; the song goes back to the
     * extensions from where it is, as a resume does.
     */
    fun backThroughExtensions() {
        if (LocalPlayer.active.value || routing || !com.music.spotui.data.preferences.ConnectMirrorPref.on) return
        if (api.player.state.value?.isPaused != false) return
        _activeDevice.value = null
        MyspotiRuntime.spotify.player.remoteControl = false
        if (resumeThroughExtensions()) AppLog.d("mirror: playback back on this phone, the extensions play it again")
    }

    /** The song being resolved, as if it played (paused, loading): screens, notification, lyrics. */
    private fun showRouted(song: SongsModel) {
        val uri = SPOTIFY_TRACK_PREFIX + song.spotifyTrackId
        currentTrackId = song.spotifyTrackId
        durationMs = song.durationMs.toLong()
        val changed = _nowPlaying.value.uri != uri
        if (changed) _nowPlaying.value = NowPlaying(uri = uri, contextName = routingContext)
        // Its real saved state, as for a song Spotify plays: known at once when seen, else asked.
        val liked = likedFor(uri, library[uri] ?: false)
        // Its large cover, as a song Spotify plays shows (the list gave the small one).
        val cover = app.myspoti.host.android.Covers.large(song.coverUri)
        boundState?.let { st ->
            st.likeState.value = liked
            st.updateSongState(cover, song.title, song.singer, false, songIdFor(song.spotifyTrackId, uri), 0, song.album)
        }
        pushNotification(song.copy(coverUri = cover), liked)
        if (changed) refreshCurrentLiked()
        if (com.music.spotui.video.MusicVideoController.inForeground && app.myspoti.power.EnergySettings.state.value.policy.allowBackgroundLookups)
            com.music.spotui.data.api.LyricsApi.prefetch(lyricsTrack(song))
    }

    /** [by]: who asked, for the diagnostic (the app's screens, the media session, an extension...). */
    fun play(by: String = "user") {
        AppLog.d("play asked by $by")
        if (by != BY_CALL) callPause.userActed()
        userActed()
        if (routing) return // the song asked for starts by itself
        if (LocalPlayer.active.value) { Haptics.click(); if (!playDueOnSpotify()) LocalPlayer.resume(); return }
        val wasLocal = restoredLocal
        if (resumeRestoredLocal()) { Haptics.click(); return }
        if (resumeThroughExtensions(wasLocal)) { Haptics.click(); return }
        // Smart shuffle was turned off while paused: the list's order comes back as it plays on.
        plainOrderDue?.let { if (restorePlainOrder(it)) return }
        // Myspoti's shuffle turned on or off while paused: the song goes on in the list's new order.
        if (AppShuffle.resume()) { Haptics.click(); return }
        if (!isEpisode && refusedWithoutAccountPlayer(null, trackIdOf(_nowPlaying.value.uri))) return
        Haptics.click(); intendPlaying(); playing = true; positionAt = SystemClock.elapsedRealtime()
        // Loading until the page plays: the clock ran from the tap before, over silence when the
        // resume came late or never (reported on a slow network).
        if (api.player.state.value?.isPaused != false) bufferingState.value = true
        // Tapped on the restored mini player while the Web Player is still loading.
        if (!stateSeen) resumeWhenReady = true
        val uri = _nowPlaying.value.uri
        transport(checkAfter = true) { api.player.resume() }
        jamFollowUp(wantPaused = false)
        // An episode ignored by a plain resume (the page's element stays paused, which is what
        // "the podcast stopped and the play button does nothing" was — B11) is asked for again
        // by its uri, where it was. Music keeps the plain resume: it never showed that.
        if (!uri.startsWith("spotify:episode:")) return
        scope.launch {
            kotlinx.coroutines.delay(EPISODE_RESUME_CHECK_MS)
            if (!playing || LocalPlayer.active.value) return@launch
            val s = api.player.state.value
            if (s?.item?.uri == uri && s.isPaused) {
                Log.i(TAG, "episode resume not taken: playing $uri again (${queueTag()})")
                // In its show: played alone, Spotify goes on with its own autoplay after the episode.
                val ctx = _nowPlaying.value.contextUri.ifBlank { uri }
                runCatching { api.player.play(ctx, trackUri = uri.takeIf { ctx != it }, positionMs = getCurrentPosition()) }
            }
        }
    }

    private const val BY_CALL = "phone call"
    private val callPause = CallPause()
    // Read by the native player's thread. Do not change audio usage or request a call route.
    @Volatile internal var relaxCallFocus: Boolean = false
        private set

    /** Apply a setting change on the main thread, including during a call. */
    internal fun refreshCallPolicy() = phoneCall(app.myspoti.host.android.PhoneCall.busy)

    /** Updates app-managed audio focus, then handles the fallback call pause. Main thread. */
    private fun phoneCall(busy: Boolean) {
        val allowMusic = com.music.spotui.data.preferences.MusicDuringCallsPref.on
        val relaxFocus = shouldRelaxCallFocus(optedIn = allowMusic, busy = busy)
        if (relaxFocus != relaxCallFocus) {
            relaxCallFocus = relaxFocus
            LocalPlayer.refreshAudioFocus()
            NativeAudio.refreshAudioFocus()
            AppLog.d("music during calls: ${if (relaxFocus) "call mode" else "normal focus"}")
        }
        if (LocalPlayer.holdsFocus || MyspotiRuntime.spotify.player.playsElsewhere.value ||
            com.music.spotui.cast.CastPlayback.active) {
            callPause.userActed()
            return
        }
        when (callPause.modeChanged(busy, isPlaying(), SystemClock.elapsedRealtime(), allowMusic = allowMusic)) {
            CallPause.Action.PAUSE -> pause(by = BY_CALL)
            CallPause.Action.RESUME -> play(by = BY_CALL)
            CallPause.Action.NONE -> Unit
        }
    }

    fun pause(by: String = "user") {
        if (by != BY_CALL) callPause.userActed()
        AppLog.d("pause asked by $by")
        userActed()
        routeAsk.incrementAndGet(); routingState.value = null; routingSongs = null
        Haptics.click(); cancelBurst(); pauseSilently()
        app.myspoti.host.android.PlaybackService.pausedOnPurpose()
    }

    /** [send] false: the engine has paused already (the sleep timer's fade). */
    private fun pauseSilently(send: Boolean = true) {
        invalidateHandoff()
        if (LocalPlayer.active.value) { LocalPlayer.pause(); return }
        intendPaused()
        positionMs = getCurrentPosition(); positionAt = SystemClock.elapsedRealtime(); playing = false
        if (send) { transport(pullBack = false) { api.player.pause() }; jamFollowUp(wantPaused = true) }
    }

    /**
     * In a Jam this phone controls (the music on the host's device): a play or pause the host has
     * not followed [JAM_FOLLOW_MS] later is sent once more. Reported: "starting the sound from the
     * phone does not work": the first play after joining was answered 202 by Spotify and never
     * reached the host; the next one did.
     */
    private fun jamFollowUp(wantPaused: Boolean) {
        val jam = api.jam.session.value ?: return
        if (jam.isHost || jam.listensHere) return
        scope.launch {
            kotlinx.coroutines.delay(JAM_FOLLOW_MS)
            if (playing == wantPaused) return@launch // asked otherwise since
            kotlinx.coroutines.withTimeoutOrNull(RECONCILE_READ_MS) { runCatching { MyspotiRuntime.spotify.player.refresh() } }
            val s = api.player.state.value ?: return@launch
            if (s.isPaused == wantPaused || playing == wantPaused) return@launch
            AppLog.d("jam: the host did not ${if (wantPaused) "pause" else "play"} in ${JAM_FOLLOW_MS / 1000} s, sent again")
            transport(pullBack = false) { if (wantPaused) api.player.pause() else api.player.resume() }
        }
    }
    private val JAM_FOLLOW_MS = 3_000L

    fun stop() = pause()

    /**
     * Next, from any control: the player, the mini player, the notification, headphones, the car,
     * the widget. The song it lands on is shown at once ([showSkipTarget]) and stays shown until the
     * page plays it or the skip fails. Only the in-app buttons showed it before, for [PENDING_MS] at
     * most: on a slow network the skip took longer and the screen went back to the old song
     * (reported: "Next does not move").
     */
    fun next(by: String = "user") {
        Log.d(TAG, "next tapped")
        AppLog.d("next asked by $by")
        userActed()
        Haptics.click()
        if (stepWhileRoutingOrCold(forward = true)) return
        if (MixedPlaylistQueue.active) { MixedPlaylistQueue.step(forward = true); return }
        if (LocalPlayer.active.value) { LocalPlayer.next(); return }
        cancelRepeatOnce("next")
        com.music.spotui.extensions.Extensions.skipAsked("forward")
        // Spotify is refusing licences: every skip asks for one more and makes the limit last
        // (a tester's log: 183 refusals in 8 min of fast skipping, the page then skipping on its
        // own through songs it could not play). Nothing is sent until the limit is over.
        if (MyspotiRuntime.host.licenseLimited()) {
            android.widget.Toast.makeText(Graph.app, app.myspoti.engine.R.string.spotify_limited, android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        // A cold extension lookup must not hold a skip off a Spotify fallback. Dispatch it
        // through the same transport and burst rules as any other Spotify skip.
        if (pendingSkips == 0 && (NativeAudio.on || SystemClock.elapsedRealtime() - skipSentAt >= MIN_SKIP_GAP_MS)) _queue.value.let { it.queued + it.nextUp }.firstOrNull()?.song?.let { t ->
            if (backToExtensions(t, trackIdOf(_nowPlaying.value.uri), upcomingSongs(t), fallback = ::sendNext)) return
        }
        if (!isEpisode && refusedWithoutAccountPlayer(null, trackIdOf(_nowPlaying.value.uri))) return
        sendNext()
    }

    private fun sendNext() {
        intendPlaying()
        tapSeq++
        // The first tap skips at once. Taps that follow it within SKIP_BURST_MS, or within
        // MIN_SKIP_GAP_MS of the last skip sent, become one jump to the song they add up to: a
        // burst of "next" commands left the Web Player out of step (state conflicts, then a
        // player stuck until reloaded), and each song skipped through asks for a licence.
        val now = SystemClock.elapsedRealtime()
        if (NativeAudio.on && _activeDevice.value == null) {
            cancelBurst()
            pendingSkip = 0
            pendingTrackId = null
            pendingItemUri = null
            bufferingState.value = true
            skipSentAt = now
            positionMs = 0L
            positionAt = now
            NativeAudio.skipNextQueued()
            return
        }
        val sinceSent = now - skipSentAt
        if (now - burstAt > SKIP_BURST_MS && sinceSent >= MIN_SKIP_GAP_MS) {
            burstAt = now
            burstUpcoming = apiQueue?.let { it.queued + it.nextUp }.orEmpty()
            burstTaps = 1
            pendingSkips = 0
            skipSentAt = now
            // The next song starts at 0: a previous tapped before Spotify reports must not read
            // the old song's position and restart instead of going back.
            positionMs = 0L
            positionAt = now
            val shown = showSkipTarget()
            // Reported: one skip went two songs on. A song that ends while the skip waits its turn
            // (the device check, a command still running, a slow page) is left by the page on its
            // own, and the skip then left the next song too. The skip is for the song it was
            // tapped on: gone already, it is not sent.
            val tappedOn = api.player.state.value?.item?.uri
            // The device check after the skip, as for a resume: before it, a slow network held
            // every skip for the device list's round trip (up to DEVICES_WAIT_MS).
            transport(waitReady = !stateSeen, checkAfter = true, pullBack = false, done = { ok -> skipDone(shown, ok) }) {
                val now = api.player.state.value?.item?.uri
                if (tappedOn != null && now != null && now != tappedOn) {
                    AppLog.d("next not sent: the song it was tapped on had already ended")
                    return@transport
                }
                api.player.next()
            }
            return
        }
        burstAt = now
        // A burst whose first tap was held (it came too soon after the last skip sent, e.g. a
        // previous): its songs are counted from the one playing now, none of its taps sent yet.
        if (burstTaps == 0 || burstUpcoming.isEmpty()) {
            burstUpcoming = apiQueue?.let { it.queued + it.nextUp }.orEmpty()
            burstTaps = 0
        }
        burstTaps++
        pendingSkips++
        showSkipTarget()
        main.removeCallbacks(sendSkips)
        main.postDelayed(sendSkips, maxOf(SKIP_BURST_MS, MIN_SKIP_GAP_MS - sinceSent))
    }

    /** Hands out the tokens of [showSkipTarget]; 0 is never one. */
    private var skipShownSeq = 0
    /** The skip whose song is pending on screen; 0 when the pending song is not a skip's (a pick). */
    private var pendingSkip = 0

    /**
     * Shows the song the taps so far land on, before the page plays it: the song after the one
     * playing at the first tap, or [burstTaps] songs after it. -> the token [skipDone] is told
     * with, 0 when the target is unknown (the page's own states then show where it lands).
     */
    private fun showSkipTarget(): Int {
        val token = ++skipShownSeq
        // Reported (beta.9): each fast tap showed `nowPlaying.next` — the same second song every
        // time, held as pending, so the screen stayed on it for seconds while the page went on to
        // the fifth. A burst shows the song its taps add up to.
        val n = if (burstTaps <= 1) _nowPlaying.value.next
            else burstUpcoming.getOrNull(burstTaps - 1)?.let(::songOf)
        if (n == null) {
            pendingTrackId = null
            pendingItemUri = null
            pendingSkip = 0
            return 0
        }
        markPending(n.spotifyTrackId, holdMs = SKIP_PENDING_MAX_MS)
        pendingSkip = token
        boundState?.updateSongState(n.coverUri, n.title, n.singer, true, n.id, 0, n.album)
        durationMs = n.durationMs.toLong()
        pushNotification(n, false)
        return token
    }

    /**
     * The skip shown as [token] was answered ([ok]): the page now has [SKIP_ANSWERED_MS] to report the
     * song. Not answered (failed, timed out, dropped): the screen goes back at once to what the
     * page really plays, instead of showing a song nothing is going to play. A newer skip or a
     * pick shown since owns the screen, and is left alone.
     */
    private fun skipDone(token: Int, ok: Boolean) {
        if (token == 0 || token != pendingSkip || pendingTrackId == null) return
        if (ok) {
            val now = SystemClock.elapsedRealtime()
            pendingUntil = minOf(pendingUntil, now + SKIP_ANSWERED_MS)
            reconcileAfter(pendingEnded, pendingUntil - now)
            return
        }
        Log.w(TAG, "skip not taken by the page: the screen shows what it plays")
        pendingSkip = 0
        pendingTrackId = null
        pendingItemUri = null
        applyState(api.player.state.value)
    }

    /** When the last skip command left (see [next]). */
    private var skipSentAt = 0L

    /** When the last "next" tap came, the queue as it was at the first one, and the taps since. */
    private var burstAt = 0L
    private var burstUpcoming: List<app.myspoti.api.NowPlaying> = emptyList()
    private var burstTaps = 0
    private var pendingSkips = 0
    private val sendSkips = Runnable {
        if (pendingSkips <= 0) return@Runnable
        pendingSkips = 0
        skipSentAt = SystemClock.elapsedRealtime()
        // The song [burstTaps] after the one playing at the first tap.
        val target = burstUpcoming.getOrNull(burstTaps - 1)
        AppLog.d("next taps merged: $burstTaps skips${if (target != null) " in one jump to ${target.name}" else ", sent as a plain next"}")
        val shown = pendingSkip
        transport(waitReady = !stateSeen, checkAfter = true, pullBack = false, done = { ok -> skipDone(shown, ok) }) {
            if (target == null) api.player.next() else api.player.skipTo(target)
        }
        if (target != null && (!NativeAudio.on || _activeDevice.value != null)) {
            burstTarget = target
            burstContext = _nowPlaying.value.contextUri
            burstSeq++
            verifyTap = tapSeq
            main.removeCallbacks(verifyBurst)
            main.postDelayed(verifyBurst, BURST_VERIFY_MS)
        }
    }

    /*
     * Measured on the test phone: the burst's first "next" is acknowledged by the page, applied
     * a second late, after the jump to the target — the page then lands one song past it (the
     * screen showed the target, the speaker the song after). Where the burst landed is checked,
     * and the target played by name when it is not there.
     */
    private var burstTarget: app.myspoti.api.NowPlaying? = null
    private var burstContext = ""
    private var burstSeq = 0
    private var lastPageUri = ""

    /** Bumped by every user transport action (tap or pick); [verifyBurst] only runs if it did not move since it was scheduled. */
    private var tapSeq = 0
    private var verifyTap = 0
    private const val BURST_VERIFY_MS = 2_500L
    private val verifyBurst = Runnable {
        val t = burstTarget ?: return@Runnable
        burstTarget = null
        if (NativeAudio.on && _activeDevice.value == null) return@Runnable
        val seq = burstSeq
        val tap = verifyTap
        // A newer tap, pick or pause: the user moved on (a reported log: a previous pressed
        // 1 s after the burst was undone by this check, which played the burst's song again).
        if (tap != tapSeq || SystemClock.elapsedRealtime() - burstAt < BURST_VERIFY_MS || !playing) return@Runnable
        if (lastPageUri == t.uri || burstContext.isBlank()) return@Runnable
        Log.d(TAG, "skips landed on $lastPageUri, not ${t.name}: playing it (${queueTag()})")
        AppLog.d("skips landed on another song than ${t.name}: it is played by name")
        // In the order it was played in (a sorted list, a smart shuffle), and a song the user
        // queued is not in the list: asking for it there would restart the list.
        if (t.provider == "queue") return@Runnable
        val order = playedOrder?.takeIf { it.first == burstContext }?.second
        transport { if (seq == burstSeq && tap == tapSeq) api.player.play(burstContext, t.uri, order = order) }
    }

    /**
     * The user does something else than "next" (a pick, a pause, a seek, a previous): whatever
     * the burst still had to send or check is dropped, or it would undo that action (reported:
     * a previous after two nexts was overridden by the burst's jump, then by its check).
     */
    private fun cancelBurst() {
        tapSeq++
        pendingSkips = 0
        burstTarget = null
        burstTaps = 0
        burstAt = 0L
        burstUpcoming = emptyList()
        main.removeCallbacks(sendSkips)
        main.removeCallbacks(verifyBurst)
    }

    /** "shuffle=…, next=[…]": the page's shuffle flag and the first upcoming songs, for the play logs. */
    private fun queueTag(): String {
        val up = apiQueue?.let { it.queued + it.nextUp }.orEmpty().take(5).joinToString { it.name.take(30) }
        return "shuffle=${api.player.state.value?.shuffle} next=[$up]"
    }

    fun previous(by: String = "user") {
        AppLog.d("previous asked by $by")
        userActed()
        Haptics.click()
        if (stepWhileRoutingOrCold(forward = false)) return
        if (MixedPlaylistQueue.active) {
            if (getCurrentPosition() > 3_000L) seekTo(0L) else MixedPlaylistQueue.step(forward = false)
            return
        }
        if (LocalPlayer.active.value) { LocalPlayer.previous(); return }
        cancelRepeatOnce("previous")
        if (getCurrentPosition() <= 3_000) com.music.spotui.extensions.Extensions.skipAsked("backward")
        intendPlaying()
        // A previous counts as -1 in the burst. Skips still waiting to be sent (nexts tapped
        // within SKIP_BURST_MS) just lose one: next, next, previous is one next, and nothing
        // is sent for the previous. Once the burst has left (or there is none), previous is a
        // plain one, and the burst is forgotten so it cannot send or verify anything later.
        if (pendingSkips > 0) {
            pendingSkips--
            burstTaps--
            tapSeq++
            burstAt = SystemClock.elapsedRealtime()
            if (pendingSkips == 0) main.removeCallbacks(sendSkips)
            return
        }
        // Off a song Spotify played for want of an extension (a previous that goes back a song).
        if (getCurrentPosition() <= 3_000) _nowPlaying.value.prev?.let { t ->
            val songs = listOf(t) + upcomingSongs(_queue.value.current ?: t).filter { it.spotifyTrackId != t.spotifyTrackId }
            if (backToExtensions(t, trackIdOf(_nowPlaying.value.uri), songs, forward = false) { intendPlaying(); transport(pullBack = false) { api.player.previous() } }) return
        }
        cancelBurst()
        val now = SystemClock.elapsedRealtime()
        skipSentAt = now
        positionMs = 0L
        positionAt = now
        if (NativeAudio.on && _activeDevice.value == null) {
            pendingSkip = 0
            pendingTrackId = null
            pendingItemUri = null
            NativeAudio.skipPrevQueued()
            return
        }
        transport(waitReady = !stateSeen, checkAfter = true, pullBack = false) { api.player.previous() }
    }

    /** Tracks shufflePlay plays without a context: the first one, plus up to 49 queued. */
    private const val SHUFFLE_QUEUE_MAX = 50
    /** After pulling playback back, the page needs a moment before it takes commands. */
    private const val PULL_BACK_SETTLE_MS = 600L
    private const val PULL_BACK_WAIT_MS = 6_000L
    private const val DEVICES_WAIT_MS = 2_000L
    private const val DISCOVERY_WAIT_MS = 800L

    /**
     * How long the device list read by [takeBackPlayback] is trusted. Long enough that a burst of
     * taps pays for it once, short enough that a device taking playback in between is noticed.
     */
    private const val DEVICES_FRESH_MS = 10_000L
    /** A transport command waits that long for the page to load before it is dropped. */
    private const val READY_WAIT_MS = 30_000L

    /**
     * Shuffle-play a list: Spotify picks the first track of its own shuffled context. With an
     * audio-source extension on, it is asked first for a random song of the list, which then
     * plays shuffled in the local player.
     */
    fun shufflePlay(songs: List<SongsModel>, askExtensions: Boolean = true) {
        if (songs.isEmpty()) return
        invalidateHandoff()
        val first = if (askExtensions && com.music.spotui.extensions.Extensions.hasAudioSource()) com.music.spotui.extensions.AudioRoute.shufflePick(songs) else null
        if (askExtensions && first == null) com.music.spotui.extensions.Extensions.audioSkipped()?.let {
            AppLog.d("audio: $it, Spotify shuffles the list")
        }
        if (first != null) {
            val ctx = contextRegistry[songs.first().url].orEmpty()
            playThroughExtensions(first.spotifyTrackId, first, knownContextName(ctx), { shufflePlay(songs, askExtensions = false) }, songs = songs, contextUri = ctx, spotifyFirst = false) { isLatest, _ ->
                com.music.spotui.extensions.ExtensionAudio.playList(songs, first, knownContextName(ctx), true, ctx, isLatest)
            }
            return
        }
        if (refusedWithoutAccountPlayer(songs.first().title, songs.first().spotifyTrackId)) return
        routeAsk.incrementAndGet(); routingState.value = null
        LocalPlayer.stop()
        val ctx = contextRegistry[songs.first().url]
        cancelBurst()
        intendPlaying()
        transport {
            api.player.setShuffle(true)
            Log.d(TAG, "shuffle-playing ${ctx ?: "a shuffled list"}: ${queueTag()}")
            if (ctx == null) {
                // No registered context: play the list in a shuffled order (first
                // track now, the rest queued), not one random song alone. Capped at
                // SHUFFLE_QUEUE_MAX tracks: the queue is the user's Spotify queue,
                // which outlives this list and follows them to every device, so
                // queuing all of Liked Songs would bury whatever they play next.
                val order = songs.shuffled().take(SHUFFLE_QUEUE_MAX)
                api.player.play(order.first().url)
                if (order.size > 1) api.player.addToQueue(order.drop(1).map { it.url })
            } else {
                api.player.play(ctx)
                if (NativeAudio.on && _activeDevice.value == null) return@transport
            }
            kotlinx.coroutines.delay(1500)
            api.player.setShuffle(true)
        }
    }

    /** The list and the order of the last play that was not a smart shuffle's (null: the list's own). */
    @Volatile private var plainOrder: Pair<String, List<String>?>? = null
    /** The list a smart shuffle is playing as its own mixed order. */
    @Volatile private var smartPlayed: String? = null
    /** Smart shuffle ended on this list while paused: its order comes back at the next play. */
    @Volatile private var plainOrderDue: String? = null

    /** The list and order of the last play, kept for the replays that name a song only. */
    @Volatile private var playedOrder: Pair<String, List<String>?>? = null

    private fun endSmartShuffle(ctx: String) {
        if (smartPlayed != ctx) return
        smartPlayed = null
        if (_nowPlaying.value.contextUri != ctx) return
        if (playing) restorePlainOrder(ctx) else plainOrderDue = ctx
    }

    /** Plays the song now playing again in [ctx] as it was before the smart shuffle, where it is. */
    private fun restorePlainOrder(ctx: String): Boolean {
        plainOrderDue = null
        val uri = _nowPlaying.value.uri
        if (_nowPlaying.value.contextUri != ctx || uri.isBlank() || LocalPlayer.active.value) return false
        val song = if (uri.startsWith("spotify:episode:")) "episode:" + uri.substringAfterLast(':') else uri
        Log.d(TAG, "smart shuffle off: $ctx back in the list's order from ${_nowPlaying.value.uri}")
        playSong(song, contextUri = ctx, order = plainOrder?.takeIf { it.first == ctx }?.second, positionMs = getCurrentPosition())
        return true
    }

    /** Shuffle as the player shows it (Spotify's, or the local queue's). */
    fun isShuffleOn(): Boolean = if (LocalPlayer.active.value) LocalPlayer.shuffled else boundState?.shuffle?.value == true

    fun setShuffle(on: Boolean) {
        Haptics.toggle(on)
        // Neither of these has a page state to bring the news to the media session.
        if (LocalPlayer.active.value) LocalPlayer.setShuffle(on)
        else if (!AppShuffle.toggle(on)) { setPageShuffle(on); return }
        pushNotification(null, boundState?.likeState?.value ?: false)
    }

    /** Spotify's own shuffle, set on the page (Myspoti's, [AppShuffle], keeps it off). */
    internal fun setPageShuffle(on: Boolean) {
        shuffleWanted = on
        shuffleWantedUntil = SystemClock.elapsedRealtime() + SHUFFLE_HOLD_MS
        command { api.player.setShuffle(on) }
    }

    // Reported: shuffle out of step between the list and the player. A state the page sent
    // before it took the tap flipped the button back, and the two screens then disagreed; the
    // value asked for holds until the page reports it (or for SHUFFLE_HOLD_MS).
    @Volatile private var shuffleWanted = false
    /** The repeat mode last tapped, held against the page's older reports like [shuffleWanted]. */
    @Volatile private var repeatWanted = 0
    @Volatile private var repeatWantedUntil = 0L
    @Volatile private var shuffleWantedUntil = 0L
    private const val SHUFFLE_HOLD_MS = 2_500L

    /** 0 = off, 1 = context, 2 = track for good, 3 = track once (see [LocalRepeat]). */
    private val _repeatMode = mutableStateOf(0)
    val repeatMode: State<Int> get() = _repeatMode

    fun setRepeat(on: Boolean) = setRepeatMode(if (on) 1 else 0)

    fun setRepeatMode(mode: Int) {
        if (LocalPlayer.active.value) { _repeatMode.value = mode; boundState?.repeat?.value = mode != 0; LocalPlayer.setRepeatMode(mode); lastTrackPrefs().edit().putInt("repeat", mode.coerceIn(0, 3)).apply(); return }
        Haptics.toggle(mode != 0)
        _repeatMode.value = mode
        repeatWanted = LocalRepeat.pageMode(mode)
        repeatWantedUntil = SystemClock.elapsedRealtime() + SHUFFLE_HOLD_MS
        boundState?.repeat?.value = mode != 0
        lastTrackPrefs().edit().putInt("repeat", mode.coerceIn(0, 3)).apply()
        command { api.player.setRepeat(Repeat.entries[LocalRepeat.pageMode(mode)]) }
    }

    /**
     * Reported: the repeat button forgets what it was. The mode is the user's choice, kept from
     * one run of the app to the next (the page always starts with repeat off): shown at once and
     * set again on the first song the page reports.
     */
    private fun restoreRepeat(state: CurrentSongState) {
        val p = lastTrackPrefs()
        if (!p.contains("repeat")) return
        val mode = p.getInt("repeat", 0).coerceIn(0, 3)
        _repeatMode.value = mode
        state.repeat.value = mode != 0
        MyspotiRuntime.spotify.player.restoreRepeat(Repeat.entries[LocalRepeat.pageMode(mode)])
    }

    /** Off, the queue, the song for good, the song once, off. */
    fun cycleRepeat() = setRepeatMode((_repeatMode.value + 1) % 4)

    /** A manual move on a Spotify song cancels repeat once: it was for the song left. */
    private fun cancelRepeatOnce(why: String) {
        if (_repeatMode.value != LocalRepeat.ONCE) return
        AppLog.d("repeat once: cancelled ($why), back to off")
        setRepeatMode(LocalRepeat.OFF)
    }

    private const val PODCAST_SPEED_PREF = "podcast_speed"
    private var speedWanted = 1.0
    private var speedWantedUntil = 0L
    private var lastAppliedEpisodeSpeedUri = ""

    private fun loadSavedPodcastSpeed(): Double =
        runCatching {
            Graph.app.getSharedPreferences("myspoti_prefs", Context.MODE_PRIVATE)
                .getFloat(PODCAST_SPEED_PREF, 1f).toDouble().coerceIn(0.5, 3.5)
        }.getOrDefault(1.0)

    fun setSpeed(speed: Double) {
        val clamped = (kotlin.math.round(speed.coerceIn(0.5, 3.5) * 20.0) / 20.0)
        positionMs = getCurrentPosition()
        positionAt = SystemClock.elapsedRealtime()
        _speed.value = clamped
        speedWanted = clamped
        speedWantedUntil = SystemClock.elapsedRealtime() + 4_000L
        runCatching {
            Graph.app.getSharedPreferences("myspoti_prefs", Context.MODE_PRIVATE)
                .edit().putFloat(PODCAST_SPEED_PREF, clamped.toFloat()).apply()
        }
        LocalPlayer.setEpisodeSpeed(clamped.toFloat())
        command { api.player.setSpeed(clamped) }
        boundState?.let { pushNotification(null, it.likeState.value) }
    }

    private val _speed = mutableStateOf(1.0)
    /** The speed Spotify reports for what plays (podcasts only); 1.0 for music. */
    val speed: State<Double> get() = _speed

    /** Lands within the episode when skipping: Spotify refuses a position past the end. */
    fun skipBy(deltaMs: Long) {
        val duration = getDuration()
        val target = (getCurrentPosition() + deltaMs).coerceAtLeast(0L)
        seekTo(if (duration > 0) target.coerceAtMost(duration - 1_000L) else target)
    }

    /** "Add to queue" for a podcast episode (its uri, not a track id). */
    fun addEpisodeToQueue(url: String) {
        val id = url.removePrefix("episode:").takeIf { url.startsWith("episode:") } ?: return
        Haptics.confirm()
        command { api.player.addToQueue(listOf("spotify:episode:$id")) }
    }

    /**
     * What plays is a podcast episode: the player shows its own controls (30-second-free
     * skips, speed, no shuffle), not the music ones.
     */
    val isEpisode: Boolean get() = _nowPlaying.value.uri.startsWith("spotify:episode:")

    fun lyricsTrack(s: SongsModel) = com.music.spotui.data.api.LyricsApi.Track(
        trackId = s.spotifyTrackId, title = s.title, artist = s.singer, album = s.album,
        durationMs = s.durationMs.toLong().takeIf { it > 0 } ?: durationMs, coverUrl = s.coverUri,
    )

    /** The lyrics request for what is playing now. */
    fun currentLyricsTrack(): com.music.spotui.data.api.LyricsApi.Track? {
        val st = boundState ?: return null
        val title = st.title.value
        if (title.isBlank()) return null
        return com.music.spotui.data.api.LyricsApi.Track(
            trackId = currentTrackId, title = title, artist = st.singer.value, album = st.album.value,
            durationMs = durationMs, coverUrl = st.coverUri.value,
        )
    }

    /** Save / remove the current track in Liked Songs. */
    fun setLiked(on: Boolean) {
        // A file of the device is not in the Spotify library; a stream or a download is.
        if (LocalPlayer.active.value && !routing && localSpotifyUri(LocalPlayer.current()) == null) {
            AppLog.d("library: like not sent, the local song has no Spotify id (${LocalPlayer.current()?.uri?.scheme})")
            return
        }
        Haptics.toggle(on)
        val uri = currentLikeUri().ifBlank { if (currentTrackId.isNotBlank()) SPOTIFY_TRACK_PREFIX + currentTrackId else "" }
        if (uri.isBlank()) { boundState?.likeState?.value = on; AppLog.d("library: like not sent, no song id"); return }
        setSaved(uri, on)
    }

    // ── Library state (Liked Songs, saved albums / playlists, followed artists) ──
    /** What Spotify's library says about each uri seen so far; every screen reads this. */
    val library: androidx.compose.runtime.snapshots.SnapshotStateMap<String, Boolean> =
        androidx.compose.runtime.mutableStateMapOf()

    /** Confirmed by Spotify less than that long ago: not asked for again (see [libraryContains]). */
    private const val SAVED_FRESH_MS = 60_000L

    /** A check of the song shown that got no answer is made once more after this long. */
    private const val LIKE_RETRY_MS = 2_500L

    /** After a check that failed twice, page states do not start another before this long. */
    private const val LIKE_RETRY_AFTER_MS = 30_000L

    /** When Spotify (or the user's own tap) last settled each uri. */
    private val savedAt = java.util.concurrent.ConcurrentHashMap<String, Long>()

    /** One request in flight per uri list, so two callers asking share it. */
    private val savedFlights =
        java.util.concurrent.ConcurrentHashMap<String, kotlinx.coroutines.Deferred<List<Boolean>?>>()
    private val savedFlightLock = kotlinx.coroutines.sync.Mutex()
    /** Why the last request for saved states got no answer (logged by [refreshCurrentLiked]). */
    @Volatile private var savedError = ""

    // The user's last like/unlike wins briefly over states that were already in flight.
    @Volatile private var intentUri = ""
    @Volatile private var intentValue = false
    @Volatile private var intentUntil = 0L

    private fun likedFor(uri: String, reported: Boolean): Boolean =
        if (uri == intentUri && SystemClock.elapsedRealtime() < intentUntil) intentValue else reported

    private fun onLibraryItem(uri: String, saved: Boolean) {
        if (uri == intentUri && SystemClock.elapsedRealtime() < intentUntil && saved != intentValue) return
        library[uri] = saved
        savedAt[uri] = SystemClock.elapsedRealtime()
        if (uri == currentLikeUri()) {
            boundState?.likeState?.value = saved
            pushNotification(null, saved)
        }
        if (!saved && uri.startsWith(SPOTIFY_TRACK_PREFIX)) {
            val id = trackIdOf(uri)
            com.music.spotui.data.api.Api.LikedCache.tracks =
                com.music.spotui.data.api.Api.LikedCache.tracks?.filterNot { it.spotifyTrackId == id }
        }
    }

    // Rows ask for their saved state one by one; ask Spotify in one batch per frame.
    private val wantedSaved = java.util.Collections.synchronizedSet(LinkedHashSet<String>())
    private val flushSaved = Runnable {
        val uris = synchronized(wantedSaved) { wantedSaved.toList().also { wantedSaved.clear() } }
        if (uris.isNotEmpty()) scope.launch { uris.chunked(50).forEach { libraryContains(it) } }
    }

    /** Make sure [uri]'s saved state ends up in [library]. */
    fun requestSaved(uri: String) {
        // An entry older than [SAVED_FRESH_MS] is asked again (it may have changed in another app); [libraryContains] skips the fresh ones.
        if (uri.isBlank() || (library.containsKey(uri) && SystemClock.elapsedRealtime() - (savedAt[uri] ?: 0L) < SAVED_FRESH_MS)) return
        if (wantedSaved.add(uri)) { main.removeCallbacks(flushSaved); main.postDelayed(flushSaved, 32) }
    }

    /** The in-app swipe and button: [next], which shows the song it lands on at once. */
    fun swipeNext() = next()

    fun swipePrevious() {
        userActed()
        Haptics.click()
        if (stepWhileRoutingOrCold(forward = false, restartAllowed = false)) return
        if (LocalPlayer.active.value) { LocalPlayer.previousItem(); return }
        val np = _nowPlaying.value
        val target = np.prev ?: return
        val uri = target.url.takeIf { it.startsWith("spotify:") || it.startsWith("episode:") }
            ?: target.spotifyTrackId.takeIf { it.isNotBlank() }?.let { SPOTIFY_TRACK_PREFIX + it } ?: return
        cancelBurst()
        playSong(uri, contextUri = np.contextUri.ifBlank { null }, songs = upcomingSongs(target))
    }

    /**
     * A seek the page has not shown yet: the song, the position asked for, when it was asked and
     * until when it holds. States of that song from before the seek (the old position) do not move
     * the clock back meanwhile. Reported: the bar dragged to a new place jumped back, the song
     * playing on from where it was — a state still on the old position, taken over the seek.
     */
    @Volatile private var seekUri = ""
    @Volatile private var seekTarget = 0L
    @Volatile private var seekAt = 0L
    @Volatile private var seekUntil = 0L
    private var seekJob: kotlinx.coroutines.Job? = null
    private var seekSeq = 0
    private val seekEnded = Runnable { reconcile() }

    /** [s] is the song a seek was asked on, somewhere it can have got to since. */
    private fun seekLanded(s: PlayerState): Boolean {
        if (s.item?.uri != seekUri) return false
        val at = s.positionAt(System.currentTimeMillis())
        val played = SystemClock.elapsedRealtime() - seekAt
        return at >= seekTarget - SEEK_NEAR_MS && at <= seekTarget + played + SEEK_NEAR_MS
    }

    private fun seekHeld(uri: String) = uri == seekUri && SystemClock.elapsedRealtime() < seekUntil

    fun seekTo(ms: Long) {
        invalidateHandoff()
        if (LocalPlayer.active.value) { LocalPlayer.seekTo(ms); return }
        cancelBurst()
        val now = SystemClock.elapsedRealtime()
        positionMs = ms
        positionAt = now
        seekUri = _nowPlaying.value.uri
        seekTarget = ms
        seekAt = now
        seekUntil = now + SEEK_HOLD_MS
        reconcileAfter(seekEnded, SEEK_HOLD_MS)
        // The newest seek only: a drag that ends while the last one is still on its way replaces it.
        val seq = ++seekSeq
        seekJob?.cancel()
        seekJob = scope.launch {
            try {
                // Sent once more when the page does not show it (busy, a slow network); after that
                // the page's word stands, wherever it is.
                repeat(2) { attempt ->
                    runCatching { kotlinx.coroutines.withTimeoutOrNull(SEEK_SEND_MS) { api.player.seek(ms) } }
                        .onFailure { if (it is kotlinx.coroutines.CancellationException) throw it; Log.w(TAG, "seek failed: ${it.message}") }
                    val landed = kotlinx.coroutines.withTimeoutOrNull(SEEK_CHECK_MS) {
                        api.player.state.first { it != null && (it.item?.uri != seekUri || seekLanded(it)) }
                    }
                    if (landed != null) return@launch
                    Log.w(TAG, "seek to $ms not taken by the page${if (attempt == 0) ": sent again" else ""}")
                }
            } finally {
                if (seq == seekSeq) {
                    seekUntil = 0L
                    main.removeCallbacks(seekEnded)
                    main.post { reconcile() }
                }
            }
        }
    }

    private val pendingLibraryUris = LinkedHashSet<String>()
    private const val MAX_PENDING_LIBRARY_URIS = 200

    /** What [checkLibrary] found: [saved] of the uris asked about, [asked] the ones that went to Spotify, [failed] when that got no answer. */
    private class LibraryCheck(val saved: Set<String>, val asked: Set<String>, val failed: Boolean)

    /** Which of [uris] are saved in the user's library (Liked Songs / saved albums…). */
    suspend fun libraryContains(uris: List<String>): Set<String> = checkLibrary(uris).saved

    private suspend fun checkLibrary(uris: List<String>): LibraryCheck {
        if (uris.isEmpty()) return LibraryCheck(emptySet(), emptySet(), false)
        val now = SystemClock.elapsedRealtime()
        // A page prefetch and the page opening ask for the same list within a second, and the
        // rows of a list ask again for what the list just confirmed: only what is unknown (or
        // old enough to have changed elsewhere) goes to Spotify.
        val (known, unknown) = uris.partition { library.containsKey(it) && now - (savedAt[it] ?: 0L) < SAVED_FRESH_MS }
        val out = known.filterTo(mutableSetOf()) { library[it] == true }
        if (unknown.isEmpty()) return LibraryCheck(out, emptySet(), false)
        val flags = savedFlags(unknown)
        if (flags == null) {
            if (!api.ready.value) {
                synchronized(pendingLibraryUris) {
                    for (u in unknown) {
                        if (pendingLibraryUris.size >= MAX_PENDING_LIBRARY_URIS) break
                        pendingLibraryUris.add(u)
                    }
                }
            }
            return LibraryCheck(out, emptySet(), true)
        }
        val saved = unknown.filterIndexed { i, _ -> flags.getOrNull(i) == true }.toSet()
        main.post {
            for (u in unknown) {
                if (u == intentUri && SystemClock.elapsedRealtime() < intentUntil) continue
                library[u] = u in saved
                savedAt[u] = now
            }
        }
        return LibraryCheck(out + saved, unknown.toSet(), false)
    }

    /** [uris] in one request; two callers asking the same list share that one request. */
    private suspend fun savedFlags(uris: List<String>): List<Boolean>? {
        val key = uris.sorted().joinToString("\n")
        val flight = savedFlightLock.withLock {
            savedFlights[key] ?: scope.async {
                try {
                    api.library.contains(uris)
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    savedError = e.message ?: e.javaClass.simpleName
                    null
                }
            }.also { d ->
                savedFlights[key] = d
                d.invokeOnCompletion { savedFlights.remove(key, d) }
            }
        }
        return try {
            flight.await()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    /** Bumped at every like / unlike of a track Spotify took: the Liked Songs page refreshes its top. */
    val likedChanges = kotlinx.coroutines.flow.MutableStateFlow(0)

    /** Every like / unlike of a track the moment it is tapped (and its undo): track id, liked. */
    val likedTaps = kotlinx.coroutines.flow.MutableSharedFlow<Pair<String, Boolean>>(extraBufferCapacity = 16)

    /** Like / unlike a track by id. */
    fun setTrackSaved(trackId: String, on: Boolean) {
        if (trackId.isBlank()) return
        Haptics.toggle(on)
        setSaved(SPOTIFY_TRACK_PREFIX + trackId, on)
    }

    /** Save / remove any item (album, playlist, track, artist, show, episode) in the user's library. */
    fun setSaved(uri: String, on: Boolean) {
        intentUri = uri
        intentValue = on
        intentUntil = SystemClock.elapsedRealtime() + 3000
        onLibraryItem(uri, on)
        val track = uri.startsWith(SPOTIFY_TRACK_PREFIX)
        if (track) likedTaps.tryEmit(trackIdOf(uri) to on)
        val write = libraryWrites.incrementAndGet()
        // No connection: the change stays on screen and is sent when the network is back.
        if (!com.music.spotui.data.offline.OfflineStore.isOnline(Graph.app)) {
            com.music.spotui.data.LibraryOutbox.put(uri, on)
            AppLog.d("library: $uri ${if (on) "saved" else "removed"} kept for later (offline${if (com.music.spotui.data.DataSaver.active) ", data saver" else ""})")
            // Sent as soon as Spotify answers (put asks for it), not only when Android reports a
            // network coming up: a network already there (or the data saver turned off) never reports one.
            return
        }
        // An artist unfollowed, an album or a show removed: out of the Library's list at once.
        // Spotify's list (libraryV3) trails the write by seconds, so the artist stayed there and a
        // reload brought it back, as if the button did nothing (reported); playlists already did this.
        val listEdit = if (!track && !on) com.music.spotui.data.api.LibraryEdits.Remove(uri).also(com.music.spotui.data.api.LibraryEdits::begin) else null
        if (!track && on) com.music.spotui.data.api.LibraryEdits.dropRemovals(uri)
        scope.launch {
            // One write at a time; a refused one is undone on screen if no newer tap replaced it.
            libraryLock.withLock {
                runCatching { writeLibrary(uri, on) }.onSuccess {
                    AppLog.d("library: $uri ${if (on) "saved" else "removed"} on Spotify")
                    if (track) likedChanges.value++
                    listEdit?.let(com.music.spotui.data.api.LibraryEdits::confirm)
                    // Followed or saved: the Library reads its list again once Spotify has it.
                    if (!track && on) com.music.spotui.data.api.LibraryEdits.reloadSoon()
                }.onFailure {
                    listEdit?.let(com.music.spotui.data.api.LibraryEdits::cancel)
                    Log.w(TAG, "library change failed: ${it.message}")
                    AppLog.d("library: $uri change failed: ${it.javaClass.simpleName} ${it.message}")
                    // The connection went while it was sent: kept for later, like an offline tap.
                    if (it is java.io.IOException && !com.music.spotui.data.offline.OfflineStore.isOnline(Graph.app)) {
                        com.music.spotui.data.LibraryOutbox.put(uri, on)
                        return@withLock
                    }
                    if (write == libraryWrites.get()) {
                        intentUntil = 0
                        onLibraryItem(uri, !on)
                        if (track) likedTaps.tryEmit(trackIdOf(uri) to !on)
                        android.widget.Toast.makeText(Graph.app, app.myspoti.engine.R.string.library_change_failed, android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
    private val libraryLock = kotlinx.coroutines.sync.Mutex()
    private val libraryWrites = java.util.concurrent.atomic.AtomicInteger()

    private suspend fun writeLibrary(uri: String, on: Boolean) {
        if (uri.startsWith("spotify:playlist:")) {
            if (on) api.playlists.follow(uri) else api.playlists.unfollow(uri)
        } else {
            if (on) api.library.add(listOf(uri)) else api.library.remove(listOf(uri))
        }
    }

    /** The library changes made offline ([com.music.spotui.data.LibraryOutbox]), sent once Spotify is reachable. */
    fun startLibraryOutbox(context: Context) {
        com.music.spotui.data.LibraryOutbox.init(context, scope,
            sender = { uri, on -> libraryLock.withLock { writeLibrary(uri, on) }; if (uri.startsWith(SPOTIFY_TRACK_PREFIX)) likedChanges.value++ },
            // The engine is started after the app's graph: wait for it, then for Spotify to answer,
            // then for the session's account (unknown after a session lost: it may be another one).
            ready = { awaitEngine(); api.ready.first { it }; com.music.spotui.data.api.ProfileCache.awaitId(context, ACCOUNT_WAIT_MS) },
            account = { com.music.spotui.data.api.ProfileCache.id },
            onAvailable = { scope.launch { kotlinx.coroutines.delay(3_000); com.music.spotui.data.LibraryOutbox.request() } },
        )
        // The Web Player ready again (a reload, a new sign-in): what waits is sent (nothing is asked when nothing waits),
        // once the session's account is read: after a session lost, what waits for it is told from what is not its own.
        scope.launch {
            awaitEngine()
            api.ready.collect { if (it) { com.music.spotui.data.api.ProfileCache.awaitId(context, ACCOUNT_WAIT_MS); com.music.spotui.data.LibraryOutbox.request() } }
        }
    }

    private suspend fun awaitEngine() { while (!MyspotiRuntime.isStarted) kotlinx.coroutines.delay(1_000) }

    /** The library changes kept for later wait that long for the account's id (see ProfileCache.awaitId). */
    private const val ACCOUNT_WAIT_MS = 10_000L

    // ── Spotify Connect ──
    data class ConnectDevice(val id: String, val name: String, val type: String, val isSelf: Boolean, val isActive: Boolean)

    private val _activeDevice = mutableStateOf<ConnectDevice?>(null)
    /** The device currently playing, when known and not this one. */
    val activeDevice: State<ConnectDevice?> get() = _activeDevice

    private fun refreshDevice() {
        scope.launch {
            runCatching { api.devices.refresh() }
            val active = api.devices.devices.value.firstOrNull { it.active }
            _activeDevice.value = active?.takeIf { !it.local }?.let { ConnectDevice(it.id, it.name, it.type, false, true) }
            MyspotiRuntime.spotify.player.remoteControl = _activeDevice.value != null
            // A negative volume is a device with a fixed one (Web Player: disable_volume): not 0 %.
            // Nor the 0 of a device muted for an ad (RemoteAdMute): the bar keeps the user's level.
            active?.volume?.takeIf { it >= 0 }?.let { if (SystemClock.elapsedRealtime() > volumeHoldUntil && !com.music.spotui.connect.RemoteAdMute.muting) { _remoteVolume.intValue = (it * 100).toInt().coerceIn(0, 100); remoteVolumeOf = active.id } }
            PlaybackService.setPlaybackDevice(_activeDevice.value != null, remoteVolume)
        }
    }

    /** Devices of the account, this phone first. */
    suspend fun devices(): List<ConnectDevice> {
        // What the Web Player's own picker does when it opens: it asks Spotify to look for devices
        // again. The answer is not known (no device test yet); bounded, and a page without it is fine.
        kotlinx.coroutines.withTimeoutOrNull(DISCOVERY_WAIT_MS) { runCatching { MyspotiRuntime.spotify.raw.service("ConnectDiscoveryAPI", "startActiveDiscovery") } }
        runCatching { api.devices.refresh() }
        val list = api.devices.devices.value.map { ConnectDevice(it.id, it.name, it.type, it.local, it.active) }
            .sortedWith(compareByDescending<ConnectDevice> { it.isSelf }.thenBy { it.name })
        _activeDevice.value = list.firstOrNull { it.isActive && !it.isSelf }
        // Kinds only (no names or ids): a report that says "no speaker" shows whether Spotify listed one.
        AppLog.d("connect: picker lists ${list.size} devices (${list.joinToString { it.type.lowercase() }})")
        return list
    }

    /**
     * The other device picked in Myspoti to play on; null: this phone. Kept over a restart of the
     * app (a day at most): forgotten, the first skip after the app came back took the device for one
     * that took playback by itself and pulled the music back to the phone (B12, reported: "I skip a
     * song and the audio starts playing through the phone").
     */
    private var chosenRemote: String?
        get() {
            if (!chosenLoaded) {
                chosenLoaded = true
                chosen = runCatching {
                    val p = chosenPrefs()
                    p.getString("device", null)?.takeIf { System.currentTimeMillis() - p.getLong("at", 0L) < CHOSEN_KEEP_MS }
                }.getOrNull()
            }
            return chosen
        }
        set(value) {
            chosenLoaded = true
            chosen = value
            runCatching { chosenPrefs().edit().putString("device", value).putLong("at", System.currentTimeMillis()).apply() }
        }
    @Volatile private var chosen: String? = null
    @Volatile private var chosenLoaded = false
    private fun chosenPrefs() = Graph.app.getSharedPreferences("myspoti_connect_choice", Context.MODE_PRIVATE)
    private const val CHOSEN_KEEP_MS = 24 * 3600_000L
    /** [chosenRemote], read by RemoteAdMute (only that device's ads are muted). */
    val chosenRemoteId: String? get() = chosenRemote

    /**
     * Another device took playback without being picked here (the Spotify app opened on the
     * same account, for instance): Myspoti's play, skip and previous then drove that device,
     * where a free account's commands are refused. The music comes back to this phone first.
     */
    /** When [takeBackPlayback] last read the device list; 0 = never read (read it now). */
    @Volatile private var devicesFreshUntil = 0L

    private suspend fun takeBackPlayback() {
        // The device list as Spotify has it now: the one kept here is only refreshed on a song
        // change, and after a cold start it does not know a device that took playback before.
        // But this used to run on EVERY tap, i.e. a server round trip before the song was even
        // asked for: measured 963 ms from tap to sound against 554 ms for a skip, which takes the
        // same playback path without this call. The list is read again only once the entry is
        // older than [DEVICES_FRESH_MS] — a takeover within those seconds is still caught by the
        // play check (the page does not move, the play is sent again) and by the next read.
        // Measured (15/10 run): this refresh answers from the page's cache in 8-36 ms, so it is not
        // what makes a tap slower than a skip (963 vs 554 ms then) — keeping it unconditional keeps
        // "a device that took playback is pulled back at once" (beta.7 behaviour). The timing stays
        // in the log because the day it becomes slow, that line says so.
        devicesFreshUntil = 0L
        val started = System.currentTimeMillis()
        kotlinx.coroutines.withTimeoutOrNull(DEVICES_WAIT_MS) { runCatching { api.devices.refresh() } }
        Log.i(TAG, "device list read in ${System.currentTimeMillis() - started} ms")
        val active = api.devices.devices.value.firstOrNull { it.active }
        _activeDevice.value = active?.takeIf { !it.local }?.let { ConnectDevice(it.id, it.name, it.type, false, true) }
        MyspotiRuntime.spotify.player.remoteControl = _activeDevice.value != null
        val remote = _activeDevice.value ?: return
        if (remote.id == chosenRemote) return
        // A Jam joined here: the music plays on the host's device and the commands go to it (Connect,
        // to the session's device): pulling it back took the host's playback away and broke the Jam.
        // (The Jam is read again first when none is known: after a restart the app has not read it yet.)
        if (api.jam.session.value == null) kotlinx.coroutines.withTimeoutOrNull(1_500) { runCatching { api.jam.refresh() } }
        if (remote.id.startsWith("social-connect") || api.jam.session.value?.isHost == false) {
            Log.i(TAG, "playback on ${remote.name} in a Jam: left there")
            return
        }
        Log.i(TAG, "playback taken by ${remote.name}: pulled back here")
        // A pull-back can land on this phone at 0:00 (reported: "sometimes on Connect the sound
        // starts over"). The position is remembered across the pull and restored only when the same
        // item really rolled back — a new play right after this call asks for its own position.
        val before = api.player.state.value?.let { s -> s.item?.uri?.let { uri -> uri to s.positionAt(System.currentTimeMillis()) } }
        // Bounded: a transfer from a device that went away can leave the page's promise
        // pending for ever, and every later command waiting behind it.
        val pulled = kotlinx.coroutines.withTimeoutOrNull(PULL_BACK_WAIT_MS) { runCatching { api.devices.pullHere() } }
        // Whatever happened, the list just changed under us: read it again next time.
        devicesFreshUntil = 0L
        if (pulled?.isSuccess != true) Log.w(TAG, "pull here failed: ${pulled?.exceptionOrNull()?.message ?: "no answer"}")
        // No answer: the page's Connect layer waits on that device and would hold every later
        // command. A new page claims playback for itself at the first command.
        if (pulled == null) {
            Log.w(TAG, "pull here hangs: player page reloaded")
            AppLog.d("pull here hangs (no answer in ${PULL_BACK_WAIT_MS / 1000} s): player page reloaded")
            MyspotiRuntime.spotify.player.reloadPage()
        }
        _activeDevice.value = null
        MyspotiRuntime.spotify.player.remoteControl = false
        PlaybackService.setPlaybackDevice(false, remoteVolume)
        kotlinx.coroutines.delay(PULL_BACK_SETTLE_MS)
        // Same item but an earlier position: the page restarted it. Put the listener back where they
        // were. Anything else (a different item, a position that did not move back) is left alone.
        before?.let { (uri, pos) ->
            val now = api.player.state.value
            val at = now?.positionAt(System.currentTimeMillis()) ?: return@let
            if (now.item?.uri == uri && pos > 3_000 && at < pos - 3_000) {
                Log.i(TAG, "playback came back at $at ms on the same item: back to $pos ms")
                runCatching { api.player.seek(pos) }
            } else {
                Log.i(TAG, "playback came back at $at ms (item ${now.item?.uri})")
            }
        }
    }

    /** A transfer asked during an ad waits for its end (the page refuses commands meanwhile). */
    private val transferAfterAd by lazy {
        app.myspoti.spotify.TransferAfterAd(scope, MyspotiRuntime.spotify.player.adPlaying, log = { AppLog.d("connect: $it") })
    }

    /**
     * Move playback to [device] (Spotify Connect transfer). During an ad, once it is over: with the
     * song and the place that play then ([transferNow] reads them when it runs).
     */
    fun transferTo(device: ConnectDevice) {
        invalidateHandoff()
        Haptics.confirm()
        if (!MyspotiRuntime.isStarted) { transferNow(device); return }
        if (transferAfterAd.run(device.name) { transferNow(device) }) main.post {
            android.widget.Toast.makeText(Graph.app, Graph.app.getString(app.myspoti.engine.R.string.connect_after_ad, device.name), android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun transferNow(device: ConnectDevice) {
        chosenRemote = if (device.isSelf) null else device.id
        _activeDevice.value = if (device.isSelf) null else device
        MyspotiRuntime.spotify.player.remoteControl = !device.isSelf
        if (!device.isSelf) NativeAudio.leaveForRemoteDevice(device.name)
        // A downloaded or streamed song plays in Myspoti's own player, which no other device can
        // reach: the device gets the same Spotify song, list and place, played by Spotify.
        val trackId = currentTrackId
        if (!device.isSelf && LocalPlayer.active.value && trackId.isNotBlank()) {
            val track = SPOTIFY_TRACK_PREFIX + trackId
            val context = LocalPlayer.contextUri.ifBlank { track }
            val at = LocalPlayer.position()
            val wasPlaying = LocalPlayer.isPlaying()
            Log.i(TAG, "local song to ${device.name}: $track in $context at $at ms")
            AccountSync.listen.leaving(device.name)
            LocalPlayer.stop()
            command(onFailure = { transferFailed(device) }) {
                api.devices.transfer(device.id)
                api.player.play(context, trackUri = track.takeIf { it != context }, positionMs = at)
                if (!wasPlaying) api.player.pause()
                else com.music.spotui.connect.SonosLocal.afterTransfer(device.id, device.name, true)
            }
            return
        }
        val wanted = isPlaying()
        command(onFailure = { transferFailed(device) }) {
            if (device.isSelf) api.devices.pullHere() else {
                api.devices.transfer(device.id)
                // A Sonos may take the song and stay paused: its own play is pressed then.
                com.music.spotui.connect.SonosLocal.afterTransfer(device.id, device.name, wanted)
            }
        }
    }

    /**
     * A transfer Spotify did not take (no such device any more, a speaker that went to sleep, a
     * refusal): the picker had already shown the device as playing, and the app went on driving a
     * device that plays nothing. Back on this phone, and the person is told.
     */
    private fun transferFailed(device: ConnectDevice) {
        if (device.isSelf || chosenRemote != device.id) return
        chosenRemote = null
        _activeDevice.value = null
        main.post {
            android.widget.Toast.makeText(Graph.app, Graph.app.getString(app.myspoti.engine.R.string.cast_failed, device.name), android.widget.Toast.LENGTH_LONG).show()
        }
    }

    /** Volume (0..100) of the device that plays, as last reported. State: the player's volume bar follows it. */
    private val _remoteVolume = androidx.compose.runtime.mutableIntStateOf(100)
    val remoteVolume: Int get() = _remoteVolume.intValue
    @Volatile private var volumeHoldUntil = 0L
    /**
     * The device [remoteVolume] is the level of (reported by it, or set by the user while it played);
     * null: the first 100 %, never any device's.
     */
    @Volatile private var remoteVolumeOf: String? = null

    /** [remoteVolume] when it is [deviceId]'s own level, else null (RemoteAdMute never restores a guess). */
    fun knownRemoteVolume(deviceId: String): Int? = remoteVolume.takeIf { remoteVolumeOf == deviceId }

    /**
     * The newest volume asked for, sent one at a time by [volumeSender]. A drag on the player's
     * volume bar asks for dozens of levels a second: sent each in its own command they could
     * reach the device out of order and leave it on an older level.
     */
    private val volumeToSend = kotlinx.coroutines.flow.MutableStateFlow<Int?>(null)
    private val volumeSender by lazy {
        scope.launch {
            volumeToSend.collect { v ->
                if (v != null) runCatching {
                    // Another device plays: its own volume, as Spotify's apps set it; else (or refused) the page's.
                    val target = _activeDevice.value?.id
                    val sent = target != null && runCatching { MyspotiRuntime.spotify.devices.setVolume(target, v / 100.0) }
                        .onFailure { Log.w(TAG, "device volume failed: ${it.message}") }.getOrDefault(false)
                    if (!sent) api.player.setVolume(v / 100.0)
                }.onFailure { Log.w(TAG, "volume failed: ${it.message}") }
            }
        }
    }

    /** Set the volume of the device that plays (volume keys, system slider, the player's volume bar). */
    fun setRemoteVolume(volume: Int) {
        _remoteVolume.intValue = volume.coerceIn(0, 100)
        remoteVolumeOf = _activeDevice.value?.id
        volumeHoldUntil = SystemClock.elapsedRealtime() + 1500
        volumeSender
        // A device muted for an ad is at 0 whatever the bar says: the same level as the last one sent
        // would not go out through [volumeToSend], so it is sent here.
        if (com.music.spotui.connect.RemoteAdMute.userSetVolume()) {
            val v = remoteVolume
            scope.launch { runCatching { api.player.setVolume(v / 100.0) } }
        }
        volumeToSend.value = remoteVolume
        PlaybackService.setPlaybackDevice(_activeDevice.value != null, remoteVolume)
    }

    // ── Sleep timer ──
    private val _sleepEndsAt = mutableStateOf<Long?>(null)   // elapsedRealtime, or -1 = end of track
    val sleepEndsAt: State<Long?> get() = _sleepEndsAt
    private val sleepRunnable = Runnable {
        _sleepEndsAt.value = null
        // The fade ends in the pause itself.
        if (sleepFade?.isActive != true) pauseSilently()
    }
    private val sleepFadeRunnable = Runnable { startSleepFade() }
    private var sleepFade: kotlinx.coroutines.Job? = null
    private var sleepTrackId: String? = null

    /** [minutes] null = off, 0 = at the end of the current track. */
    fun setSleepTimer(minutes: Int?) {
        main.removeCallbacks(sleepRunnable)
        main.removeCallbacks(sleepFadeRunnable)
        main.removeCallbacks(endOfTrackWatch)
        sleepFade?.cancel(); sleepFade = null   // a fade under way ends with the volume back, the song going on
        sleepTrackId = null
        when {
            minutes == null -> _sleepEndsAt.value = null
            minutes == 0 -> {
                // Any source (song, episode, local file, repeat one): the uri and the clock.
                sleepTrackId = _nowPlaying.value.uri.ifBlank { currentTrackId }
                _sleepEndsAt.value = -1L
                main.removeCallbacks(endOfTrackWatch); main.post(endOfTrackWatch)
            }
            else -> {
                _sleepEndsAt.value = SystemClock.elapsedRealtime() + minutes * 60_000L
                main.postDelayed(sleepRunnable, minutes * 60_000L)
                main.postDelayed(sleepFadeRunnable, (minutes * 60_000L - SLEEP_FADE_MS).coerceAtLeast(0L))
            }
        }
    }

    /**
     * The last [SLEEP_FADE_MS] of a timed sleep timer: the volume goes down along the ear's curve
     * and the song is paused at the end of the timer, the volume back for the next play. Spotify
     * songs use the pause's own ramp ([app.myspoti.api.Player.pauseSlowly]), the others the player's volume.
     */
    private fun startSleepFade() {
        if (!isPlaying()) return
        sleepFade?.cancel()
        sleepFade = scope.launch {
            if (LocalPlayer.active.value) {
                fadeLocalOut(SLEEP_FADE_MS)
                return@launch
            }
            runCatching { api.player.pauseSlowly(SLEEP_FADE_MS) }.onFailure { if (it is kotlinx.coroutines.CancellationException) throw it }
            if (playing) { _sleepEndsAt.value = null; pauseSilently(send = false) }
        }
    }

    private suspend fun fadeLocalOut(ms: Long) {
        val cast = com.music.spotui.cast.CastPlayback.active
        val base = if (cast) com.music.spotui.cast.CastPlayback.volume.floatValue else 1f
        fun set(gain: Float) = if (cast) com.music.spotui.cast.CastPlayback.setVolume(base * gain) else LocalPlayer.setGain(gain)
        val startedAt = SystemClock.elapsedRealtime()
        try {
            while (true) {
                if (!isPlaying()) return   // paused meanwhile: only the volume to put back
                val t = ((SystemClock.elapsedRealtime() - startedAt).toFloat() / ms).coerceIn(0f, 1f)
                if (t >= 1f) break
                set(Math.pow(10.0, -2.0 * t).toFloat())   // 1 down to -40 dB
                kotlinx.coroutines.delay(if (cast) 1_000L else 250L)
            }
            _sleepEndsAt.value = null
            pauseSilently()
            kotlinx.coroutines.delay(300)   // the tail of the buffer is not heard at the old level
        } finally {
            withContext(kotlinx.coroutines.NonCancellable) { set(1f) }
        }
    }

    private fun checkEndOfTrackTimer(@Suppress("UNUSED_PARAMETER") newTrackId: String) {
        // Done by [endOfTrackWatch], which pauses before the next item starts.
    }

    // ── A-B loop ──
    data class AbLoopState(val trackUri: String = "", val aMs: Long? = null, val bMs: Long? = null) {
        val active: Boolean get() = aMs != null && bMs != null && bMs > aMs
    }

    private val _abLoop = mutableStateOf(AbLoopState())
    val abLoop: State<AbLoopState> get() = _abLoop
    private var lastAbSeekAt = 0L

    private val abLoopWatch = object : Runnable {
        override fun run() {
            val st = _abLoop.value
            if (!st.active) return
            val uri = _nowPlaying.value.uri
            if (uri.isNotBlank() && st.trackUri.isNotBlank() && uri != st.trackUri) {
                clearAbLoop()
                return
            }
            val a = st.aMs!!
            val b = st.bMs!!
            val now = SystemClock.elapsedRealtime()
            if (isPlaying() && now - lastAbSeekAt > 350L && getCurrentPosition() >= b) {
                lastAbSeekAt = now
                seekTo(a)
            }
            main.postDelayed(this, 150L)
        }
    }

    fun setAbLoopA(ms: Long = getCurrentPosition()) {
        val uri = _nowPlaying.value.uri
        if (uri.isBlank()) return
        val cur = _abLoop.value.takeIf { it.trackUri == uri } ?: AbLoopState(uri)
        val clamped = ms.coerceAtLeast(0L)
        val b = cur.bMs?.takeIf { it > clamped + 200L }
        _abLoop.value = AbLoopState(uri, clamped, b)
        main.removeCallbacks(abLoopWatch)
        if (_abLoop.value.active) main.post(abLoopWatch)
    }

    fun setAbLoopB(ms: Long = getCurrentPosition()) {
        val uri = _nowPlaying.value.uri
        if (uri.isBlank()) return
        val cur = _abLoop.value.takeIf { it.trackUri == uri } ?: AbLoopState(uri)
        val a = cur.aMs ?: 0L
        val clamped = ms.coerceAtLeast(a + 200L).let { if (durationMs > 0L) it.coerceAtMost(durationMs) else it }
        _abLoop.value = AbLoopState(uri, a, clamped)
        main.removeCallbacks(abLoopWatch)
        main.post(abLoopWatch)
    }

    fun nudgeAbLoopA(deltaMs: Long) {
        val cur = _abLoop.value
        val a = cur.aMs ?: return
        val next = (a + deltaMs).coerceAtLeast(0L)
        val limit = cur.bMs?.let { it - 200L } ?: (durationMs.takeIf { it > 0L } ?: Long.MAX_VALUE)
        _abLoop.value = cur.copy(aMs = next.coerceAtMost(limit))
    }

    fun nudgeAbLoopB(deltaMs: Long) {
        val cur = _abLoop.value
        val b = cur.bMs ?: return
        val min = (cur.aMs ?: 0L) + 200L
        val max = durationMs.takeIf { it > 0L } ?: Long.MAX_VALUE
        _abLoop.value = cur.copy(bMs = (b + deltaMs).coerceIn(min, max))
    }

    fun clearAbLoop() {
        main.removeCallbacks(abLoopWatch)
        _abLoop.value = AbLoopState()
    }

    /** "End of track": pauses just before the item ends, or as soon as another one plays. */
    private val endOfTrackWatch = object : Runnable {
        override fun run() {
            val t = sleepTrackId ?: return
            val uri = _nowPlaying.value.uri.ifBlank { currentTrackId }
            val duration = getDuration()
            val moved = uri.isNotBlank() && uri != t
            val atEnd = duration > 0 && isPlaying() && getCurrentPosition() >= duration - END_OF_TRACK_MARGIN_MS
            if (moved || atEnd) {
                sleepTrackId = null
                _sleepEndsAt.value = null
                pauseSilently()
                return
            }
            main.postDelayed(this, 250)
        }
    }

    // ── Queue (the API pushes every change) ──

    /**
     * The queue row [item] stands for in Spotify's latest queue: by its row id, else by its song
     * (a row moved a moment ago got a new id, and the list on screen may still show the old one).
     */
    private fun apiItem(item: QueueItem): app.myspoti.api.NowPlaying? =
        apiQueue?.let { q ->
            val all = q.queued + q.nextUp
            all.firstOrNull { it.uri == item.uri && (item.uid.isBlank() || it.uid == item.uid) } ?: all.firstOrNull { it.uri == item.uri }
        }

    /**
     * [item] in the page's queue, waited for when the page does not list it yet: an edit made while
     * the page is rebuilt (just after an install or a "player never started" reload, log 04/11
     * 19:10) found no queue and was dropped without a word, the row then going back.
     */
    private suspend fun liveItem(item: QueueItem): app.myspoti.api.NowPlaying? {
        apiItem(item)?.let { return it }
        val q = kotlinx.coroutines.withTimeoutOrNull(QUEUE_READY_MS) {
            api.player.queue.first { q -> q != null && (q.queued + q.nextUp).any { it.uri == item.uri } }
        } ?: return null.also { AppLog.d("queue edit: ${item.uri} not in the page's queue, edit dropped") }
        val all = q.queued + q.nextUp
        return all.firstOrNull { it.uri == item.uri && it.uid == item.uid } ?: all.firstOrNull { it.uri == item.uri }
    }
    private const val QUEUE_READY_MS = 12_000L

    /**
     * Queue edits, one at a time and each after Spotify has shown the one before. Sent together
     * they raced in the Web Player: "move up into the queue" (add + remove) lost its remove and
     * left the song twice, and that copy could then not be moved or taken out (reported).
     */
    private val queueLock = kotlinx.coroutines.sync.Mutex()
    private fun queueCommand(block: suspend () -> Unit) {
        scope.launch { queueLock.withLock { runCatching { block() }.onFailure { Log.w(TAG, "queue edit failed: ${it.message}") } } }
    }

    private const val QUEUE_ECHO_MS = 2_500L

    /** Waits (at most [QUEUE_ECHO_MS]) for Spotify's queue to show [done]; the queue then, or null. */
    private suspend fun awaitQueue(done: (app.myspoti.api.Queue) -> Boolean): app.myspoti.api.Queue? =
        kotlinx.coroutines.withTimeoutOrNull(QUEUE_ECHO_MS) { api.player.queue.first { it != null && done(it) } }

    /** "Play next": first in the queue, right after the current track. */
    fun playNext(trackId: String) {
        if (trackId.isBlank()) return
        Haptics.confirm()
        if (LocalPlayer.active.value) { localQueue(trackId, next = true); return }
        command { api.player.playNext(listOf(SPOTIFY_TRACK_PREFIX + trackId)) }
    }

    fun addToQueue(trackId: String) {
        if (trackId.isBlank()) return
        Haptics.confirm()
        if (LocalPlayer.active.value) { localQueue(trackId, next = false); return }
        command { api.player.addToQueue(listOf(SPOTIFY_TRACK_PREFIX + trackId)) }
    }

    /**
     * While the local player plays, the paused engine's queue would never be heard: the song goes
     * into the local queue, and only one neither a download nor an extension has goes to Spotify.
     */
    private fun localQueue(trackId: String, next: Boolean) {
        scope.launch {
            if (com.music.spotui.extensions.ExtensionAudio.enqueue(trackId, next)) return@launch
            val uris = listOf(SPOTIFY_TRACK_PREFIX + trackId)
            command { if (next) api.player.playNext(uris) else api.player.addToQueue(uris) }
        }
    }

    /** Songs per call of Spotify's queue: a whole playlist in one call is a long wait for the page. */
    private const val QUEUE_BATCH = 100

    /**
     * "Play next" / "Add to queue" for a whole list, in the list's order; [done] is told how many
     * songs joined a queue (on the main thread). Every song goes where its single-song action
     * would send it: while the local player plays, a device file, a download or an extension's song
     * joins the local queue and the others Spotify's; otherwise Spotify's queue takes everything it
     * can stream (tracks and episodes). A device file cannot be streamed by Spotify: it is left
     * out then, as a Spotify local file nothing matched and a greyed song are. The two queues
     * are separate, so a mixed list is split between them, each part in order.
     */
    fun queueSongs(songs: List<SongsModel>, next: Boolean, done: (Int) -> Unit) {
        Haptics.confirm()
        scope.launch {
            val local = LocalPlayer.active.value
            val rows = songs.filter { it.playable && !it.isUnmatchedLocal }
            val files = if (local && rows.any { it.isDeviceFile })
                runCatching { com.music.spotui.data.local.LocalMusic.tracks(Graph.app) }.getOrDefault(emptyList()).associateBy { com.music.spotui.data.local.LocalFileMatch.key(it) }
            else emptyMap()
            val toLocal = ArrayList<com.music.spotui.data.local.LocalTrack>()
            val toSpotify = ArrayList<String>()
            for (s in rows) {
                val uri = when {
                    s.isDeviceFile -> { if (local) files[s.url]?.let { toLocal += it }; continue }
                    s.url.startsWith("episode:") -> "spotify:episode:" + s.url.removePrefix("episode:")
                    s.spotifyTrackId.isNotBlank() -> SPOTIFY_TRACK_PREFIX + s.spotifyTrackId
                    else -> continue
                }
                val own = if (local && !s.url.startsWith("episode:")) com.music.spotui.extensions.ExtensionAudio.queueTrack(s) else null
                if (own != null) toLocal += own else toSpotify += uri
            }
            if (toLocal.isNotEmpty()) withContext(Dispatchers.Main) { LocalPlayer.enqueueAll(toLocal, next) }
            if (toSpotify.isNotEmpty()) {
                val batches = toSpotify.chunked(QUEUE_BATCH)
                queueCommand {
                    if (!next) batches.forEach { api.player.addToQueue(it) }
                    // Each batch goes in front of the one sent before it, so the last is sent first;
                    // Spotify's queue is shown again between two (playNext reads its first row).
                    else batches.asReversed().forEachIndexed { i, batch ->
                        val before = api.player.queue.value
                        api.player.playNext(batch)
                        if (i < batches.lastIndex) awaitQueue { it !== before }
                    }
                }
            }
            val count = toLocal.size + toSpotify.size
            withContext(Dispatchers.Main) { done(count) }
        }
    }

    fun skipTo(item: QueueItem) {
        userActed()
        if (MixedPlaylistQueue.jumpToQueueItem(item.uid)) return
        routeAsk.incrementAndGet(); routingState.value = null; routingSongs = null
        // Its index found now: a row shown in a just-dragged order carries the index it had before (see localIndex).
        if (item.provider == LOCAL) { localIndex(item)?.let(LocalPlayer::skipTo); return }
        cancelBurst()
        playedByHand = item.uri
        val id = trackIdOf(item.uri)
        if (id.isNotBlank()) markPending(id)
        boundState?.updateSongState(item.song.coverUri, item.song.title, item.song.singer, true, item.song.id, 0, item.song.album)
        durationMs = item.song.durationMs.toLong()
        pushNotification(item.song, false)
        val target = apiItem(item) ?: return
        transport(waitReady = !stateSeen) { api.player.skipTo(target) }
    }

    /** "Clear queue": drops the tracks the user queued (not the context's next ones). */
    fun clearQueue() {
        if (LocalPlayer.active.value) { LocalPlayer.clearQueued(); return }
        _queue.value = _queue.value.copy(queued = emptyList())
        command { api.player.clearQueue() }
    }

    /**
     * The local player's list index of a queue row, found now: the row's own uid is the index it had
     * when the queue was reported, and a row shown in a just-dragged order carries an older one.
     */
    private fun localIndex(item: QueueItem): Int? {
        val up = LocalPlayer.upcoming().filter { "local:${it.second.id}" == item.uri }
        return (up.firstOrNull { it.first.toString() == item.uid } ?: up.firstOrNull())?.first
    }

    /**
     * Queue moves sent to Spotify and not done yet. Spotify shows a move late and in steps (the song
     * out of one part, queued at the end, then placed), and showing them took the song back to where
     * it was before it reached the place it was dropped at. So while a move is under way its reports
     * are held and the order the user dropped ([showQueueOrder]) stays; the last move to finish shows
     * the queue as Spotify has it then, and for [STALE_MS] after, a late report of an order from
     * before the moves is ignored.
     */
    private val queueMovesInFlight = java.util.concurrent.atomic.AtomicInteger()
    private val staleOrders = java.util.Collections.synchronizedSet(HashSet<Pair<List<String>, List<String>>>())
    @Volatile private var staleUntil = 0L
    private const val STALE_MS = 1_500L

    private fun order(q: app.myspoti.api.Queue) = q.queued.map { it.uri } to q.nextUp.map { it.uri }

    /** Shows [queued] / [nextUp] at once: the order a drop made, kept while the move that makes it so runs. */
    fun showQueueOrder(queued: List<QueueItem>, nextUp: List<QueueItem>) {
        if (LocalPlayer.active.value) return
        val shown = _queue.value
        if (shown.queued == queued && shown.nextUp == nextUp) return
        if (queueMovesInFlight.get() == 0) staleOrders.clear()
        staleOrders += shown.queued.map { it.uri } to shown.nextUp.map { it.uri }
        _queue.value = shown.copy(queued = queued, nextUp = nextUp)
    }

    /** A move of a Spotify queue row, run as [queueCommand]; see [queueMovesInFlight]. */
    private fun queueMove(block: suspend () -> Unit) {
        queueMovesInFlight.incrementAndGet()
        queueCommand {
            try {
                block()
            } finally {
                if (queueMovesInFlight.decrementAndGet() == 0) {
                    staleUntil = SystemClock.elapsedRealtime() + STALE_MS
                    api.player.queue.value?.let { staleOrders -= order(it) }
                    main.post { if (acceptsSessionUpdates()) applyQueue(api.player.queue.value ?: apiQueue) }
                }
            }
        }
    }

    /** Whether [q] shows [uri] right before / after [target], in either part. */
    private fun placed(q: app.myspoti.api.Queue, uri: String, target: String, after: Boolean): Boolean =
        listOf(q.queued, q.nextUp).any { part ->
            val uris = part.map { it.uri }
            val i = uris.indexOf(uri)
            val t = uris.indexOf(target)
            i >= 0 && t >= 0 && i == (if (after) t + 1 else t - 1)
        }

    /**
     * Debug builds: a queue drawn with no player behind it (QueueProbeActivity, to drag rows on an
     * emulator); its moves are applied to it at once, as the local player reports them.
     */
    @Volatile private var probeQueue = false
    internal fun showProbeQueue(q: EngineQueue) {
        if (!app.myspoti.engine.BuildConfig.DEBUG) return
        probeQueue = true
        _queue.value = q
    }
    private fun probeMove(item: QueueItem, target: QueueItem?, after: Boolean, intoQueue: Boolean) = main.postDelayed({
        val q = _queue.value
        val queued = q.queued.filter { it.uri != item.uri }.toMutableList()
        val next = q.nextUp.filter { it.uri != item.uri }.toMutableList()
        val part = when {
            intoQueue -> queued
            target != null && queued.any { it.uri == target.uri } -> queued
            else -> next
        }
        val at = target?.let { t -> part.indexOfFirst { it.uri == t.uri }.takeIf { it >= 0 }?.let { if (after) it + 1 else it } } ?: 0
        part.add(at.coerceIn(0, part.size), item)
        _queue.value = q.copy(queued = queued, nextUp = next)
    }, 300)

    /** Move [item] just before / after [target]; a Spotify row stays in its section (see [moveIntoQueue]), a local one goes into [target]'s. */
    fun reorder(item: QueueItem, target: QueueItem, after: Boolean) {
        if (probeQueue) { probeMove(item, target, after, intoQueue = false); return }
        if (item.provider == LOCAL) {
            val from = localIndex(item) ?: return
            val t = localIndex(target) ?: return
            LocalPlayer.moveBeside(from, t, after)
            return
        }
        // Read when the edit runs, after the ones before it: never a row id that has gone stale.
        queueMove {
            val a = liveItem(item) ?: return@queueMove
            val b = liveItem(target) ?: return@queueMove
            api.player.moveInQueue(a, b, after)
            // Done once Spotify shows it in place, not at its first report: that one may still be of the old order.
            awaitQueue { placed(it, a.uri, b.uri, after) }
        }
    }

    /** Move a "next up" track into the queue, right after the current one. */
    fun moveToQueueFront(item: QueueItem) = moveIntoQueue(item, null, after = false)

    /**
     * A "next up" track moved up into the queue, before / after [target] (a queued row; null: first).
     * As the official app: out of "next up" first, then queued — in that order and one after the
     * other (both at once left it in both places), then placed where it was dropped.
     */
    fun moveIntoQueue(item: QueueItem, target: QueueItem?, after: Boolean) {
        if (probeQueue) { probeMove(item, target, after, intoQueue = true); return }
        if (item.provider == LOCAL) {
            val from = localIndex(item) ?: return
            LocalPlayer.moveIntoQueue(from, target?.let { localIndex(it) ?: return }, after)
            return
        }
        queueMove {
            val a = liveItem(item) ?: return@queueMove
            val first = apiQueue?.queued?.firstOrNull()
            api.player.removeFromQueue(listOf(a))
            awaitQueue { q -> q.nextUp.none { it.uid == a.uid } }
            api.player.addToQueue(listOf(a.uri))
            val added = awaitQueue { q -> q.queued.any { it.uri == a.uri } }?.queued?.lastOrNull { it.uri == a.uri } ?: return@queueMove
            // Queued at the end: moved to the place it was dropped (the front when no target).
            val t = target?.let(::apiItem) ?: first?.takeIf { it.uid != added.uid } ?: return@queueMove
            val placeAfter = if (target == null) false else after
            // Already there (dropped last in the queue): nothing to move.
            if (api.player.queue.value?.let { placed(it, added.uri, t.uri, placeAfter) } == true) return@queueMove
            api.player.moveInQueue(added, t, placeAfter)
            awaitQueue { placed(it, added.uri, t.uri, placeAfter) }
        }
    }

    fun removeFromQueue(item: QueueItem) {
        // Found now, as for skipTo: with the index the row was reported with, a swipe right after a
        // drag removed whichever song had taken that place.
        if (item.provider == LOCAL) { localIndex(item)?.let(LocalPlayer::remove); return }
        _queue.value = _queue.value.let { q -> q.copy(queued = q.queued - item, nextUp = q.nextUp - item) }
        queueCommand {
            val a = liveItem(item) ?: return@queueCommand
            api.player.removeFromQueue(listOf(a))
            awaitQueue { q -> (q.queued + q.nextUp).none { it.uid == a.uid && it.uri == a.uri } }
        }
    }

    fun isPlaying(): Boolean = if (LocalPlayer.active.value && !routing) LocalPlayer.isPlaying() else playing
    fun getDuration(): Long = if (LocalPlayer.active.value && !routing) LocalPlayer.duration() else durationMs

    fun getCurrentPosition(): Long {
        if (LocalPlayer.active.value && !routing) return LocalPlayer.position()
        val base = positionMs
        if (!playing || isBuffering) return base
        val rate = if (isEpisode) _speed.value.coerceIn(0.5, 3.5) else 1.0
        val now = base + ((SystemClock.elapsedRealtime() - positionAt) * rate).toLong()
        return if (durationMs > 0) now.coerceAtMost(durationMs) else now
    }

    /**
     * Whether [getCurrentPosition] moves on now. Not only paused: a song that is to play but is
     * loading (its start, a seek into what is not loaded yet, a stream that does not keep up)
     * stands still too, for seconds with an extension's stream; the lyrics hold meanwhile.
     */
    fun positionMoving(): Boolean =
        if (LocalPlayer.active.value && !routing) LocalPlayer.isPlaying() else playing && !isBuffering

    /**
     * A tap on a synced lyric line, for the diagnostic: where it jumps, which player plays (and
     * whether its source can seek), then where the song is 300 ms and 2 s later.
     */
    fun logLyricJump(targetMs: Long) {
        val log: (String) -> Unit = { AppLog.d(it) }
        val player = when {
            routing -> "spotify, an extension being asked"
            LocalPlayer.active.value -> "local, ${LocalPlayer.describe()}"
            _activeDevice.value != null -> "spotify connect"
            else -> "spotify"
        }
        log("lyrics: tap on the line at $targetMs ms, from ${getCurrentPosition()} ms ($player)")
        for (afterMs in longArrayOf(300L, 2_000L)) main.postDelayed({
            log("lyrics: $afterMs ms after the tap to $targetMs ms: at ${getCurrentPosition()} ms" +
                if (positionMoving()) "" else if (isPlaying() || LocalPlayer.active.value && LocalPlayer.playWhenReady()) ", loading" else ", paused")
        }, afterMs)
    }

    /** A local file starts: Spotify pauses (wherever it plays). */
    fun pauseEngineForLocal() {
        // A song the extensions were asked for has its answer, or other files play: older answers play nothing.
        invalidateHandoff()
        routeAsk.incrementAndGet(); routingState.value = null
        localStartedAt = SystemClock.elapsedRealtime()
        // What the page reported last (the screens may already show the song asked for).
        engineUriBeforeLocal = lastPageUri
        engineRepaused = false
        // The listen sync's page goes on to the new song itself (or is paused by it if that one is not synced).
        if (playing && !AccountSync.holdsSpotify) command { api.player.pause() }
        playing = false
        // The local player keeps the output open itself; the engine's states, which
        // would close the silent stream, are ignored while it plays.
        SpeakerKeepAlive.set(false)
    }

    private var localStartedAt = 0L
    /** What the engine played when the local file started (to tell a pause that did not take from a takeover). */
    private var engineUriBeforeLocal = ""
    private var engineRepaused = false

    /**
     * The engine reports playing while a local file plays. Two streams must never play
     * at once: a pause that did not take (the engine was not ready) is sent once more;
     * anything else is Spotify taking over (a Connect "play on this phone", a resume from
     * another device), and the local player yields; with the listen sync on, the local player
     * follows those commands instead (see [AccountSync]). True when the state is to be ignored.
     */
    private fun engineWhileLocal(s: PlayerState): Boolean {
        // The listen sync's page: its states are another device's commands for the local player
        // to follow, or the echo of the sync's own; never a takeover.
        // On the native engine, the page shows the engine's playback (the mirror's): the sync reads the engine's own.
        if (AccountSync.holdsSpotify) { if (AccountSync.holdsSpotifyPage) AccountSync.listen.onProviderState(s); return true }
        if (s.isPaused) return true
        // An extension mirrors its own song in the page, muted: that is not the engine taking over.
        if (api.player.localMute) return true
        // The page's last states from before the pause reached it.
        if (SystemClock.elapsedRealtime() - localStartedAt < LOCAL_GRACE_MS) return true
        if (s.item?.uri == engineUriBeforeLocal && !engineRepaused) {
            engineRepaused = true
            Log.i(TAG, "engine still playing under a local file: pausing it again")
            command { api.player.pause() }
            return true
        }
        Log.i(TAG, "engine started playing: the local player yields")
        LocalPlayer.stop()
        return false
    }

    /** The local player's track / state, shown like any other (player, mini player, notification). */
    fun onLocalState(t: com.music.spotui.data.local.LocalTrack, isPlaying: Boolean, pos: Long, dur: Long) {
        main.post {
            // A state of what played before the song now being asked for, or of a song already left.
            if (routing || LocalPlayer.current() !== t) return@post
            val trackId = streamedTrackId(t)
            // A download keeps its Spotify id too (likes, menu): only a file of the device has none.
            currentTrackId = trackId.ifBlank { localSpotifyUri(t)?.let(::trackIdOf).orEmpty() }
            playing = isPlaying; positionMs = pos; positionAt = SystemClock.elapsedRealtime(); durationMs = dur
            // Played on here (another device's resume through the Connect mirror): Spotify no longer waits for a play.
            if (isPlaying) spotifyDue = null
            bufferingState.value = false
            // A song an extension streams keeps its Spotify uri: its lyrics, Canvas and artists load as for Spotify.
            val uri = if (trackId.isNotBlank()) SPOTIFY_TRACK_PREFIX + trackId else "local:${t.id}"
            val songChanged = _nowPlaying.value.uri != uri
            if (songChanged && _abLoop.value.trackUri.isNotBlank() && uri != _abLoop.value.trackUri) clearAbLoop()
            // From the list, its song radio, or the songs the user queued (as Spotify's player says).
            val shown = NowPlaying(uri = uri, contextUri = LocalPlayer.contextUri, contextName = LocalPlayer.contextName,
                provider = if (LocalPlayer.fromQueue()) "queue" else "")
            if (_nowPlaying.value.let { it.uri != uri || it.contextUri != shown.contextUri || it.contextName != shown.contextName || it.provider != shown.provider })
                _nowPlaying.value = shown
            val song = localSong(t, dur)
            val likeUri = localSpotifyUri(t)
            val liked = likeUri?.let { likedFor(it, library[it] ?: false) } ?: false
            // Its large cover, as a song Spotify plays shows (the queue keeps the small one).
            val cover = app.myspoti.host.android.Covers.large(song.coverUri)
            boundState?.let { st ->
                st.likeState.value = liked
                st.updateSongState(cover, song.title, song.singer, isPlaying, song.id, 0, song.album)
            }
            pushNotification(song.copy(coverUri = cover), liked)
            if (songChanged) refreshCurrentLiked()
            com.music.spotui.extensions.Extensions.mirrorTick(isPlaying, uri)
            AccountSync.onLocal(t, isPlaying, pos, dur)
            val source = if (t.uri.scheme == "file") com.music.spotui.data.local.ListenHistory.Source.DOWNLOAD
                else com.music.spotui.data.local.ListenHistory.Source.LOCAL
            trackListen("local:${t.id}", song, source, isPlaying)
            // An extension's stream or a download (it has a Spotify id): kept to come back to at launch.
            if (likeUri != null) {
                val rest = LocalPlayer.upcoming().map { localSong(it.second) }.filter { it.spotifyTrackId.isNotBlank() }
                saveLastTrack(song.copy(coverUri = cover), likeUri, liked, LocalPlayer.contextUri, LocalPlayer.contextName,
                    com.music.spotui.data.preferences.LastSession.SOURCE_LOCAL, listOf(song) + rest)
            }
        }
    }

    /**
     * Play on a session put back at launch: a download plays from its file, a song an extension
     * streamed is asked again (its saved stream address may have expired) by [resumeThroughExtensions].
     */
    private fun resumeRestoredLocal(): Boolean {
        if (!restoredLocal) return false
        restoredLocal = false
        val q = _queue.value
        val songs = listOfNotNull(q.current) + q.nextUp.map { it.song }
        val store = com.music.spotui.data.offline.OfflineStore
        val downloads = store.list().associateBy { it.trackId }
        if (songs.firstOrNull()?.spotifyTrackId?.let(downloads::containsKey) != true) return false
        val list = songs.mapNotNull { downloads[it.spotifyTrackId] }.map(store::toLocalTrack)
        // In the list it was played in, as the extensions' resume does.
        val np = _nowPlaying.value
        LocalPlayer.play(list, 0, startMs = getCurrentPosition(), context = np.contextName.ifBlank { null }, contextUri = np.contextUri)
        return true
    }

    /** The Spotify uri of what the local player plays: a song an extension streams or a download; null for a file of the device. */
    private fun localSpotifyUri(t: com.music.spotui.data.local.LocalTrack?): String? {
        t ?: return null
        return LocalPlayer.spotifyIdOf(t).takeIf { it.isNotBlank() }?.let { SPOTIFY_TRACK_PREFIX + it }
    }

    /** The uri a like of the song shown saves ("" or a local: uri for a file of the device). */
    private fun currentLikeUri(): String = when {
        routing -> _nowPlaying.value.uri
        LocalPlayer.active.value -> localSpotifyUri(LocalPlayer.current()).orEmpty()
        else -> pendingItemUri ?: _nowPlaying.value.uri
    }

    /**
     * The song shown can be liked: anything with a Spotify id (from Spotify, an extension's stream,
     * a download); not a file of the device. Read by the screens (state: recomposes as it changes).
     */
    val canLike: Boolean get() {
        val uri = _nowPlaying.value.uri
        if (!LocalPlayer.active.value || !uri.startsWith("local:")) return true
        return uri.removePrefix("local:").toLongOrNull()?.let { com.music.spotui.data.offline.OfflineStore.byLocalId(it) } != null
    }

    /** The Spotify id of a song an extension streams (audio-source), "" for files. */
    private fun streamedTrackId(t: com.music.spotui.data.local.LocalTrack) =
        t.uri.takeIf { it.scheme == com.music.spotui.extensions.ExtensionAudio.SCHEME }?.lastPathSegment.orEmpty()

    private fun localSong(t: com.music.spotui.data.local.LocalTrack, dur: Long = t.durationMs): SongsModel {
        val trackId = streamedTrackId(t)
        return SongsModel(id = if (trackId.isNotBlank()) songIdFor(trackId, "") else ("local:" + t.id).hashCode() and 0x7fffffff, title = t.title, album = t.album,
            singer = t.artist, coverUri = t.artUri.toString(), url = "local:${t.uri}", durationMs = dur.toInt(), spotifyTrackId = trackId)
    }

    /**
     * The local player's queue: [upcoming] are the songs after [current], with their list index as
     * uid; its first [queuedCount] are the ones the user queued ("Next in queue"), the rest the list's.
     */
    fun onLocalQueue(current: com.music.spotui.data.local.LocalTrack, upcoming: List<Pair<Int, com.music.spotui.data.local.LocalTrack>>, queuedCount: Int = 0) {
        main.post {
            if (!LocalPlayer.active.value) return@post
            if (MixedPlaylistQueue.active) {
                MixedPlaylistQueue.toEngineQueue()?.let { _queue.value = it }
                return@post
            }
            val items = upcoming.map { (i, t) -> QueueItem(localSong(t), "local:${t.id}", i.toString(), LOCAL) }
            _queue.value = EngineQueue(current = localSong(current), queued = items.take(queuedCount), nextUp = items.drop(queuedCount))
        }
    }

    /** The song a real crossfade fades out, as the screens showed it when the fade began. */
    data class FadingSong(val title: String, val artist: String, val coverUri: String, val durationMs: Long)

    private val fadingOutState = mutableStateOf<FadingSong?>(null)
    /**
     * Set while the local player's crossfade overlaps two songs (none for Spotify's own fades,
     * which do not overlap): the players blend this one into the current song.
     */
    val fadingOut: State<FadingSong?> get() = fadingOutState

    /** [LocalPlayer]'s fade starts (just after its switch to the next song) or ends. */
    fun onLocalFade(on: Boolean) {
        // The new song's state is posted: what the screens hold is still the song going out.
        fadingOutState.value = if (!on) null else boundState?.let {
            FadingSong(it.title.value, it.singer.value, it.coverUri.value, durationMs)
        }
    }
    fun release() {}

    // ── Play-key helpers (url = "spotify:track:<id>|<search text>") ──

    private val featSearchPattern = Regex("""\s*[\(\[]\s*(feat|ft)\..*?[\)\]]""", RegexOption.IGNORE_CASE)

    /**
     * [song] ("catalog:<uri>", a song of another provider) as the same recording on Spotify (by its ISRC, else the
     * match gate), played alone; a short message when Spotify is not asked (signed out, turned off) or has no such
     * recording, so the tap is never lost.
     */
    private fun playCatalogSong(song: String, context: Context?, askExtensions: Boolean) {
        val uri = song.removePrefix(com.music.spotui.data.catalog.CatalogRuntime.PLAY_PREFIX)
        app.myspoti.host.android.MyspotiRuntime.scope.launch {
            val m = try { com.music.spotui.data.catalog.CatalogRuntime.spotifyMatchFor(uri) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) {
                com.music.spotui.data.catalog.SpotifyMatch.Unavailable(e.message ?: e.javaClass.simpleName)
            }
            if (m !is com.music.spotui.data.catalog.SpotifyMatch.Found) {
                AppLog.d("catalog: $uri not played on Spotify: $m")
                com.music.spotui.data.catalog.SpotifyMatch.message(m)?.let { android.widget.Toast.makeText(Graph.app, it, android.widget.Toast.LENGTH_SHORT).show() }
                return@launch
            }
            val (id, t) = m.id to m.track
            playSong(buildSpotifyPlayQuery(id, t.name, t.artists.joinToString(", ") { it.name }), context, askExtensions = askExtensions, alone = true)
        }
    }

    fun buildSpotifyPlayQuery(spotifyTrackId: String, title: String, artist: String): String {
        val searchText = listOf(title.replace(featSearchPattern, "").trim(), artist)
            .filter { it.isNotBlank() }
            .joinToString(" ")
        return if (spotifyTrackId.isBlank()) searchText else "$SPOTIFY_TRACK_PREFIX$spotifyTrackId|$searchText"
    }

    private fun spotifyTrackIdForPlayback(song: String): String? =
        if (song.startsWith(SPOTIFY_TRACK_PREFIX)) {
            song.removePrefix(SPOTIFY_TRACK_PREFIX).substringBefore('|').takeIf { it.isNotBlank() }
        } else {
            null
        }

    // Media cache for the looping Canvas video on the now-playing screen, sized as Settings > Storage says (at its first use).
    @Volatile private var mediaCache: androidx.media3.datasource.cache.SimpleCache? = null

    @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
    internal fun mediaCache(context: Context): androidx.media3.datasource.cache.SimpleCache =
        mediaCache ?: synchronized(this) {
            mediaCache ?: com.music.spotui.data.MediaCacheStartup.open(
                context,
                com.music.spotui.data.MediaCacheStartup.clearPreviousSession,
                com.music.spotui.data.AppStorage.mediaCacheLimit(),
            ).also { mediaCache = it }
        }
}
