package com.music.spotui.data.preferences

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

// Trimmed from Spotui: stream quality, YouTube and web-playback settings are gone (the Web
// Player engine streams Spotify's own audio). Crossfade is ours: a fade, not an overlap.

private const val PREF = "settings_prefs"
private const val KEY_LIBRARY_GRID = "library_grid_view"
private const val KEY_LYRIC_TRANSLATE_LANG = "lyric_translate_lang"
private const val KEY_LYRICS_EXTRA = "lyrics_extra_sources"
private const val KEY_CROSSFADE = "crossfade_seconds"

/** Extra lyrics sources (NetEase, Genius) when Spotify and LRCLIB have none. On by default: more songs have words. */
fun isLyricsExtraSources(c: Context): Boolean = prefs(c).getBoolean(KEY_LYRICS_EXTRA, true)
fun setLyricsExtraSources(c: Context, v: Boolean) = prefs(c).edit().putBoolean(KEY_LYRICS_EXTRA, v).apply()
/** The extra sources were turned off by hand (never touched: Genius is still the last resort). */
fun isLyricsExtraSourcesOff(c: Context): Boolean = prefs(c).let { it.contains(KEY_LYRICS_EXTRA) && !it.getBoolean(KEY_LYRICS_EXTRA, false) }

/** Lyrics timed word by word first (karaoke); off: line by line, Spotify's first. */
fun isLyricsWordSync(c: Context): Boolean = prefs(c).getBoolean("lyrics_word_sync", true)
fun setLyricsWordSync(c: Context, v: Boolean) = prefs(c).edit().putBoolean("lyrics_word_sync", v).apply()

private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

/**
 * Genius (on by default): what a song means and the notes on its lines, and Genius's plain-text
 * lyrics as a last resort. Off: nothing is asked of genius.com and the Genius parts (the light
 * bulb, the underlined lines, the "Meaning" row, Genius among the lyrics sources) are gone. Read as
 * state by both looks; read off the main thread by GeniusMeaning and LyricsApi (true before the
 * app is set up, in tests).
 */
object GeniusPref {
    private const val KEY = "genius"
    var on by androidx.compose.runtime.mutableStateOf(
        runCatching { prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, true) }.getOrDefault(true))
        private set

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
        if (!value) com.music.spotui.data.api.GeniusMeaning.forget()
        // Lyrics read from Genius before are not kept: the song is read again from the others.
        com.music.spotui.data.api.LyricsApi.forgetAll()
    }
}

/**
 * "Show romanization" under the lyrics' lines (the song in Latin letters), offered when the lyrics
 * carry one. Off by default; read as state by both looks, so the menu and the lines agree.
 */
object LyricsRomanizationPref {
    private const val KEY = "lyrics_romanization"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, false))
        private set

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

object LyricsTranslateButtonPref {
    private const val KEY = "lyrics_translate_button_visible"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, true))
        private set

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

/** The bottom bar: fading into the list (the default), or solid black. Read by the bar as state. */
object SolidNavBar {
    private const val KEY = "solid_nav_bar"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, false))
        private set

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

/** Best effort only: Android and the current audio route still control whether media is audible. */
object MusicDuringCallsPref {
    private const val KEY = "music_during_calls"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, false))
        private set

    fun set(c: Context, value: Boolean) {
        if (on == value) return
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
        com.music.spotui.di.SongPlayer.refreshCallPolicy()
    }
}

/** "When your music ends, keep playing similar songs" (on by default). Read by the player. */
object AutoplayPref {
    private const val KEY = "autoplay_similar"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, true))
        private set

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

/**
 * "Myspoti shuffle" (on by default: Spotify's replayed songs before the end of the list, reported): with shuffle on, a list plays every one of its songs once, in
 * an order Myspoti draws, before it starts over, instead of Spotify's shuffle (see
 * [com.music.spotui.di.AppShuffle]). Off: Spotify shuffles, as before.
 */
object AppShufflePref {
    private const val KEY = "myspoti_shuffle"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, true))
        private set

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
        if (!value) com.music.spotui.di.AppShuffle.forget()
    }
}

/**
 * "Count extension plays on your music account": a song an extension streams live is played by the
 * chosen account provider's web player too ([AccountProviderPref]: Spotify's Web Player, YouTube
 * Music's web app), unheard, so the provider counts it (and Spotify Connect sees and controls it; see
 * [com.music.spotui.di.AccountSync]). Off: the extension's stream alone. Off for a new install; an
 * install from before this default keeps what it had (on, the earlier default, when never changed),
 * and the value read the first time is stored so a later update keeps it. Downloads are never
 * synced (the earlier "Sync downloaded songs with Spotify" key, `download_spotify_sync`, is no
 * longer read).
 */
object ConnectMirrorPref {
    private const val KEY = "connect_mirror"
    var on by androidx.compose.runtime.mutableStateOf(initial(com.music.spotui.di.Graph.app))
        private set

    private fun initial(c: Context): Boolean {
        val p = prefs(c)
        if (p.contains(KEY)) return p.getBoolean(KEY, false)
        // Never set: an update of an older install or a TV had it on by default, a new phone install starts off.
        val updated = com.music.spotui.ui.tv.Tv.isTv(c) ||
            runCatching { c.packageManager.getPackageInfo(c.packageName, 0).let { it.lastUpdateTime > it.firstInstallTime } }
                .getOrDefault(false)
        p.edit().putBoolean(KEY, updated).apply()
        return updated
    }

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
        com.music.spotui.di.AccountSync.listen.refresh()
    }
}

/**
 * The automatic update check at launch (on by default: the app behaved that way before this
 * option existed). Off means no check when the app starts — a check asked for in Settings still
 * works, it reads the same release list.
 */
object AutoUpdateCheckPref {
    private const val KEY = "auto_update_check"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, true))
        private set

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

/** Screen rotation: portrait (the default), automatic (follows the system), or landscape. */
object OrientationPref {
    private const val KEY = "screen_orientation"
    const val PORTRAIT = "portrait"
    const val AUTO = "auto"
    const val LANDSCAPE = "landscape"
    var mode by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getString(KEY, PORTRAIT) ?: PORTRAIT)
        private set

    fun set(c: Context, value: String) {
        mode = value
        prefs(c).edit().putString(KEY, value).apply()
    }

    /** The [android.content.pm.ActivityInfo] value for the chosen mode. */
    fun requested(): Int = when (mode) {
        AUTO -> android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        LANDSCAPE -> android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else -> android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    }
}

/** Library layout: false = rows (default), true = Spotify-style 3-column grid. */
fun isLibraryGridView(c: Context): Boolean = prefs(c).getBoolean(KEY_LIBRARY_GRID, false)
fun setLibraryGridView(c: Context, v: Boolean) = prefs(c).edit().putBoolean(KEY_LIBRARY_GRID, v).apply()

/**
 * Crossfade length in seconds, 0 = off (the default: nothing changes unless asked for).
 *
 * It is a fade, not an overlap: the page plays one media element, so the next song cannot
 * start before this one ends. The song fades out over its last N seconds, the next one fades
 * in. The value is Compose state, so the settings row redraws when it changes.
 */
object CrossfadePref {
    const val MAX = 12
    var seconds by androidx.compose.runtime.mutableStateOf(
        prefs(com.music.spotui.di.Graph.app).getInt(KEY_CROSSFADE, 0).coerceIn(0, MAX),
    )
        private set

    /** Saves it and hands it to the player: the change applies to the song playing now. */
    fun set(c: Context, value: Int) {
        val v = value.coerceIn(0, MAX)
        seconds = v
        prefs(c).edit().putInt(KEY_CROSSFADE, v).apply()
        applyCrossfade(v)
    }
}

/**
 * How the local player's songs follow each other: one choice over [CrossfadePref] and AutoMix,
 * which never run together (AutoMix on, the crossfade's length is kept for later but unused).
 * Spotify songs, which AutoMix cannot mix (the app never has the Web Player's audio), then change
 * with a short fade of [SPOTIFY_FADE_SECONDS] rather than with that kept length (up to 12 s).
 */
object TransitionPref {
    enum class Mode { OFF, CROSSFADE, AUTOMIX }

    /** The Spotify songs' fade while AutoMix is on, seconds. */
    const val SPOTIFY_FADE_SECONDS = 3

    val mode: Mode get() = when {
        com.music.spotui.automix.AutoMix.on -> Mode.AUTOMIX
        CrossfadePref.seconds > 0 -> Mode.CROSSFADE
        else -> Mode.OFF
    }

    fun set(c: Context, mode: Mode) {
        val automix = mode == Mode.AUTOMIX
        if (automix != com.music.spotui.automix.AutoMix.on) {
            com.music.spotui.automix.AutoMix.set(automix)
            com.music.spotui.di.LocalPlayer.autoMixChanged(automix)
        }
        when (mode) {
            Mode.OFF -> CrossfadePref.set(c, 0)
            // Back to the crossfade: its last length, 6 s the first time.
            Mode.CROSSFADE -> if (CrossfadePref.seconds == 0) CrossfadePref.set(c, 6)
            Mode.AUTOMIX -> Unit
        }
    }
}

/**
 * "Music videos": the video button in the player, the lookup behind it and a clip that starts
 * by itself on the next song. On by default; off, the player is audio (and Canvas) only.
 */
object MusicVideoPref {
    private const val KEY = "music_video_enabled"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, true))
        private set

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
        if (!value) com.music.spotui.video.MusicVideoController.setOn(false)
    }
}

/**
 * "Hide the DJ" on Home (off by default): Spotify's DJ, which comes in the home feed as a
 * playlist card, leaves the shelves. Read by both Home screens as state.
 */
object HideDjPref {
    private const val KEY = "hide_dj"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, false))
        private set

    /** Hidden here or by an extension's look (`home.dj`). */
    val hidden: Boolean get() = on || com.music.spotui.extensions.ExtensionLook.hides(app.myspoti.extensions.UiPart.HOME_DJ)

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

object HidePodcastsPref {
    private const val KEY = "hide_podcasts"
    var on by androidx.compose.runtime.mutableStateOf(
        runCatching { prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, false) }.getOrDefault(false)
    )
        private set

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

fun getCrossfadeSeconds(c: Context): Int =
    prefs(c).getInt(KEY_CROSSFADE, 0).coerceIn(0, CrossfadePref.MAX)

/** Gives the saved length to the player (at start, and at every change); 0 stops a fade at once. */
fun applyCrossfade(seconds: Int) {
    // The local player: its audio offload is allowed only without a crossfade, its fade timer follows.
    com.music.spotui.di.LocalPlayer.crossfadeChanged()
    val runtime = app.myspoti.host.android.MyspotiRuntime
    if (!runtime.isStarted) return
    // AutoMix on: the crossfade length is only kept for later, the Spotify songs get a short fade.
    runtime.spotify.player.crossfadeSeconds = if (com.music.spotui.automix.AutoMix.on) TransitionPref.SPOTIFY_FADE_SECONDS else seconds
}

fun getLyricTranslateLang(c: Context): String =
    prefs(c).getString(KEY_LYRIC_TRANSLATE_LANG, "").orEmpty()

fun setLyricTranslateLang(c: Context, code: String) =
    prefs(c).edit().putString(KEY_LYRIC_TRANSLATE_LANG, code.trim()).apply()

/**
 * Liquid Glass in the Immersive look (Settings > Display, under Look): the floating bars refract
 * the page through a lens instead of only frosting it. On by default; it only takes effect on
 * Android 12+ and when the phone does not ask for less blur or motion (see
 * [com.music.spotui.ui.immersive.shell.rememberLiquidGlassActive]).
 */
object LiquidGlassPref {
    private const val KEY = "immersive_liquid_glass"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, true))
        private set

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

/**
 * "Lyrics preview in the player" (Settings > Display, Classic look): the lyrics card under the
 * player. On by default; off, the lyrics still open with a flick up on the cover.
 */
object PlayerLyricsCardPref {
    private const val KEY = "player_lyrics_card"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, true))
        private set

    /** Shown: on here and not hidden by an extension's look (`player.lyrics-card`). */
    val shown: Boolean get() = on && !com.music.spotui.extensions.ExtensionLook.hides(app.myspoti.extensions.UiPart.PLAYER_LYRICS_CARD)

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

object LyricsSwipeExpandPref {
    private const val KEY = "lyrics_swipe_expand_fullscreen"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, true))
        private set

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

object PlayerLyricsWrapPref {
    private const val KEY = "player_lyrics_wrap_long_line"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, true))
        private set

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

object PlayerVolumeButtonsPref {
    private const val KEY_ENABLED = "player_volume_buttons_enabled"
    private const val KEY_STEP = "player_volume_buttons_step"
    var enabled by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY_ENABLED, false))
        private set
    var step by androidx.compose.runtime.mutableIntStateOf(prefs(com.music.spotui.di.Graph.app).getInt(KEY_STEP, 5).coerceIn(1, 20))
        private set

    fun setEnabled(c: Context, value: Boolean) {
        enabled = value
        prefs(c).edit().putBoolean(KEY_ENABLED, value).apply()
    }

    fun setStep(c: Context, value: Int) {
        step = value.coerceIn(1, 20)
        prefs(c).edit().putInt(KEY_STEP, step).apply()
    }
}

object PlayerLyricsPreviewLinesPref {
    private const val KEY = "player_lyrics_preview_lines"
    var lines by androidx.compose.runtime.mutableIntStateOf(
        prefs(com.music.spotui.di.Graph.app).getInt(KEY, 1).coerceIn(1, 3)
    )
        private set

    fun set(c: Context, value: Int) {
        val clamped = value.coerceIn(1, 3)
        lines = clamped
        prefs(c).edit().putInt(KEY, clamped).apply()
    }
}

/**
 * "Source and quality in the player" (Settings > Display, both looks): the line that says what
 * plays and how (under the title in the Immersive look, under the device in the Classic one). On
 * by default; off, the player's menu has the Sound quality row (and Stats for nerds) instead.
 */
object ArtworkLoopPref {
    private const val KEY = "artwork_loop"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, false))
        private set
    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

object ImmersiveChromePref {
    private val store get() = prefs(com.music.spotui.di.Graph.app)
    var handle by androidx.compose.runtime.mutableStateOf(store.getBoolean("player_handle_visible", true))
        private set
    var stats by androidx.compose.runtime.mutableStateOf(store.getBoolean("player_stats_shortcut", false))
        private set
    var canvas by androidx.compose.runtime.mutableStateOf(store.getBoolean("player_canvas_focus", false))
        private set
    fun handle(value: Boolean) { handle = value; store.edit().putBoolean("player_handle_visible", value).apply() }
    fun stats(value: Boolean) { stats = value; store.edit().putBoolean("player_stats_shortcut", value).apply() }
    fun canvas(value: Boolean) { canvas = value; store.edit().putBoolean("player_canvas_focus", value).apply() }
}

object PlayerSourceLinePref {
    private const val KEY = "player_source_line"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, true))
        private set

    /** Shown: on here and not hidden by an extension's look (`player.source`). */
    val shown: Boolean get() = on && !com.music.spotui.extensions.ExtensionLook.hides(app.myspoti.extensions.UiPart.PLAYER_SOURCE)

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

/**
 * "Capsule in the player" (Settings > Display, Immersive look): the capsule at the bottom of the
 * player (devices, with shuffle and repeat when [PlayerModesPref] is on). On by default; off, the
 * player's menu has a Listen on row for the devices.
 */
object PlayerCapsulePref {
    private const val KEY = "immersive_player_capsule"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, true))
        private set

    /** Shown: on here and not hidden by an extension's look (`player.capsule`). */
    val shown: Boolean get() = on && !com.music.spotui.extensions.ExtensionLook.hides(app.myspoti.extensions.UiPart.PLAYER_CAPSULE)

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

/**
 * "Shuffle and repeat in the player" (Settings > Display, Immersive look): on, the player's
 * bottom capsule holds shuffle, repeat and devices (2.2); off, only devices, as in 2.1.0 (the
 * queue panel keeps shuffle and repeat). Off by default: the owner's call, and asked on Discord.
 */
object PlayerModesPref {
    private const val KEY = "immersive_player_modes"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, false))
        private set

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

/**
 * "Volume bar in the player" (Settings > Display, Immersive look): the volume slider under the
 * transport. On by default; off, the phone's volume keys still do it, and the bottom row moves up
 * into its place while the cover and the other controls stay where they are (#186).
 */
object PlayerVolumePref {
    private const val KEY = "immersive_player_volume"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, true))
        private set

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

/**
 * "Keep the screen on with lyrics" (Settings > Playback, both looks): while the lyrics are open
 * the screen does not go dark, so the lines can be followed, for 10 minutes after the last touch
 * (no limit while charging). On by default. Read as state by the lyrics of both looks.
 */
object LyricsKeepAwakePref {
    private const val KEY = "lyrics_keep_screen_on"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, true))
        private set

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}

/**
 * "Picture-in-picture" (Settings > Display, both looks): leaving the app while a song plays opens
 * a small window with its cover, the line being sung and previous, play/pause and next buttons
 * ([com.music.spotui.ui.components.SongPip]). Off by default: asked for on Discord, and "keep it
 * optional" there too. A music video keeps its own window whatever this says.
 */
object SongPipPref {
    private const val KEY = "song_pip"
    var on by androidx.compose.runtime.mutableStateOf(prefs(com.music.spotui.di.Graph.app).getBoolean(KEY, false))
        private set

    fun set(c: Context, value: Boolean) {
        on = value
        prefs(c).edit().putBoolean(KEY, value).apply()
    }
}
