# VN-Revera 1.0.7-vn1

This is a personal fork based on Revera 1.0.7.

## Changes

- Long lyric wrapping in the immersive player's inline lyric preview is enabled by default. The current lyric can use the available preview rows; the following lyric line is suppressed while wrapping is enabled so it cannot displace the continuation of the current lyric.
- Optional volume icon buttons in the immersive player. Disabled by default. When enabled, the left icon lowers and the right icon raises volume by the configured percentage step. The step cycles through 1%, 2%, 5%, 10%, and 15% in Display settings. The local Android music stream or active Spotify Connect device volume is adjusted as appropriate.
- App identity changed to `app.vn.revera`, label `VN-Revera`, version `1.0.7-vn1`, version code `210`, so it can be installed alongside the original Revera.

## Build note

Build with the Android Gradle project in `base/`. A successful APK build has not yet been verified in this environment because the Gradle distribution could not be downloaded (network unavailable). Do not treat this source archive as a tested APK.

A manual GitHub Actions workflow is included at `.github/workflows/vn-apk.yml`. After this source is pushed to the user's fork, run **Actions → VN-Revera APK → Run workflow**; the arm64 debug APK is uploaded as a workflow artifact.


## VNEra 2.1.0
- Added JSON import/export for app settings in both Classic and Immersive Settings > App.
- Moved Wrap Long Lyrics into Settings > Lyrics.
- Added a Lyrics setting to enable swipe gestures: swipe down to expand lyrics full-screen with animation, swipe up to return to the player.
- Preserved AutoMix Very Long (95 seconds).
