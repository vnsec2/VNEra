package com.music.spotui.data.offline

import android.util.Log
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.snapshots.SnapshotStateMap
import com.music.spotui.data.entity.SongsModel
import com.music.spotui.data.preferences.isDownloadsEnabled
import com.music.spotui.di.Graph
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.sync.withPermit
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import com.music.spotui.extensions.MediaHttp
import java.util.concurrent.ConcurrentHashMap

/**
 * Downloads songs for offline listening. Spotify only gives the track (title, artist,
 * duration, ISRC); where the audio file is, and that it is the right recording, is the job
 * of a `download-source` extension (docs/extensions/API.md §3), which answers the files it
 * has, best first. Myspoti then:
 *
 * 1. fetches the first file that works (a FLAC, a DASH manifest of FLAC frames joined
 *    into one FLAC, or an M4A / MP3);
 * 2. checks what any file must pass, whoever sent it: real, decodable audio whose length
 *    is the song's (Spotify's duration), so a preview or another cut is refused;
 * 3. keeps it encrypted ([OfflineCrypto]), with its cover, in the Downloaded list — unless
 *    "visible files" is on ([OfflineStore.isPublicAudio]): the song is then saved in plain in
 *    the phone's Download folder (Download/Orpheon), where the file manager and other players see it.
 * 4. embeds the track's lyrics in the file itself ([LyricsEmbedder]: USLT/SYLT, `©lyr`,
 *    Vorbis LYRICS — plus a `.lrc` sidecar next to a visible FLAC), for other players.
 *
 * No extension giving download files: downloads say to install one. Nothing that fails the
 * check is kept: the song is marked unavailable instead.
 */
object OfflineDownloader {
    private const val TAG = "Offline"
    private const val WORKERS = 3
    /** A file may be this much shorter than the song (seconds): more is a preview or a cut. */
    private const val SHORTER_MAX = 5
    /** And this much longer (trailing silence, a longer intro): more is another version. */
    private const val LONGER_MAX = 15
    /** How long a download waits for the lyrics before going on without them. */
    private const val LYRICS_WAIT_MS = 15_000L

    data class Request(
        val trackId: String,
        val title: String,
        val artist: String,
        val album: String,
        val albumId: String,
        val durationMs: Long,
        val coverUrl: String,
        /** The quality chosen for this download ([DownloadQuality.name]); empty = the setting. */
        val quality: String = "",
    ) {
        fun toJson(): JSONObject = JSONObject().put("id", trackId).put("title", title).put("artist", artist)
            .put("album", album).put("albumId", albumId).put("duration", durationMs).put("cover", coverUrl)
            .put("quality", quality)

        companion object {
            fun of(s: SongsModel) = Request(
                trackId = s.spotifyTrackId, title = s.title, artist = s.singer, album = s.album,
                albumId = s.albumId, durationMs = s.durationMs.toLong(), coverUrl = s.coverUri,
            )
            fun fromJson(o: JSONObject) = Request(
                o.getString("id"), o.optString("title"), o.optString("artist"), o.optString("album"),
                o.optString("albumId"), o.optLong("duration"), o.optString("cover"), o.optString("quality"),
            )
        }
    }

    private class Unavailable(message: String) : Exception(message)

    /** Two AAC encodes at once at most: the CPU stays free for the rest of the app. */
    private val encodeSlots = kotlinx.coroutines.sync.Semaphore(2)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    /** Songs queued, downloading, or whose download did not succeed (for the Downloaded list). */
    val requests: SnapshotStateMap<String, Request> = mutableStateMapOf()
    private val queue = Channel<Request>(Channel.UNLIMITED)
    /** Requests not finished yet, in order (persisted: a restart resumes them). */
    private val pending = LinkedHashMap<String, Request>()
    private val running = ConcurrentHashMap<String, Job>()
    @Volatile private var started = false

    private fun start() {
        if (started) return
        synchronized(this) {
            if (started) return
            started = true
            repeat(WORKERS) { scope.launch { for (r in queue) work(r) } }
        }
    }

    /** Re-queues what was waiting when the app last stopped. */
    fun resumePending() {
        // Read off the main thread (the app is already drawing): the queue fills a moment later.
        scope.launch {
            val saved = runCatching {
                val a = JSONArray(OfflineStore.pendingFile.readText())
                (0 until a.length()).map { Request.fromJson(a.getJSONObject(it)) }
            }.getOrDefault(emptyList())
            if (saved.isNotEmpty()) enqueueAll(saved)
            DownloadNotifier.changed()
        }
    }

    /**
     * Downloads [songs] in [quality] (asked when the setting is "ask each time"), else in
     * the quality chosen in Settings.
     */
    /**
     * Whether a download can start now, said in a toast when not: downloads switched off in
     * Settings (instead of a list of failed songs), or no extension giving download files (where to
     * get one, for a download the user asked for). A list is only marked downloaded when this holds.
     */
    fun ready(auto: Boolean = false): Boolean {
        if (!isDownloadsEnabled(Graph.app)) {
            scope.launch(Dispatchers.Main) {
                android.widget.Toast.makeText(Graph.app, app.myspoti.engine.R.string.downloads_off_toast, android.widget.Toast.LENGTH_LONG).show()
            }
            return false
        }
        if (!com.music.spotui.extensions.Extensions.hasDownloadSource()) {
            if (!auto) scope.launch(Dispatchers.Main) {
                android.widget.Toast.makeText(Graph.app, app.myspoti.engine.R.string.downloads_need_source, android.widget.Toast.LENGTH_LONG).show()
            }
            return false
        }
        return true
    }

    fun enqueue(
        songs: List<SongsModel>,
        quality: com.music.spotui.data.preferences.DownloadQuality? = null,
        /** Started by the app (a downloaded list keeping in step), not by a tap. */
        auto: Boolean = false,
    ) {
        if (!ready(auto)) return
        if (auto) {
            // Automatic downloads wait for Wi-Fi (never the user's mobile data): the next sync takes them.
            if (com.music.spotui.data.DataSaver.metered || !OfflineStore.isOnline(Graph.app)) { OfflineCollections.waitForWifi(); return }
        } else if (com.music.spotui.data.DataSaver.metered) {
            // Asked for by the user on mobile data: it goes ahead, but they are told.
            scope.launch(Dispatchers.Main) {
                android.widget.Toast.makeText(Graph.app, app.myspoti.engine.R.string.download_on_mobile_data, android.widget.Toast.LENGTH_LONG).show()
            }
        }
        val q = quality?.let { com.music.spotui.data.preferences.DownloadQuality.saved(it.name) }?.name.orEmpty()
        // Episodes go to PodcastDownloader: their id is no track id, so the download-source lookup
        // would 404 (or worse, match an unrelated recording by title).
        enqueueAll(songs.filter { it.spotifyTrackId.isNotBlank() && !isEpisodeKey(it.spotifyTrackId) }.map { Request.of(it).copy(quality = q) })
    }

    private fun enqueueAll(list: List<Request>) {
        val added = synchronized(pending) {
            list.filter { r ->
                // Last guard before the track download path, whatever the caller (resume, retry, list).
                !isEpisodeKey(r.trackId) &&
                    !OfflineStore.isDownloaded(r.trackId) && pending.putIfAbsent(r.trackId, r) == null
            }.also { if (it.isNotEmpty()) savePending() }
        }
        if (added.isEmpty()) return
        scope.launch(Dispatchers.Main) {
            added.forEach { requests[it.trackId] = it; OfflineStore.status[it.trackId] = OfflineStatus.Queued }
            DownloadNotifier.changed()
        }
        start()
        added.forEach { queue.trySend(it) }
    }

    /**
     * The account's downloads are put away (sign-out, another account signing in): the queue is
     * dropped from memory only (its file goes with the account's folder) and the running downloads
     * stop, waited for a moment so none finishes into the next account's folder.
     */
    internal suspend fun forgetSession() {
        synchronized(pending) { pending.clear() }
        val jobs = running.values.toList()
        running.clear()
        jobs.forEach { it.cancel() }
        kotlinx.coroutines.withTimeoutOrNull(5_000) { jobs.forEach { it.join() } }
        withContext(Dispatchers.Main) { requests.clear() }
        DownloadNotifier.changed()
    }

    /** Stops a queued or running download (and forgets a failed one). */
    fun cancel(trackId: String) {
        synchronized(pending) { if (pending.remove(trackId) != null) savePending() }
        running.remove(trackId)?.cancel()
        OfflineStore.status.remove(trackId)
        requests.remove(trackId)
        DownloadNotifier.changed()
    }

    /**
     * Stops every running and queued download and empties the queue. Unlike [removeAll], it
     * deletes nothing: finished songs stay in [OfflineStore.tracks] and in the index, and a
     * cancelled download only drops its own partial file in the temp folder.
     */
    fun stopAll() {
        // The queue survives a restart through pending.json: clearing it here is what makes the
        // stop stick, instead of the downloads resuming at the next launch.
        val ids = synchronized(pending) { pending.keys.toList().also { pending.clear(); savePending() } }
        // Running jobs may not all be in `pending` any more; cancel them by their own handle.
        running.values.forEach { it.cancel() }
        running.clear()
        // Snapshot state: the badges and the list are read from the UI, so write them there.
        scope.launch(Dispatchers.Main) {
            ids.forEach { OfflineStore.status.remove(it); requests.remove(it) }
            DownloadNotifier.changed()
        }
    }

    /** Tries a failed song again. */
    fun retry(trackId: String) {
        val r = requests[trackId] ?: return
        enqueueAll(listOf(r))
    }

    /** Removes the song: the file if downloaded, else its download. */
    fun remove(trackId: String) {
        cancel(trackId)
        // File deletion on the IO scope, not the (UI) caller's thread.
        scope.launch { OfflineStore.remove(trackId) }
    }

    fun removeAll() {
        val ids = synchronized(pending) { pending.keys.toList().also { pending.clear(); savePending() } }
        ids.forEach { running.remove(it)?.cancel() }
        running.values.forEach { it.cancel() }
        requests.clear()
        DownloadNotifier.changed()
        // Deleting a large library can take a while: IO scope, not the caller.
        scope.launch { OfflineCollections.removeAll(); OfflineStore.removeAll() }
    }

    private fun savePending() {
        runCatching {
            val a = JSONArray()
            pending.values.forEach { a.put(it.toJson()) }
            com.music.spotui.data.writeTextSafely(OfflineStore.pendingFile, a.toString())
        }
    }

    /** [by]: the download sources a failure waits for (Extensions.NotAnswering), shown on its row. */
    private suspend fun setStatus(id: String, s: OfflineStatus?, by: List<String> = emptyList()) = withContext(Dispatchers.Main) {
        if (by.isEmpty()) OfflineStore.notAnswering.remove(id) else OfflineStore.notAnswering[id] = by.joinToString(", ")
        if (s == null) OfflineStore.status.remove(id) else OfflineStore.status[id] = s
        if (s !is OfflineStatus.Downloading) DownloadNotifier.changed()
    }

    private suspend fun work(r: Request) {
        // Cancelled while it waited in the queue.
        if (synchronized(pending) { !pending.containsKey(r.trackId) }) return
        // Data saver on mobile data: downloads wait for Wi-Fi.
        while (com.music.spotui.data.DataSaver.active) {
            kotlinx.coroutines.delay(5_000)
            if (synchronized(pending) { !pending.containsKey(r.trackId) }) return
        }
        val job = scope.launch {
            var by = emptyList<String>()
            val outcome: OfflineStatus? = try {
                setStatus(r.trackId, OfflineStatus.Downloading(-1f))
                DownloadNotifier.changed()
                val t = download(r)
                // Already on the IO scope: the index rewrite stays off the main thread.
                OfflineStore.add(t)
                withContext(Dispatchers.Main) { requests.remove(r.trackId) }
                DownloadNotifier.changed()
                // Its lyrics kept with it, for playing offline (looked up behind, one song at a time).
                if (com.music.spotui.data.preferences.LyricsOfflinePref.on) com.music.spotui.data.api.LyricsApi.keepForOffline(
                    com.music.spotui.data.api.LyricsApi.Track(r.trackId, r.title, r.artist, r.album, r.durationMs, r.coverUrl))
                null
            } catch (e: CancellationException) {
                throw e
            } catch (e: Unavailable) {
                Log.i(TAG, "${r.title}: ${e.message}")
                OfflineStatus.Unavailable
            } catch (e: com.music.spotui.extensions.Extensions.NotAnswering) {
                // Failed, not unavailable: a source could not answer or was not asked (inactive, still starting),
                // so a tap on the song tries it again.
                Log.i(TAG, "${r.title}: download source not answering: ${e.message}")
                by = e.sources
                OfflineStatus.Failed
            } catch (t: Throwable) {
                Log.w(TAG, "${r.title} failed", t)
                OfflineStatus.Failed
            }
            synchronized(pending) { pending.remove(r.trackId); savePending() }
            if (outcome != null) setStatus(r.trackId, outcome, by)
        }
        running[r.trackId] = job
        job.join()
        running.remove(r.trackId, job)
    }

    private suspend fun download(r: Request): OfflineTrack {
        if (!isDownloadsEnabled(Graph.app)) throw Unavailable("downloads are off")
        val quality = qualityOf(r)
        val tmp = OfflineStore.tmpDir
        val audioTmp = File(tmp, "${r.trackId}.part")
        try {
            val meta = spotifyMeta(r)
            Log.i(TAG, "${meta.title}: isrc=${meta.isrc ?: "-"}")

            // ── The files the download-source extensions give, tried in their order; each one
            // is checked (real audio, the song's length) before it is taken.
            val file = resolveAndFetch(r, meta, audioTmp, quality)
            currentCoroutineContext().ensureActive()

            val out: File
            // Visible files: a readable name ("Artist - Title [trackId].flac") in the Download
            // folder; private files keep the bare track id as their name, as before.
            val public = OfflineStore.isPublicAudio
            val ext = if (file.lossy != null) file.lossy
                else if (quality == com.music.spotui.data.preferences.DownloadQuality.SMALL) "m4a" else "flac"
            val name = if (public) publicFileName(meta.title, meta.artist, r.trackId, ext) else "${r.trackId}.$ext"
            out = File(OfflineStore.songAudioDir, name)
            if (public) OfflineStore.songAudioDir.mkdirs()
            if (file.lossy != null) {
                // A small file as the source served it (M4A, MP3): kept as it is.
                if (!moveFile(audioTmp, out)) throw IOException("could not move the file")
            } else if (quality == com.music.spotui.data.preferences.DownloadQuality.SMALL) {
                // "Smallest": the checked FLAC becomes AAC, encoded on the phone.
                val aacTmp = File(OfflineStore.tmpDir, "${r.trackId}.m4apart")
                try {
                    // Encoding is long: a few at a time, the other downloads go on meanwhile.
                    encodeSlots.withPermit { runInterruptible(Dispatchers.Default) { AacTranscoder.transcode(audioTmp, aacTmp) } }
                    if (aacTmp.length() < 10_000 || !moveFile(aacTmp, out)) throw IOException("could not encode the small file")
                } finally {
                    aacTmp.delete()
                }
            } else {
                if (!moveFile(audioTmp, out)) throw IOException("could not move the file")
            }
            // The audio is complete on disk from here on: "stop all" must not interrupt this last
            // part, or the file would stay out of the index and be swept as a stray at startup.
            return withContext(NonCancellable) {
                // The cover, downloaded now: it is embedded in the file below, and kept
                // beside it as the <trackId>.jpg Orpheon's own screens read.
                val coverFile = runCatching {
                    val c = File(OfflineStore.coverDir, "${r.trackId}.jpg")
                    httpGet(app.myspoti.host.android.Covers.large(meta.coverUrl), c); c
                }.getOrNull()
                // Standard metadata, lyrics, and the cover are embedded before encryption
                // (private) or the MediaStore scan (public), so both see the final file.
                embedMetadataLyricsAndCoverInFile(r, meta, out, ext, coverFile)
                if (public) {
                    // In plain in the Download folder: visible in the file manager, playable by
                    // other apps. Announced to MediaStore so it shows up right away.
                    android.media.MediaScannerConnection.scanFile(Graph.app, arrayOf(out.path), arrayOf(mimeForExt(ext)), null)
                } else {
                    // Kept encrypted: the file only plays in Myspoti, on this phone.
                    runInterruptible(Dispatchers.IO) { OfflineCrypto.encryptInPlace(Graph.app, out) }
                }
                OfflineTrack(
                    trackId = r.trackId, title = meta.title, artist = meta.artist, album = meta.album,
                    albumId = meta.albumId, durationMs = meta.durationMs, coverUrl = meta.coverUrl,
                    file = out.name, cover = coverFile?.name ?: "",
                    source = if (quality == com.music.spotui.data.preferences.DownloadQuality.SMALL && file.lossy == null)
                        "${providerWithoutQuality(file.providerName)} AAC ${AacTranscoder.BITRATE / 1000} kbit/s" else file.provider,
                    verified = file.isrcMatched,
                    bytes = out.length(), addedAt = System.currentTimeMillis(), providerId = file.extensionId,
                    extensionQuality = com.music.spotui.extensions.Extensions.qualityLine(file.extensionId, app.myspoti.extensions.SettingSection.DOWNLOADS),
                    public = public,
                )
            }
        } finally {
            audioTmp.delete()
        }
    }

    /**
     * Embeds the track's standard metadata, lyrics and cover into the just-downloaded [file], for
     * other players. Metadata always comes from Spotify; lyrics use the same setting as keeping
     * them beside the download ("Download lyrics with songs"), and the cover is [coverFile].
     * A timeout, missing lyrics/cover, or an embedding error never fails the download.
     * The lyrics lookup is shared with [LyricsApi.keepForOffline], which runs
     * right after and finds it in the cache.
     */
    private suspend fun embedMetadataLyricsAndCoverInFile(r: Request, meta: Meta, file: File, ext: String, coverFile: File?) {
        val cover = coverFile?.takeIf { it.isFile }?.let { runCatching { it.readBytes() }.getOrNull() }
        var lyrics: com.music.spotui.data.entity.Lyrics? = null
        if (com.music.spotui.data.preferences.LyricsOfflinePref.on) {
            val track = com.music.spotui.data.api.LyricsApi.Track(
                r.trackId, meta.title, meta.artist, meta.album, meta.durationMs, meta.coverUrl)
            lyrics = withTimeoutOrNull(LYRICS_WAIT_MS) {
                runCatching { com.music.spotui.data.api.LyricsApi.fetch(track) }.getOrNull()
            }?.takeIf { com.music.spotui.data.api.LyricsApi.keepable(it) }
        }
        val tags = LyricsEmbedder.TrackMetadata(meta.title, meta.artist, meta.album)
        runCatching { LyricsEmbedder.embed(file, ext, lyrics, cover, OfflineStore.isPublicAudio, tags) }
            .onSuccess { if (it) Log.i(TAG, "${meta.title}: metadata, lyrics and cover embedded in the file") }
            .onFailure { Log.w(TAG, "${meta.title}: metadata/lyrics/cover not embedded: ${it.message}") }
    }

    private class Fetched(
        val provider: String,
        val isrcMatched: Boolean,
        /** The id of the download-source extension that supplied it. */
        val extensionId: String,
        /** The extension of a lossy file kept as served (m4a, mp3); null for a FLAC. */
        val lossy: String? = null,
        /** Source name before the measured quality is appended (encoding may change it). */
        val providerName: String = provider,
    )

    /** This download's quality: the one chosen when it started, else Settings (CD when Settings says "ask"). */
    private fun qualityOf(r: Request): com.music.spotui.data.preferences.DownloadQuality =
        com.music.spotui.data.preferences.DownloadQuality.saved(r.quality)
            ?: com.music.spotui.data.preferences.DownloadQuality.saved(com.music.spotui.data.preferences.getDownloadQuality(Graph.app).name)
            ?: com.music.spotui.data.preferences.DownloadQuality.CD

    /** The quality as a download-source extension is asked for it. */
    internal fun queryQuality(q: com.music.spotui.data.preferences.DownloadQuality): String = when (q) {
        com.music.spotui.data.preferences.DownloadQuality.HI_RES -> "hi-res"
        com.music.spotui.data.preferences.DownloadQuality.SMALL -> "small"
        else -> "cd"
    }

    /**
     * Asks the download-source extensions for [meta]'s files and saves the first one that works
     * into [out]: all of them are asked at once, and their files are tried best fit to [quality]
     * first ([downloadFit]; ties: the exact recording, then the user's order, then the order the
     * extension gave). When none of a round's files can be used, the extensions that answered
     * meanwhile are tried. Unavailable when no extension has a file, or none of them could be used.
     */
    private suspend fun resolveAndFetch(r: Request, meta: Meta, out: File, quality: com.music.spotui.data.preferences.DownloadQuality): Fetched {
        val track = com.music.spotui.extensions.Extensions.trackInfo(r.trackId, meta.title, meta.artist, meta.album, meta.durationMs, meta.coverUrl)
            .copy(isrc = meta.isrc)
        val seen = mutableListOf<String>()
        var tried = 0
        // The last error of a file that could not be fetched (not refused or failed a check): the song is then
        // a download that failed and can be tried again, not a recording that was not found.
        var fetchError: Exception? = null
        val fetched = com.music.spotui.extensions.Extensions.download(
            track, queryQuality(quality),
            fit = { files -> files.maxOf { downloadFit(quality, it) } },
            bestFit = BEST_FIT,
            graceMs = { best -> if (best >= BEST_FIT) GRACE_BEST_MS else GRACE_MS },
        ) { offers ->
            seen += offers.map { it.name }
            val files = downloadOrder(quality, offers.map { it.files })
            Log.i(TAG, "${meta.title}: trying ${files.size} files from ${offers.joinToString { it.name }}")
            files.firstNotNullOfOrNull { (i, file) ->
                tried++
                fetchOne(r, meta, out, file, offers[i].extensionId, offers[i].name) { fetchError = it }
            }
        }
        if (fetched != null) {
            com.music.spotui.extensions.Extensions.downloaded(fetched.extensionId, meta.title)
            return fetched
        }
        if (seen.isEmpty()) throw Unavailable("no download source has this song")
        fetchError?.let { throw IOException("none of the $tried files from ${seen.joinToString()} could be fetched: ${it.message}", it) }
        throw Unavailable("none of the $tried files from ${seen.joinToString()} could be used")
    }

    /**
     * [file] saved into [out] and checked, or null when it could not be fetched or is not the song
     * ([onFetchError] hears of a failure that is not a refusal).
     */
    private suspend fun fetchOne(
        r: Request, meta: Meta, out: File, file: app.myspoti.extensions.DownloadFile, extensionId: String, extension: String,
        onFetchError: (Exception) -> Unit,
    ): Fetched? {
        currentCoroutineContext().ensureActive()
        setStatus(r.trackId, OfflineStatus.Downloading(-1f))
        val provider = file.provider ?: extension
        var label = provider
        val ok = try {
            when {
                file.format == "dash-flac" -> runInterruptible(Dispatchers.IO) {
                    DashFlacRemux.download("data:application/dash+xml;base64,${file.manifest}", out, file.headers)
                }
                else -> fetchWithProgress(r.trackId, file.url!!, out, file.headers)
            } && out.length() >= 10_000 && runInterruptible(Dispatchers.IO) {
                file.transform?.let { spec ->
                    val staged = File.createTempFile("download-transform-", ".partial", out.parentFile)
                    try {
                        out.inputStream().use { input -> staged.outputStream().use { output ->
                            app.myspoti.extensions.PatternedBlowfish.transform(input, output, spec)
                        } }
                        if (Thread.currentThread().isInterrupted) throw java.io.InterruptedIOException("transform cancelled")
                        java.nio.file.Files.move(staged.toPath(), out.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING)
                    } finally { staged.delete() }
                }
                true
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "${meta.title}: $label ${file.format}: ${e.message}")
            if (e !is app.myspoti.extensions.ExtensionMediaHttp.Refused && !app.myspoti.extensions.SafeNet.isRefusal(e)) onFetchError(e)
            false
        }
        if (!ok) return null
        val refused = runCatching {
            if (file.lossless) {
                val actual = checkFlacHeader(out, meta)
                label = downloadSourceLabel(provider, actual)
                if (file.bitDepth != null && file.bitDepth != actual.bitDepth)
                    Log.i(TAG, "${meta.title}: source labelled ${file.bitDepth}-bit, file is ${actual.bitDepth}-bit")
            } else checkAudio(out, meta)
        }.exceptionOrNull()
        if (refused != null) { Log.i(TAG, "${meta.title}: $label: ${refused.message}"); return null }
        if (!file.lossless) {
            Log.i(TAG, "${meta.title}: saved $label ${file.format}")
            return Fetched(label, file.isrcMatched, extensionId, lossy = file.format)
        }
        Log.i(TAG, "${meta.title}: saved FLAC from $label")
        return Fetched(label, file.isrcMatched, extensionId, providerName = provider)
    }

    /**
     * A STREAMINFO read on the saved file: anything that is not a FLAC file (an encrypted or
     * AAC stream) is refused, a preview or another cut is caught (the header states the real
     * length). Bit depth and sample rate come from the file, not the extension's label.
     */
    private fun checkFlacHeader(file: File, meta: Meta): FlacStreamInfo {
        val actual = runCatching {
            file.inputStream().use { s ->
                val head = ByteArray(42); var off = 0
                while (off < head.size) { val n = s.read(head, off, head.size - off); if (n < 0) break; off += n }
                flacStreamInfo(head.copyOf(off))
            }
        }.getOrNull() ?: throw Unavailable("the source did not send a FLAC file")
        checkLength(actual.durationSeconds, meta)
        Log.d(TAG, "${meta.title}: FLAC ${actual.durationSeconds}s, ${actual.bitDepth}-bit, ${actual.sampleRate} Hz")
        return actual
    }

    /** An M4A / MP3 as served: the phone's own extractor must find an audio track of the song's length. */
    private fun checkAudio(file: File, meta: Meta) {
        val extractor = android.media.MediaExtractor()
        val seconds = try {
            extractor.setDataSource(file.path)
            val format = (0 until extractor.trackCount).map { extractor.getTrackFormat(it) }
                .firstOrNull { it.getString(android.media.MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
                ?: throw Unavailable("the source did not send an audio file")
            if (format.containsKey(android.media.MediaFormat.KEY_DURATION)) format.getLong(android.media.MediaFormat.KEY_DURATION) / 1_000_000 else -1L
        } catch (e: IOException) {
            throw Unavailable("the file could not be read: ${e.message}")
        } finally {
            extractor.release()
        }
        // No length in the track's header (some MP3 streams): the file's own metadata is asked next.
        val known = seconds.takeIf { it > 0 } ?: runCatching {
            android.media.MediaMetadataRetriever().let { r ->
                try {
                    r.setDataSource(file.path)
                    r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.div(1000)
                } finally { r.release() }
            }
        }.getOrNull()?.takeIf { it > 0 }
        if (known != null) checkLength(known, meta)
        else Log.w(TAG, "${meta.title}: length of the file unknown, not compared with the song's")
    }

    private fun checkLength(seconds: Long, meta: Meta) {
        lengthMismatch(seconds, meta.durationMs)?.let { throw Unavailable("backed out: $it") }
    }

    private data class Meta(
        val title: String, val artist: String, val album: String, val albumId: String,
        val durationMs: Long, val coverUrl: String, val isrc: String?,
    )

    /** The request, completed by Spotify's track (ISRC, and anything the list lacked). */
    private suspend fun spotifyMeta(r: Request): Meta {
        val api = app.myspoti.host.android.MyspotiRuntime.api
        val uri = "spotify:track:${r.trackId}"
        val t = runCatching { api.catalog.track(uri) }.onFailure { Log.w(TAG, "${r.title}: Spotify track: $it") }.getOrNull()
        val isrc = runCatching { api.catalog.isrc(uri) }.onFailure { Log.w(TAG, "${r.title}: ISRC: $it") }.getOrNull()
        val cover = r.coverUrl.ifBlank { t?.album?.images?.maxByOrNull { it.width ?: 0 }?.url.orEmpty() }
        return Meta(
            title = r.title.ifBlank { t?.name.orEmpty() },
            artist = r.artist.ifBlank { t?.artists?.joinToString(", ") { it.name }.orEmpty() },
            album = r.album.ifBlank { t?.album?.name.orEmpty() },
            albumId = r.albumId.ifBlank { t?.album?.uri?.substringAfterLast(':').orEmpty() },
            durationMs = r.durationMs.takeIf { it > 0 } ?: t?.durationMs ?: 0L,
            coverUrl = cover,
            isrc = isrc?.let(::normalizeIsrc),
        ).also { if (it.title.isBlank() || it.artist.isBlank()) throw Unavailable("no track metadata") }
    }

    // Covers and other plain files of the downloads (not music video): data saver aware, as before.
    private val plainHttp: okhttp3.OkHttpClient by lazy {
        okhttp3.OkHttpClient.Builder()
            .addInterceptor(com.music.spotui.data.DataSaver.interceptor)
            .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
            .build()
    }

    private suspend fun httpGet(url: String, out: File) = runInterruptible {
        InterruptibleHttp.read(plainHttp.newCall(okhttp3.Request.Builder().url(url).build())) { res ->
            if (!res.isSuccessful) throw IOException("HTTP ${res.code}")
            val body = res.body ?: throw IOException("empty body")
            out.outputStream().use { body.byteStream().copyTo(it) }
        }
    }

    /**
     * Downloads the file URL into [out] with HTTP **Range** requests in chunks,
     * reporting progress: a plain streaming GET with a browser User-Agent and the
     * extension's headers, retried per chunk on resets.
     */
    private suspend fun fetchWithProgress(trackId: String, url: String, out: File, headers: Map<String, String> = emptyMap()): Boolean {
        // A quick HEAD for the size: the progress bar needs it (-1 when the server says nothing).
        val total = runInterruptible(Dispatchers.IO) { contentLength(url, headers) }
        val watcher = if (total > 0) scope.launch {
            while (isActive) {
                setStatus(trackId, OfflineStatus.Downloading((out.length().toFloat() / total).coerceIn(0f, 1f)))
                delay(400)
            }
        } else null
        try {
            return runInterruptible(Dispatchers.IO) { rangedDownload(url, out, total, headers) }
        } finally {
            watcher?.cancel()
            setStatus(trackId, OfflineStatus.Downloading(-1f))
        }
    }

    /**
     * The byte range loop, shared with [PodcastDownloader]: a publisher's MP3 is fetched the
     * same way (follows the 302s to podtrac/radiofrance/simplecast, restarts from zero when a
     * server ignores Range, retries each chunk three times).
     */
    internal fun rangedDownload(url: String, out: File, knownTotal: Long, headers: Map<String, String> = emptyMap()): Boolean {
        val chunk = 4L * 1024 * 1024 // 4 MB: the stream gets its turn between two chunks
        var total = knownTotal
        java.io.RandomAccessFile(out, "rw").use { output ->
            output.setLength(0)
            while (true) {
                // A chunk is [start, end]; a retry resumes where the bytes stopped, never re-appends.
                val end = if (total > 0) minOf(output.length() + chunk - 1, total - 1) else output.length() + chunk - 1
                var done = false
                var attempt = 0
                yieldToPlayer()
                while (true) {
                    attempt++
                    val position = output.length()
                    // The safe client (see MediaHttp): redirects followed by hand and re-checked, the headers kept on their own host only.
                    try {
                        MediaHttp.open(url, headers = headers, fixed = mapOf("User-Agent" to DownloadUa, "Range" to "bytes=$position-$end"), timeoutMs = 60_000).use { conn ->
                            val code = conn.response.code
                            // Asked past the end of a file whose size was unknown: it is complete.
                            if (code == 416 && total <= 0 && position > 0) { done = true; return@use }
                            if (code !in 200..299) throw IOException("stream HTTP $code")
                            val full = code != 206 // server ignored Range → the whole body, from byte 0
                            if (full) output.setLength(0)
                            // A part must be the one asked for: bytes from elsewhere in the file would be
                            // written at the wrong place and make a file that plays wrong.
                            if (!full) {
                                val span = contentRangeSpan(conn.response.header("Content-Range"))
                                if (span == null || span.first != position || span.last > end)
                                    throw IOException("stream sent ${conn.response.header("Content-Range") ?: "no Content-Range"} for bytes $position-$end")
                            }
                            if (total <= 0) total = contentRangeTotal(conn.response.header("Content-Range")) ?: -1L
                            output.seek(output.length())
                            val expected = if (full) -1L else end - position + 1
                            var got = 0L
                            conn.response.body.byteStream().use { input ->
                                val buf = ByteArray(256 * 1024)
                                while (true) {
                                    val n = input.read(buf)
                                    if (n < 0) break
                                    // Never more than the part asked for, whatever the server sends after it.
                                    val keep = if (expected >= 0) minOf(n.toLong(), expected - got).toInt() else n
                                    output.write(buf, 0, keep)
                                    got += keep
                                    if (expected in 0..got) break
                                }
                            }
                            if (full) done = true
                            // A short chunk with the size still unknown is the end of the stream.
                            else if (total <= 0 && got < expected) done = true
                        }
                        break
                    } catch (e: IOException) {
                        if (attempt >= 3 || e is app.myspoti.extensions.ExtensionMediaHttp.Refused || app.myspoti.extensions.SafeNet.isRefusal(e)) throw e
                        Log.w(TAG, "chunk at ${output.length()} failed (attempt $attempt): ${e.message}")
                    }
                }
                if (done) break
                if (total in 1..output.length()) break
            }
        }
        return true
    }

    /**
     * The song playing here is loading: downloads wait (up to 30 s) so they do not starve
     * it, or the player's stall watchdog would take it for stuck and skip it.
     */
    private fun yieldToPlayer() {
        var waited = 0
        while (waited < 30_000 && playerStarving()) {
            Thread.sleep(500); waited += 500
        }
    }

    private fun playerStarving(): Boolean = runCatching {
        com.music.spotui.di.SongPlayer.isPlaying() && com.music.spotui.di.SongPlayer.isBuffering &&
            com.music.spotui.di.SongPlayer.activeDevice.value == null && !com.music.spotui.di.LocalPlayer.active.value
    }.getOrDefault(false)

    private fun contentLength(url: String, headers: Map<String, String> = emptyMap()): Long =
        runCatching {
            MediaHttp.open(url, "HEAD", headers, mapOf("User-Agent" to DownloadUa)).use { conn ->
                conn.response.header("Content-Length")?.toLongOrNull()?.takeIf { it > 0 } ?: -1L
            }
        }.getOrDefault(-1L)

    // ── Pure helpers (unit-tested) ──

    /** File hosts expect a browser-ish User-Agent on downloads. */
    internal const val DownloadUa =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

    internal data class FlacStreamInfo(val sampleRate: Int, val bitDepth: Int, val channels: Int, val totalSamples: Long) {
        val durationSeconds: Long get() = totalSamples / sampleRate
    }

    /** The first metadata block must be the complete, 34-byte FLAC STREAMINFO block. */
    internal fun flacStreamInfo(head: ByteArray): FlacStreamInfo? {
        if (head.size < 42 || String(head, 0, 4, Charsets.US_ASCII) != "fLaC") return null
        if ((head[4].toInt() and 0x7F) != 0 || head[5] != 0.toByte() || head[6] != 0.toByte() || head[7] != 34.toByte()) return null
        // Bytes 18..25: sample rate (20 bits), channels (3), bits/sample (5), total samples (36).
        var bits = 0L
        for (i in 18..25) bits = (bits shl 8) or (head[i].toLong() and 0xFF)
        val sampleRate = (bits ushr 44).toInt()
        val channels = ((bits ushr 41) and 7).toInt() + 1
        val bitDepth = ((bits ushr 36) and 31).toInt() + 1
        val totalSamples = bits and 0xFFFFFFFFFL
        if (sampleRate !in 1..768_000 || bitDepth !in 4..32 || totalSamples <= 0) return null
        return FlacStreamInfo(sampleRate, bitDepth, channels, totalSamples)
    }

    /** Length from a checked FLAC STREAMINFO header. */
    internal fun flacDurationSec(head: ByteArray): Int? = flacStreamInfo(head)?.durationSeconds?.toInt()

    /** Strip descriptive quality suffixes before appending what the file actually contains. */
    internal fun providerWithoutQuality(provider: String): String = provider.trim()
        .replace(Regex("(?i)(?:\\s+(?:\\d{1,2}\\s*-?\\s*bit|hi[- ]?res))+$"), "").trim()

    internal fun downloadSourceLabel(provider: String, actual: FlacStreamInfo): String {
        val rate = if (actual.sampleRate % 1000 == 0) (actual.sampleRate / 1000).toString()
            else "%.1f".format(java.util.Locale.ROOT, actual.sampleRate / 1000.0)
        return "${providerWithoutQuality(provider)} ${actual.bitDepth}-bit · $rate kHz"
    }

    /** The best [downloadFit]. */
    internal const val BEST_FIT = 3
    /** How long the best fit waits for the extensions above it, once it is in. */
    private const val GRACE_BEST_MS = 2_000L
    /** How long a lesser fit waits for a better one from a slower extension. */
    private const val GRACE_MS = 8_000L

    /**
     * How well [file] fits [quality], up to [BEST_FIT]: hi-res wants more than 16-bit or 48 kHz,
     * CD a 16-bit FLAC (a bigger one next), small a file kept as served (a FLAC is encoded to AAC
     * on the phone). A lossy file for CD or hi-res comes last, but is still kept as served.
     */
    internal fun downloadFit(quality: com.music.spotui.data.preferences.DownloadQuality, file: app.myspoti.extensions.DownloadFile): Int = when (quality) {
        com.music.spotui.data.preferences.DownloadQuality.SMALL -> if (file.lossless) 2 else 3
        com.music.spotui.data.preferences.DownloadQuality.HI_RES -> when {
            !file.lossless -> 1
            (file.bitDepth ?: 0) > 16 || (file.sampleRate ?: 0) > 48_000 -> 3
            else -> 2
        }
        else -> when {
            !file.lossless -> 1
            (file.bitDepth ?: 16) > 16 -> 2
            else -> 3
        }
    }

    /**
     * The files of a round's [offers] (best first, as [Extensions.download] gave them) in the
     * order they are tried, each with its offer's index: best fit, then the exact recording
     * (found by ISRC), then the offers' order, then each extension's own order.
     */
    internal fun downloadOrder(quality: com.music.spotui.data.preferences.DownloadQuality, offers: List<List<app.myspoti.extensions.DownloadFile>>): List<Pair<Int, app.myspoti.extensions.DownloadFile>> =
        offers.flatMapIndexed { i, files -> files.map { i to it } }
            .sortedWith(compareByDescending<Pair<Int, app.myspoti.extensions.DownloadFile>> { downloadFit(quality, it.second) }.thenByDescending { it.second.isrcMatched })

    /** Why a file of [seconds] is not the song of [durationMs], or null when it is (or the song's length is unknown). */
    internal fun lengthMismatch(seconds: Long, durationMs: Long): String? {
        val expected = durationMs / 1000
        return when {
            expected <= 0 -> null
            seconds < expected - SHORTER_MAX -> "the file is ${seconds}s, the song ${expected}s (a preview)"
            seconds > expected + LONGER_MAX -> "the file is ${seconds}s, the song ${expected}s (another version)"
            else -> null
        }
    }

    /** "bytes 0-99/1234" → 1234; null when absent or "*". */
    /** "bytes 100-199/1234" → 100..199; null when absent or not that shape. */
    fun contentRangeSpan(header: String?): LongRange? {
        val m = Regex("""^\s*bytes\s+(\d+)-(\d+)/(\d+|\*)\s*$""", RegexOption.IGNORE_CASE).find(header ?: return null) ?: return null
        val first = m.groupValues[1].toLongOrNull() ?: return null
        val last = m.groupValues[2].toLongOrNull() ?: return null
        return if (last >= first) first..last else null
    }

    fun contentRangeTotal(header: String?): Long? =
        header?.substringAfterLast('/', "")?.trim()?.toLongOrNull()?.takeIf { it > 0 }

    /** "US-UM7-17-03861" / "usum71703861" → "USUM71703861"; null when not an ISRC. */
    fun normalizeIsrc(raw: String): String? =
        raw.uppercase().filter { it.isLetterOrDigit() }.takeIf { Regex("[A-Z]{2}[A-Z0-9]{3}\\d{7}").matches(it) }

    /**
     * A readable file name for a visible download: "Artist - Title [trackId].flac". The track id
     * stays in the name so two recordings of one song never collide; characters a file manager
     * or MediaStore would choke on are replaced, and the readable part is capped so the whole
     * name stays well under the 255-byte file-name limit (shrunk by bytes, not characters).
     */
    internal fun publicFileName(title: String, artist: String, trackId: String, ext: String): String {
        val clean = { s: String ->
            s.replace(Regex("[/\\\\:*?\"<>|\\p{Cntrl}]"), "-").replace(Regex("\\s+"), " ").trim()
        }
        var head = listOf(clean(artist), clean(title)).filter { it.isNotEmpty() }.joinToString(" - ")
            .take(100).trimEnd('-', ' ', '.')
        while (head.isNotEmpty() && "$head [$trackId].$ext".toByteArray(Charsets.UTF_8).size > 200) {
            head = head.dropLast(1).trimEnd('-', ' ', '.')
        }
        val base = if (head.isEmpty()) trackId else "$head [$trackId]"
        return "$base.$ext"
    }

    /** The MIME type MediaStore wants for a scanned download. */
    internal fun mimeForExt(ext: String): String = when (ext.lowercase()) {
        "flac" -> "audio/flac"
        "m4a" -> "audio/mp4"
        "mp3" -> "audio/mpeg"
        else -> "audio/*"
    }

    /**
     * Moves [from] to [to]: a rename when both are on one filesystem, else a copy (the temp
     * folder is internal storage, the Download folder is shared storage: a rename across them fails).
     * A copy that ends short leaves no partial file behind.
     */
    private fun moveFile(from: File, to: File): Boolean {
        if (from.renameTo(to)) return true
        val ok = runCatching {
            to.parentFile?.mkdirs()
            from.inputStream().use { input -> to.outputStream().use { output -> input.copyTo(output) } }
            from.length() == to.length()
        }.getOrDefault(false)
        if (ok) from.delete() else to.delete()
        return ok
    }
}
