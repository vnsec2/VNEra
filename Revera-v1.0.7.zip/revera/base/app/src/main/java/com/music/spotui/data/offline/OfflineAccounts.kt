package com.music.spotui.data.offline
import app.myspoti.host.android.AppLog

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

/**
 * Downloads belong to the Spotify account that made them. The downloads folder (`offline/`: songs,
 * episodes, lists, queues) is stamped with its account; on sign-out it is put aside under that
 * account (`offline-accounts/<key>/`) and the next account starts with none. Signing in again
 * brings that account's own folder back. Nothing is deleted: a phone shared by two accounts keeps
 * both sets, each seen only by its own account. Downloads made before the stamp existed go to the
 * first account seen signed in.
 *
 * Songs saved as visible files (Download/Orpheon) are not moved: they belong to the phone, not the
 * account. The folder still moves (index, covers, queues), so signing in again re-links the same
 * account's songs to the files that stayed in Download/; another account simply does not see them
 * in its Downloaded list.
 */
object OfflineAccounts {
    private const val OWNER = "owner"
    private val lock = Mutex()

    private fun live(context: Context) = File(context.filesDir, "offline")
    private fun parked(context: Context, key: String) = File(context.filesDir, "offline-accounts/$key")
    private fun ownerOf(dir: File): String? = File(dir, OWNER).takeIf { it.isFile }?.readText()?.trim()?.ifBlank { null }

    /** A stable, opaque folder name for a Spotify user id (the id itself is not written down). */
    internal fun keyOf(userId: String): String =
        MessageDigest.getInstance("SHA-256").digest(userId.toByteArray()).take(12).joinToString("") { "%02x".format(it) }

    /** Signing out: this account's downloads go aside; [userId] names them when the folder has no stamp yet. */
    suspend fun park(context: Context, userId: String?) = lock.withLock {
        val dir = live(context)
        val owner = ownerOf(dir) ?: userId?.let(::keyOf)
        if (owner == null && !hasDownloads(dir)) return@withLock
        // Whose they are is unknown (never signed in online since): kept aside, never given to anyone.
        val key = owner ?: "unclaimed-${System.currentTimeMillis()}"
        stopDownloads(dir)
        val moved = withContext(Dispatchers.IO) { OfflineStore.moving { putAside(dir, parked(context, key)) } }
        if (!moved) {
            // Still in place and still stamped with their account: the next sign-in puts them aside.
            AppLog.d("offline: downloads not put aside for sign-out")
            return@withLock
        }
        reopen(context)
        AppLog.d("offline: downloads put aside for sign-out")
    }

    /** [userId] is signed in: its downloads are the ones shown; downloads with no stamp yet become its own. */
    suspend fun claim(context: Context, userId: String) = lock.withLock {
        val key = keyOf(userId)
        val dir = live(context)
        val owner = ownerOf(dir)
        if (owner == key) return@withLock
        if (owner == null && hasDownloads(dir)) {
            stamp(dir, key)
            return@withLock
        }
        // Another account's downloads are in place (a sign-out that could not put them aside), or none.
        stopDownloads(dir)
        val ready = withContext(Dispatchers.IO) { OfflineStore.moving { swap(context, dir, owner, key) } }
        if (ready != Claimed.READY) {
            AppLog.d(                if (ready == Claimed.NOT_CLEARED) "offline: the other account's downloads could not be put aside"
                else "offline: this account's downloads could not be brought back; they stay put aside, tried again at the next sign-in"
            )
            reopen(context)
            return@withLock
        }
        reopen(context)
        // Its queues came back with its folder: they go on where they stopped.
        OfflineDownloader.resumePending()
        PodcastDownloader.resumePending()
        AppLog.d("offline: this account's downloads in place (${OfflineStore.tracks.size} songs)")
    }

    private enum class Claimed { READY, NOT_CLEARED, NOT_BROUGHT_BACK }

    /** The downloads of [owner] (or none) in [dir] go aside, and those of [key] come back in their place. */
    private fun swap(context: Context, dir: File, owner: String?, key: String): Claimed {
        // This account's stamp only goes on an emptied folder or its own: downloads that could not
        // be moved keep their own account's stamp, never this one.
        val cleared = if (owner != null) putAside(dir, parked(context, owner)) else dir.deleteRecursively()
        if (!cleared) return Claimed.NOT_CLEARED
        val back = parked(context, key)
        // Not stamped when its own folder did not come back: an empty folder with its stamp would
        // read as its downloads in place, and the folder put aside would never be tried again.
        if (back.isDirectory && !(back.renameTo(dir) && dir.isDirectory)) return Claimed.NOT_BROUGHT_BACK
        stamp(dir, key)
        return Claimed.READY
    }

    /**
     * Moves [dir] to [to]. A folder already there (left by an earlier sign-out that went wrong) is
     * kept under another name rather than deleted. False when the move failed: [dir] is untouched.
     */
    private fun putAside(dir: File, to: File): Boolean {
        to.parentFile?.mkdirs()
        if (to.exists() && !to.renameTo(File(to.parentFile, "${to.name}-${System.currentTimeMillis()}"))) return false
        return dir.renameTo(to)
    }

    private fun stamp(dir: File, key: String) {
        dir.mkdirs()
        runCatching { com.music.spotui.data.writeTextSafely(File(dir, OWNER), key) }
    }

    private fun hasDownloads(dir: File): Boolean =
        File(dir, "index.json").length() > 2 || File(dir, "collections.json").length() > 2 ||
            File(dir, "pending.json").length() > 2 || File(dir, "podcasts-pending.json").length() > 2 ||
            // Songs whose index was lost (only the older copy, or none, could be read) are downloads too.
            File(dir, "audio").list()?.isNotEmpty() == true || File(dir, "recovered").exists()

    /** Running downloads stop; the queues on disk are kept as they were, so they resume with their account. */
    private suspend fun stopDownloads(dir: File) {
        val queues = listOf(File(dir, "pending.json"), File(dir, "podcasts-pending.json"))
        val saved = withContext(Dispatchers.IO) { queues.map { f -> f to f.takeIf { it.isFile }?.readText() } }
        OfflineDownloader.forgetSession()
        PodcastDownloader.forgetSession()
        withContext(Dispatchers.IO) { saved.forEach { (f, text) -> if (text != null) runCatching { f.writeText(text) } } }
    }

    private suspend fun reopen(context: Context) = withContext(Dispatchers.Main) {
        OfflineStore.reopen(context)
        OfflineCollections.reopen()
    }
}
