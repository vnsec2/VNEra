package app.myspoti.spotify

import app.myspoti.api.Repeat
import app.myspoti.spotify.bridge.AdSchedule
import app.myspoti.spotify.bridge.Bridge
import app.myspoti.spotify.bridge.BridgeHost
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Repeat one through what takes a song's end away from it: an ad, a song stuck at its end, the
 * ad-avoiding play. Reported (2.1.0 to 2.3.0): the song looped two or three times, then the next
 * one played.
 */
class RepeatOneTest {
    private class FakeHost : BridgeHost {
        override val messages = MutableSharedFlow<String>(extraBufferCapacity = 64)
        /** Every call the player made: method to its arguments (json text). */
        val calls = CopyOnWriteArrayList<Pair<String, String>>()
        override suspend fun evaluate(script: String) {
            val m = Regex("""Myspoti\.call\((\d+), "([^"]+)", (.*)\)\.catch""", RegexOption.DOT_MATCHES_ALL).find(script) ?: return
            calls += m.groupValues[2] to m.groupValues[3]
            // The page's media element: this phone the active device, or another one.
            val value = if (m.groupValues[2] == "media.state") """{"paused":$mediaPaused,"muted":false,"level":1,"own":1,"time":0,"active":$mediaActive}""" else "null"
            messages.emit("""{"type":"result","id":${m.groupValues[1]},"ok":true,"value":$value}""")
        }
        suspend fun post(json: String) = messages.emit(json)
        @Volatile var mediaActive = true
        @Volatile var mediaPaused = false
    }

    private val time = VirtualTime()
    private lateinit var scope: CoroutineScope
    private lateinit var host: FakeHost
    private lateinit var bridge: Bridge
    private lateinit var player: SpotifyPlayer

    @BeforeEach fun up() {
        AdSchedule.clear()
        scope = time.scope
        host = FakeHost()
        bridge = Bridge(host, scope, time::now)
        player = SpotifyPlayer(bridge, scope)
    }

    @AfterEach fun down() {
        AdSchedule.clear()
        scope.cancel()
    }

    private fun track(name: String, ms: Long = 200_000, provider: String? = null) =
        """{"kind":"track","uri":"spotify:track:$name","uid":"u$name","name":"$name","durationMs":$ms${provider?.let { ""","provider":"$it"""" }.orEmpty()}}"""

    private fun state(item: String, next: String? = null, repeat: Int = 2, positionMs: Long = 0, buffering: Boolean = false) =
        """{"type":"state","state":{"track":$item,"contextUri":"spotify:playlist:C","next":${next ?: "null"},"isPaused":false,"isBuffering":$buffering,
            |"repeat":$repeat,"positionMs":$positionMs,"timestamp":${time.now()},"restrictions":{}}}""".trimMargin()

    private val ad = """{"kind":"ad","uri":"spotify:ad:1","name":"ad","durationMs":30000}"""

    private suspend fun waitFor(what: String, ms: Long = 4_000, cond: () -> Boolean) = time.waitFor(what, ms, cond)

    private fun plays() = host.calls.filter { it.first == "player.play" }.map { it.second }
    private fun called(method: String) = host.calls.count { it.first == method }

    private suspend fun readyWithRepeatOne() {
        host.post("""{"type":"ready"}""")
        waitFor("ready") { bridge.ready.value }
        player.setRepeat(Repeat.TRACK)
    }

    @Test fun `an ad over under repeat one plays the song before it again, not the one the page went to`() = time.test {
        readyWithRepeatOne()
        host.post(state(track("A"), track("B")))
        waitFor("A") { player.state.value?.item?.uri == "spotify:track:A" }
        host.post(state(ad))
        waitFor("ad flag") { player.adPlaying.value }
        host.post(state(track("B"), track("C")))
        waitFor("A played again") { plays().isNotEmpty() }
        assertTrue("\"trackUri\":\"spotify:track:A\"" in plays().single(), "the song before the ad: ${plays()}")
    }

    @Test fun `a skip during the ad under repeat one is the user's, the song before it is not played again`() = time.test {
        readyWithRepeatOne()
        host.post(state(track("A"), track("B")))
        waitFor("A") { player.state.value?.item?.uri == "spotify:track:A" }
        host.post(state(ad))
        waitFor("ad flag") { player.adPlaying.value }
        player.next()
        host.post(state(track("B"), track("C")))
        delay(600)
        assertTrue(plays().none { "spotify:track:A" in it }, "the skip stands: ${plays()}")
    }

    @Test fun `a song stuck past its end under repeat one is played again`() = time.test {
        readyWithRepeatOne()
        host.post(state(track("A"), track("B"), positionMs = 202_000))
        waitFor("stall repaired", ms = 10_000) { plays().isNotEmpty() }
        assertTrue("\"trackUri\":\"spotify:track:A\"" in plays().first(), "the song again, not B: ${plays()}")
    }

    @Test fun `a song autoplay brought, stuck past its end with nothing after it, is not played again in the list`() = time.test {
        host.post("""{"type":"ready"}""")
        host.post(state(track("A", provider = "autoplay"), repeat = 0, positionMs = 202_000))
        waitFor("stall repaired", ms = 10_000) { called("player.next") > 0 }
        assertTrue(plays().isEmpty(), "the list would start over (#135): ${plays()}")
    }

    @Test fun `another device playing is never given the repeat from here, and its repeat is the choice`() = time.test {
        host.mediaActive = false
        host.mediaPaused = true
        host.post("""{"type":"ready"}""")
        host.post(state(track("A"), repeat = 0))
        // The watcher reads the element at its first tick (up to 4 s after it started).
        waitFor("another device seen", ms = 10_000) { player.remoteActive }
        // The repeat of an earlier run, restored as after a play; the other device reports off at the loop.
        player.restoreRepeat(Repeat.TRACK)
        host.post(state(track("A"), repeat = 0, positionMs = 198_000))
        delay(400)
        host.post(state(track("A"), repeat = 0, positionMs = 199_500))
        delay(400)
        assertEquals(0, called("player.setRepeat"), "nothing sent to the other device: ${host.calls.map { it.first }}")
        assertEquals(Repeat.OFF, player.state.value?.repeat)
    }

    @Test fun `a play here taking the music back from another device is given the repeat chosen`() = time.test {
        host.mediaActive = false
        host.mediaPaused = true
        host.post("""{"type":"ready"}""")
        host.post(state(track("A"), repeat = 0))
        waitFor("another device seen", ms = 10_000) { player.remoteActive }
        player.restoreRepeat(Repeat.TRACK)
        // The play takes the music here; the page's first report (its own options) comes before
        // the watcher reads the element again, which still says another device.
        player.play("spotify:playlist:C", trackUri = "spotify:track:B")
        host.post(state(track("B"), repeat = 0))
        host.mediaActive = true
        host.mediaPaused = false
        waitFor("repeat set again") { called("player.setRepeat") > 0 }
        assertEquals(Repeat.TRACK, player.state.value?.repeat)
    }

    @Test fun `a report before the element is read gives another device playing no repeat`() = time.test {
        host.mediaActive = false
        host.mediaPaused = true
        player.restoreRepeat(Repeat.TRACK)
        host.post("""{"type":"ready"}""")
        host.post(state(track("A"), repeat = 0))
        waitFor("another device seen", ms = 10_000) { player.remoteActive }
        delay(400)
        assertEquals(0, called("player.setRepeat"), "nothing sent to the other device: ${host.calls.map { it.first }}")
    }

    @Test fun `a report before the element is read is given the repeat once this page is seen playing`() = time.test {
        player.restoreRepeat(Repeat.TRACK)
        host.post("""{"type":"ready"}""")
        host.post(state(track("A"), repeat = 0))
        waitFor("repeat set again", ms = 10_000) { called("player.setRepeat") > 0 }
        assertEquals(1, called("player.setRepeat"))
    }

    @Test fun `a transient null at the loop does not discard repeat one`() = time.test {
        readyWithRepeatOne()
        // A song plays: the watcher reads the element (with nothing playing it waits for a state).
        host.post(state(track("A")))
        waitFor("element read", ms = 10_000) { called("media.state") > 0 }
        // The ordinary loop occurs long after the 20 s restore window and the 5 s set hold.
        for (name in listOf("repeatRestoreUntil", "repeatHeldUntil")) {
            SpotifyPlayer::class.java.getDeclaredField(name).apply { isAccessible = true }.setLong(player, 0L)
        }
        host.post(state(track("A"), positionMs = 199_000))
        waitFor("A at its end") { player.state.value?.positionMs == 199_000L }
        host.post("""{"type":"state","state":null}""")
        waitFor("transient empty state") { player.state.value == null }
        val sets = called("player.setRepeat")
        host.post(state(track("A"), repeat = 0, positionMs = 500))
        waitFor("repeat restored across the empty state") { called("player.setRepeat") > sets }
        assertEquals(Repeat.TRACK, player.state.value?.repeat)
    }
}
